unpacked & leaked by aptitude#2684 @ globalfall.xyz

Fuck you diablo.


Make sure you remove their "Mapper.exe" that starts, that's a virus that will grab saved passwords. I forgot to remove it, so remove that :)

dont ask me for help or anything, i wont answer / aptitude