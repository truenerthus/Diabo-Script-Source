﻿using System;
using System.Collections.Generic;

namespace Impure
{
	// Token: 0x02000003 RID: 3
	internal class AuthApp
	{
		// Token: 0x06000005 RID: 5 RVA: 0x000031DC File Offset: 0x000013DC
		public static string GrabVariable(string name)
		{
			string result;
			try
			{
				bool flag = User.ID != null || User.HWID != null || User.IP != null || !Constants.Breached;
				if (flag)
				{
					result = AuthApp.Variables[name];
				}
				else
				{
					Constants.Breached = true;
					result = "User is not logged in, possible breach detected!";
				}
			}
			catch
			{
				result = "N/A";
			}
			return result;
		}

		// Token: 0x04000002 RID: 2
		public static string Error = null;

		// Token: 0x04000003 RID: 3
		public static Dictionary<string, string> Variables = new Dictionary<string, string>();
	}
}
