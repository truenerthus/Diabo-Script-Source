﻿using System;
using MDriver.MEME;

namespace Impure
{
	// Token: 0x0200001A RID: 26
	internal class bigbrain
	{
		// Token: 0x060000B7 RID: 183 RVA: 0x00002673 File Offset: 0x00000873
		public static void LoadMemory(string ProcName)
		{
			bigbrain.Memory = new Requests(ProcName);
		}

		// Token: 0x0400005C RID: 92
		public static Requests Memory;

		// Token: 0x0200001B RID: 27
		public struct Vector3
		{
			// Token: 0x060000B9 RID: 185 RVA: 0x00002681 File Offset: 0x00000881
			public Vector3(float x, float y, float z)
			{
				this.x = x;
				this.y = y;
				this.z = z;
			}

			// Token: 0x0400005D RID: 93
			public float x;

			// Token: 0x0400005E RID: 94
			public float y;

			// Token: 0x0400005F RID: 95
			public float z;
		}

		// Token: 0x0200001C RID: 28
		public struct Matrix
		{
			// Token: 0x060000BA RID: 186 RVA: 0x00006548 File Offset: 0x00004748
			public Matrix(float M11, float M12, float M13, float M14, float M21, float M22, float M23, float M24, float M31, float M32, float M33, float M34, float M41, float M42, float M43, float M44)
			{
				this.M11 = M11;
				this.M12 = M12;
				this.M13 = M13;
				this.M14 = M14;
				this.M21 = M21;
				this.M22 = M22;
				this.M23 = M23;
				this.M24 = M24;
				this.M31 = M31;
				this.M32 = M32;
				this.M33 = M33;
				this.M34 = M34;
				this.M41 = M41;
				this.M42 = M42;
				this.M43 = M43;
				this.M44 = M44;
			}

			// Token: 0x04000060 RID: 96
			public float M11;

			// Token: 0x04000061 RID: 97
			public float M12;

			// Token: 0x04000062 RID: 98
			public float M13;

			// Token: 0x04000063 RID: 99
			public float M14;

			// Token: 0x04000064 RID: 100
			public float M21;

			// Token: 0x04000065 RID: 101
			public float M22;

			// Token: 0x04000066 RID: 102
			public float M23;

			// Token: 0x04000067 RID: 103
			public float M24;

			// Token: 0x04000068 RID: 104
			public float M31;

			// Token: 0x04000069 RID: 105
			public float M32;

			// Token: 0x0400006A RID: 106
			public float M33;

			// Token: 0x0400006B RID: 107
			public float M34;

			// Token: 0x0400006C RID: 108
			public float M41;

			// Token: 0x0400006D RID: 109
			public float M42;

			// Token: 0x0400006E RID: 110
			public float M43;

			// Token: 0x0400006F RID: 111
			public float M44;
		}
	}
}
