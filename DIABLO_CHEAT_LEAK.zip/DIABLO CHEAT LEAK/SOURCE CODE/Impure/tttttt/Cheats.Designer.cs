﻿namespace Impure.tttttt
{
	// Token: 0x0200006B RID: 107
	public partial class Cheats : global::System.Windows.Forms.Form
	{
		// Token: 0x0600019E RID: 414 RVA: 0x000157F8 File Offset: 0x000139F8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600019F RID: 415 RVA: 0x00015830 File Offset: 0x00013A30
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.tttttt.Cheats));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.pictureBox2 = new global::System.Windows.Forms.PictureBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label6 = new global::System.Windows.Forms.Label();
			this.label7 = new global::System.Windows.Forms.Label();
			this.button1 = new global::System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel1.BackgroundImage");
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(651, 151);
			this.panel1.TabIndex = 6;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(52, 133);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(193, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "NaiveCheats - Our Cheats";
			this.pictureBox1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.BackgroundImage");
			this.pictureBox1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox1.Location = new global::System.Drawing.Point(131, 157);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(128, 110);
			this.pictureBox1.TabIndex = 7;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new global::System.EventHandler(this.pictureBox1_Click);
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label2.ForeColor = global::System.Drawing.Color.CornflowerBlue;
			this.label2.Location = new global::System.Drawing.Point(164, 270);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(32, 15);
			this.label2.TabIndex = 8;
			this.label2.Text = "Rust";
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label3.ForeColor = global::System.Drawing.Color.CornflowerBlue;
			this.label3.Location = new global::System.Drawing.Point(164, 295);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(52, 15);
			this.label3.TabIndex = 9;
			this.label3.Text = "Beta 2.0";
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label4.ForeColor = global::System.Drawing.Color.Lime;
			this.label4.Location = new global::System.Drawing.Point(155, 320);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(70, 15);
			this.label4.TabIndex = 10;
			this.label4.Text = "Undetected";
			this.pictureBox2.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox2.BackgroundImage");
			this.pictureBox2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox2.Location = new global::System.Drawing.Point(340, 157);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new global::System.Drawing.Size(128, 110);
			this.pictureBox2.TabIndex = 11;
			this.pictureBox2.TabStop = false;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label5.ForeColor = global::System.Drawing.Color.Yellow;
			this.label5.Location = new global::System.Drawing.Point(377, 320);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(39, 15);
			this.label5.TabIndex = 14;
			this.label5.Text = "Down";
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label6.ForeColor = global::System.Drawing.Color.CornflowerBlue;
			this.label6.Location = new global::System.Drawing.Point(377, 295);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(69, 15);
			this.label6.TabIndex = 13;
			this.label6.Text = "Developing";
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.999999f);
			this.label7.ForeColor = global::System.Drawing.Color.CornflowerBlue;
			this.label7.Location = new global::System.Drawing.Point(377, 270);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(52, 15);
			this.label7.TabIndex = 12;
			this.label7.Text = "Valorant";
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.ForeColor = global::System.Drawing.Color.CornflowerBlue;
			this.button1.Location = new global::System.Drawing.Point(0, 434);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(651, 34);
			this.button1.TabIndex = 15;
			this.button1.Text = "Website!";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			base.ClientSize = new global::System.Drawing.Size(651, 470);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.label6);
			base.Controls.Add(this.label7);
			base.Controls.Add(this.pictureBox2);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Cheats";
			this.Text = "Cheats";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000502 RID: 1282
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000503 RID: 1283
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000504 RID: 1284
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000505 RID: 1285
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000506 RID: 1286
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000507 RID: 1287
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000508 RID: 1288
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000509 RID: 1289
		private global::System.Windows.Forms.PictureBox pictureBox2;

		// Token: 0x0400050A RID: 1290
		private global::System.Windows.Forms.Label label5;

		// Token: 0x0400050B RID: 1291
		private global::System.Windows.Forms.Label label6;

		// Token: 0x0400050C RID: 1292
		private global::System.Windows.Forms.Label label7;

		// Token: 0x0400050D RID: 1293
		private global::System.Windows.Forms.Button button1;
	}
}
