﻿namespace Impure.tttttt
{
	// Token: 0x0200006C RID: 108
	public partial class Info : global::System.Windows.Forms.Form
	{
		// Token: 0x060001A1 RID: 417 RVA: 0x00016110 File Offset: 0x00014310
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x00016148 File Offset: 0x00014348
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.tttttt.Info));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel1.BackgroundImage");
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(651, 151);
			this.panel1.TabIndex = 6;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(52, 133);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(140, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "NaiveCheats - Info";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			base.ClientSize = new global::System.Drawing.Size(651, 470);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Info";
			this.Text = "Info";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x0400050E RID: 1294
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x0400050F RID: 1295
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000510 RID: 1296
		private global::System.Windows.Forms.Label label1;
	}
}
