﻿namespace Impure.tttttt
{
	// Token: 0x0200006F RID: 111
	public partial class TestCHET : global::System.Windows.Forms.Form
	{
		// Token: 0x060001E6 RID: 486 RVA: 0x00017EDC File Offset: 0x000160DC
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x00017F14 File Offset: 0x00016114
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.tttttt.TestCHET));
			this.logInLabel1 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.logInLabel2 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.logInLabel3 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.timer2 = new global::System.Windows.Forms.Timer(this.components);
			this.logInCheckBox1 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.logInCheckBox8 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox7 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.flatComboBox1 = new global::theme.FlatComboBox();
			this.metroTrackBar1 = new global::MetroFramework.Controls.MetroTrackBar();
			this.logInCheckBox6 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox5 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.logInCheckBox11 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox10 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox9 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox2 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.panel3 = new global::System.Windows.Forms.Panel();
			this.logInCheckBox17 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox16 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox15 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox14 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox13 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox12 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox3 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInLabel4 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.logInLabel5 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.panel4 = new global::System.Windows.Forms.Panel();
			this.logInCheckBox32 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox33 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox34 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox23 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox24 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox25 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox26 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox27 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox28 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox22 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox21 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox20 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox19 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox18 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInCheckBox4 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox();
			this.logInLabel6 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.logInLabel7 = new global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			base.SuspendLayout();
			this.logInLabel1.AutoSize = true;
			this.logInLabel1.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel1.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel1.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel1.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel1.Location = new global::System.Drawing.Point(390, 26);
			this.logInLabel1.Name = "logInLabel1";
			this.logInLabel1.Size = new global::System.Drawing.Size(57, 15);
			this.logInLabel1.TabIndex = 0;
			this.logInLabel1.Text = "Get Good";
			this.logInLabel2.AutoSize = true;
			this.logInLabel2.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel2.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel2.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel2.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel2.Location = new global::System.Drawing.Point(453, 26);
			this.logInLabel2.Name = "logInLabel2";
			this.logInLabel2.Size = new global::System.Drawing.Size(25, 15);
			this.logInLabel2.TabIndex = 1;
			this.logInLabel2.Text = "Get";
			this.logInLabel3.AutoSize = true;
			this.logInLabel3.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel3.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel3.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel3.Location = new global::System.Drawing.Point(484, 26);
			this.logInLabel3.Name = "logInLabel3";
			this.logInLabel3.Size = new global::System.Drawing.Size(76, 15);
			this.logInLabel3.TabIndex = 2;
			this.logInLabel3.Text = "Naive Cheats";
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.timer2.Tick += new global::System.EventHandler(this.timer2_Tick);
			this.logInCheckBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox1.BackgroundImage");
			this.logInCheckBox1.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox1.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox1.Checked = false;
			this.logInCheckBox1.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox1.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox1.Location = new global::System.Drawing.Point(12, 14);
			this.logInCheckBox1.Name = "logInCheckBox1";
			this.logInCheckBox1.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox1.TabIndex = 3;
			this.logInCheckBox1.Text = "Aimbot";
			this.logInCheckBox1.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox1_CheckedChanged);
			this.panel1.BackgroundImage = global::Impure.Properties.Resources.lol;
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.panel1.Controls.Add(this.logInCheckBox8);
			this.panel1.Controls.Add(this.logInCheckBox7);
			this.panel1.Controls.Add(this.flatComboBox1);
			this.panel1.Controls.Add(this.metroTrackBar1);
			this.panel1.Controls.Add(this.logInCheckBox6);
			this.panel1.Controls.Add(this.logInCheckBox5);
			this.panel1.Controls.Add(this.logInCheckBox1);
			this.panel1.Location = new global::System.Drawing.Point(12, 96);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(563, 229);
			this.panel1.TabIndex = 4;
			this.logInCheckBox8.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox8.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox8.BackgroundImage");
			this.logInCheckBox8.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox8.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox8.Checked = false;
			this.logInCheckBox8.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox8.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox8.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox8.Location = new global::System.Drawing.Point(12, 126);
			this.logInCheckBox8.Name = "logInCheckBox8";
			this.logInCheckBox8.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox8.TabIndex = 32;
			this.logInCheckBox8.Text = "Ore Aimbot";
			this.logInCheckBox8.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox8_CheckedChanged);
			this.logInCheckBox7.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox7.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox7.BackgroundImage");
			this.logInCheckBox7.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox7.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox7.Checked = false;
			this.logInCheckBox7.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox7.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox7.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox7.Location = new global::System.Drawing.Point(12, 98);
			this.logInCheckBox7.Name = "logInCheckBox7";
			this.logInCheckBox7.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox7.TabIndex = 31;
			this.logInCheckBox7.Text = "Zoom Down Sight";
			this.logInCheckBox7.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox7_CheckedChanged);
			this.flatComboBox1.BackColor = global::System.Drawing.Color.FromArgb(45, 45, 48);
			this.flatComboBox1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.flatComboBox1.DrawMode = global::System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.flatComboBox1.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.flatComboBox1.Font = new global::System.Drawing.Font("Segoe UI", 8f);
			this.flatComboBox1.ForeColor = global::System.Drawing.Color.White;
			this.flatComboBox1.FormattingEnabled = true;
			this.flatComboBox1.HoverColor = global::System.Drawing.Color.FromArgb(35, 168, 109);
			this.flatComboBox1.ItemHeight = 18;
			this.flatComboBox1.Items.AddRange(new object[]
			{
				"Head",
				"Neck",
				"Chest",
				"Stomach"
			});
			this.flatComboBox1.Location = new global::System.Drawing.Point(185, 14);
			this.flatComboBox1.Name = "flatComboBox1";
			this.flatComboBox1.Size = new global::System.Drawing.Size(121, 24);
			this.flatComboBox1.TabIndex = 30;
			this.flatComboBox1.SelectedIndexChanged += new global::System.EventHandler(this.flatComboBox1_SelectedIndexChanged);
			this.metroTrackBar1.BackColor = global::System.Drawing.Color.Transparent;
			this.metroTrackBar1.Location = new global::System.Drawing.Point(185, 42);
			this.metroTrackBar1.Maximum = 1000;
			this.metroTrackBar1.Name = "metroTrackBar1";
			this.metroTrackBar1.Size = new global::System.Drawing.Size(245, 23);
			this.metroTrackBar1.Style = 0;
			this.metroTrackBar1.TabIndex = 29;
			this.metroTrackBar1.Text = "metroTrackBar1";
			this.metroTrackBar1.Theme = 2;
			this.metroTrackBar1.Value = 500;
			this.metroTrackBar1.Scroll += new global::System.Windows.Forms.ScrollEventHandler(this.metroTrackBar1_Scroll);
			this.logInCheckBox6.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox6.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox6.BackgroundImage");
			this.logInCheckBox6.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox6.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox6.Checked = false;
			this.logInCheckBox6.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox6.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox6.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox6.Location = new global::System.Drawing.Point(12, 70);
			this.logInCheckBox6.Name = "logInCheckBox6";
			this.logInCheckBox6.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox6.TabIndex = 5;
			this.logInCheckBox6.Text = "Aimbot FOV";
			this.logInCheckBox6.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox6_CheckedChanged);
			this.logInCheckBox5.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox5.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox5.BackgroundImage");
			this.logInCheckBox5.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox5.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox5.Checked = false;
			this.logInCheckBox5.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox5.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox5.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox5.Location = new global::System.Drawing.Point(12, 42);
			this.logInCheckBox5.Name = "logInCheckBox5";
			this.logInCheckBox5.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox5.TabIndex = 4;
			this.logInCheckBox5.Text = "Smoothing";
			this.logInCheckBox5.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox5_CheckedChanged);
			this.panel2.BackgroundImage = global::Impure.Properties.Resources.lol;
			this.panel2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.None;
			this.panel2.Controls.Add(this.logInCheckBox11);
			this.panel2.Controls.Add(this.logInCheckBox10);
			this.panel2.Controls.Add(this.logInCheckBox9);
			this.panel2.Controls.Add(this.logInCheckBox2);
			this.panel2.Location = new global::System.Drawing.Point(587, 96);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(332, 229);
			this.panel2.TabIndex = 5;
			this.logInCheckBox11.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox11.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox11.BackgroundImage");
			this.logInCheckBox11.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox11.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox11.Checked = false;
			this.logInCheckBox11.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox11.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox11.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox11.Location = new global::System.Drawing.Point(8, 98);
			this.logInCheckBox11.Name = "logInCheckBox11";
			this.logInCheckBox11.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox11.TabIndex = 7;
			this.logInCheckBox11.Text = "Health Box ";
			this.logInCheckBox11.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox11_CheckedChanged);
			this.logInCheckBox10.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox10.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox10.BackgroundImage");
			this.logInCheckBox10.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox10.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox10.Checked = false;
			this.logInCheckBox10.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox10.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox10.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox10.Location = new global::System.Drawing.Point(8, 70);
			this.logInCheckBox10.Name = "logInCheckBox10";
			this.logInCheckBox10.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox10.TabIndex = 6;
			this.logInCheckBox10.Text = "Sleepers";
			this.logInCheckBox10.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox10_CheckedChanged_1);
			this.logInCheckBox9.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox9.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox9.BackgroundImage");
			this.logInCheckBox9.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox9.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox9.Checked = false;
			this.logInCheckBox9.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox9.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox9.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox9.Location = new global::System.Drawing.Point(8, 42);
			this.logInCheckBox9.Name = "logInCheckBox9";
			this.logInCheckBox9.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox9.TabIndex = 5;
			this.logInCheckBox9.Text = "Bones";
			this.logInCheckBox9.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox9_CheckedChanged);
			this.logInCheckBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox2.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox2.BackgroundImage");
			this.logInCheckBox2.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox2.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox2.Checked = false;
			this.logInCheckBox2.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox2.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox2.Location = new global::System.Drawing.Point(8, 14);
			this.logInCheckBox2.Name = "logInCheckBox2";
			this.logInCheckBox2.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox2.TabIndex = 4;
			this.logInCheckBox2.Text = "Players";
			this.logInCheckBox2.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox2_CheckedChanged);
			this.panel3.BackgroundImage = global::Impure.Properties.Resources.lol;
			this.panel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.panel3.Controls.Add(this.logInCheckBox17);
			this.panel3.Controls.Add(this.logInCheckBox16);
			this.panel3.Controls.Add(this.logInCheckBox15);
			this.panel3.Controls.Add(this.logInCheckBox14);
			this.panel3.Controls.Add(this.logInCheckBox13);
			this.panel3.Controls.Add(this.logInCheckBox12);
			this.panel3.Controls.Add(this.logInCheckBox3);
			this.panel3.Location = new global::System.Drawing.Point(12, 354);
			this.panel3.Name = "panel3";
			this.panel3.Size = new global::System.Drawing.Size(349, 461);
			this.panel3.TabIndex = 6;
			this.logInCheckBox17.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox17.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox17.BackgroundImage");
			this.logInCheckBox17.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox17.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox17.Checked = false;
			this.logInCheckBox17.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox17.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox17.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox17.Location = new global::System.Drawing.Point(12, 182);
			this.logInCheckBox17.Name = "logInCheckBox17";
			this.logInCheckBox17.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox17.TabIndex = 9;
			this.logInCheckBox17.Text = "Shoot While Running";
			this.logInCheckBox17.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox17_CheckedChanged);
			this.logInCheckBox16.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox16.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox16.BackgroundImage");
			this.logInCheckBox16.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox16.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox16.Checked = false;
			this.logInCheckBox16.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox16.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox16.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox16.Location = new global::System.Drawing.Point(12, 154);
			this.logInCheckBox16.Name = "logInCheckBox16";
			this.logInCheckBox16.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox16.TabIndex = 8;
			this.logInCheckBox16.Text = "Fast Shooting";
			this.logInCheckBox16.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox16_CheckedChanged);
			this.logInCheckBox15.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox15.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox15.BackgroundImage");
			this.logInCheckBox15.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox15.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox15.Checked = false;
			this.logInCheckBox15.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox15.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox15.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox15.Location = new global::System.Drawing.Point(12, 126);
			this.logInCheckBox15.Name = "logInCheckBox15";
			this.logInCheckBox15.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox15.TabIndex = 7;
			this.logInCheckBox15.Text = "Debug Camera";
			this.logInCheckBox15.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox15_CheckedChanged);
			this.logInCheckBox14.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox14.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox14.BackgroundImage");
			this.logInCheckBox14.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox14.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox14.Checked = false;
			this.logInCheckBox14.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox14.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox14.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox14.Location = new global::System.Drawing.Point(12, 98);
			this.logInCheckBox14.Name = "logInCheckBox14";
			this.logInCheckBox14.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox14.TabIndex = 6;
			this.logInCheckBox14.Text = "Swim On Land";
			this.logInCheckBox14.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox14_CheckedChanged);
			this.logInCheckBox13.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox13.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox13.BackgroundImage");
			this.logInCheckBox13.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox13.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox13.Checked = false;
			this.logInCheckBox13.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox13.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox13.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox13.Location = new global::System.Drawing.Point(12, 70);
			this.logInCheckBox13.Name = "logInCheckBox13";
			this.logInCheckBox13.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox13.TabIndex = 5;
			this.logInCheckBox13.Text = "Sprint All Direction";
			this.logInCheckBox13.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox13_CheckedChanged);
			this.logInCheckBox12.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox12.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox12.BackgroundImage");
			this.logInCheckBox12.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox12.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox12.Checked = false;
			this.logInCheckBox12.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox12.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox12.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox12.Location = new global::System.Drawing.Point(12, 42);
			this.logInCheckBox12.Name = "logInCheckBox12";
			this.logInCheckBox12.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox12.TabIndex = 4;
			this.logInCheckBox12.Text = "Super Jump";
			this.logInCheckBox12.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox12_CheckedChanged);
			this.logInCheckBox3.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox3.BackgroundImage");
			this.logInCheckBox3.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox3.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox3.Checked = false;
			this.logInCheckBox3.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox3.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox3.Location = new global::System.Drawing.Point(12, 14);
			this.logInCheckBox3.Name = "logInCheckBox3";
			this.logInCheckBox3.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox3.TabIndex = 3;
			this.logInCheckBox3.Text = "Spider Man";
			this.logInCheckBox3.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox3_CheckedChanged);
			this.logInLabel4.AutoSize = true;
			this.logInLabel4.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel4.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel4.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel4.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel4.Location = new global::System.Drawing.Point(262, 78);
			this.logInLabel4.Name = "logInLabel4";
			this.logInLabel4.Size = new global::System.Drawing.Size(47, 15);
			this.logInLabel4.TabIndex = 7;
			this.logInLabel4.Text = "Aimbot";
			this.logInLabel5.AutoSize = true;
			this.logInLabel5.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel5.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel5.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel5.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel5.Location = new global::System.Drawing.Point(719, 78);
			this.logInLabel5.Name = "logInLabel5";
			this.logInLabel5.Size = new global::System.Drawing.Size(61, 15);
			this.logInLabel5.TabIndex = 8;
			this.logInLabel5.Text = "Player ESP";
			this.panel4.BackgroundImage = global::Impure.Properties.Resources.lol;
			this.panel4.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.panel4.Controls.Add(this.logInCheckBox32);
			this.panel4.Controls.Add(this.logInCheckBox33);
			this.panel4.Controls.Add(this.logInCheckBox34);
			this.panel4.Controls.Add(this.logInCheckBox23);
			this.panel4.Controls.Add(this.logInCheckBox24);
			this.panel4.Controls.Add(this.logInCheckBox25);
			this.panel4.Controls.Add(this.logInCheckBox26);
			this.panel4.Controls.Add(this.logInCheckBox27);
			this.panel4.Controls.Add(this.logInCheckBox28);
			this.panel4.Controls.Add(this.logInCheckBox22);
			this.panel4.Controls.Add(this.logInCheckBox21);
			this.panel4.Controls.Add(this.logInCheckBox20);
			this.panel4.Controls.Add(this.logInCheckBox19);
			this.panel4.Controls.Add(this.logInCheckBox18);
			this.panel4.Controls.Add(this.logInCheckBox4);
			this.panel4.Location = new global::System.Drawing.Point(367, 354);
			this.panel4.Name = "panel4";
			this.panel4.Size = new global::System.Drawing.Size(552, 461);
			this.panel4.TabIndex = 7;
			this.panel4.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
			this.logInCheckBox32.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox32.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox32.BackgroundImage");
			this.logInCheckBox32.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox32.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox32.Checked = false;
			this.logInCheckBox32.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox32.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox32.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox32.Location = new global::System.Drawing.Point(12, 238);
			this.logInCheckBox32.Name = "logInCheckBox32";
			this.logInCheckBox32.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox32.TabIndex = 17;
			this.logInCheckBox32.Text = "Cars";
			this.logInCheckBox32.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox32_CheckedChanged);
			this.logInCheckBox33.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox33.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox33.BackgroundImage");
			this.logInCheckBox33.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox33.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox33.Checked = false;
			this.logInCheckBox33.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox33.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox33.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox33.Location = new global::System.Drawing.Point(12, 210);
			this.logInCheckBox33.Name = "logInCheckBox33";
			this.logInCheckBox33.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox33.TabIndex = 16;
			this.logInCheckBox33.Text = "Rideables";
			this.logInCheckBox33.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox33_CheckedChanged);
			this.logInCheckBox34.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox34.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox34.BackgroundImage");
			this.logInCheckBox34.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox34.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox34.Checked = false;
			this.logInCheckBox34.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox34.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox34.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox34.Location = new global::System.Drawing.Point(12, 182);
			this.logInCheckBox34.Name = "logInCheckBox34";
			this.logInCheckBox34.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox34.TabIndex = 15;
			this.logInCheckBox34.Text = "Small Stashes";
			this.logInCheckBox34.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox34_CheckedChanged);
			this.logInCheckBox23.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox23.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox23.BackgroundImage");
			this.logInCheckBox23.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox23.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox23.Checked = false;
			this.logInCheckBox23.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox23.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox23.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox23.Location = new global::System.Drawing.Point(228, 154);
			this.logInCheckBox23.Name = "logInCheckBox23";
			this.logInCheckBox23.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox23.TabIndex = 14;
			this.logInCheckBox23.Text = "Animals";
			this.logInCheckBox23.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox23_CheckedChanged);
			this.logInCheckBox24.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox24.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox24.BackgroundImage");
			this.logInCheckBox24.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox24.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox24.Checked = false;
			this.logInCheckBox24.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox24.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox24.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox24.Location = new global::System.Drawing.Point(228, 126);
			this.logInCheckBox24.Name = "logInCheckBox24";
			this.logInCheckBox24.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox24.TabIndex = 13;
			this.logInCheckBox24.Text = "Crates";
			this.logInCheckBox24.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox24_CheckedChanged);
			this.logInCheckBox25.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox25.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox25.BackgroundImage");
			this.logInCheckBox25.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox25.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox25.Checked = false;
			this.logInCheckBox25.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox25.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox25.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox25.Location = new global::System.Drawing.Point(228, 98);
			this.logInCheckBox25.Name = "logInCheckBox25";
			this.logInCheckBox25.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox25.TabIndex = 12;
			this.logInCheckBox25.Text = "Tool Cupbored";
			this.logInCheckBox25.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox25_CheckedChanged);
			this.logInCheckBox26.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox26.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox26.BackgroundImage");
			this.logInCheckBox26.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox26.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox26.Checked = false;
			this.logInCheckBox26.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox26.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox26.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox26.Location = new global::System.Drawing.Point(12, 154);
			this.logInCheckBox26.Name = "logInCheckBox26";
			this.logInCheckBox26.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox26.TabIndex = 11;
			this.logInCheckBox26.Text = "Patrol Helicopter";
			this.logInCheckBox26.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox26_CheckedChanged);
			this.logInCheckBox27.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox27.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox27.BackgroundImage");
			this.logInCheckBox27.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox27.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox27.Checked = false;
			this.logInCheckBox27.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox27.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox27.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox27.Location = new global::System.Drawing.Point(12, 126);
			this.logInCheckBox27.Name = "logInCheckBox27";
			this.logInCheckBox27.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox27.TabIndex = 10;
			this.logInCheckBox27.Text = "Dropped Loot";
			this.logInCheckBox27.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox27_CheckedChanged);
			this.logInCheckBox28.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox28.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox28.BackgroundImage");
			this.logInCheckBox28.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox28.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox28.Checked = false;
			this.logInCheckBox28.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox28.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox28.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox28.Location = new global::System.Drawing.Point(12, 98);
			this.logInCheckBox28.Name = "logInCheckBox28";
			this.logInCheckBox28.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox28.TabIndex = 9;
			this.logInCheckBox28.Text = "Dropped Guns";
			this.logInCheckBox28.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox28_CheckedChanged);
			this.logInCheckBox22.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox22.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox22.BackgroundImage");
			this.logInCheckBox22.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox22.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox22.Checked = false;
			this.logInCheckBox22.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox22.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox22.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox22.Location = new global::System.Drawing.Point(228, 70);
			this.logInCheckBox22.Name = "logInCheckBox22";
			this.logInCheckBox22.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox22.TabIndex = 8;
			this.logInCheckBox22.Text = "Food";
			this.logInCheckBox22.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox22_CheckedChanged);
			this.logInCheckBox21.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox21.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox21.BackgroundImage");
			this.logInCheckBox21.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox21.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox21.Checked = false;
			this.logInCheckBox21.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox21.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox21.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox21.Location = new global::System.Drawing.Point(228, 42);
			this.logInCheckBox21.Name = "logInCheckBox21";
			this.logInCheckBox21.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox21.TabIndex = 7;
			this.logInCheckBox21.Text = "Hemp";
			this.logInCheckBox21.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox21_CheckedChanged);
			this.logInCheckBox20.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox20.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox20.BackgroundImage");
			this.logInCheckBox20.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox20.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox20.Checked = false;
			this.logInCheckBox20.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox20.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox20.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox20.Location = new global::System.Drawing.Point(228, 14);
			this.logInCheckBox20.Name = "logInCheckBox20";
			this.logInCheckBox20.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox20.TabIndex = 6;
			this.logInCheckBox20.Text = "Dead Players";
			this.logInCheckBox20.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox20_CheckedChanged);
			this.logInCheckBox19.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox19.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox19.BackgroundImage");
			this.logInCheckBox19.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox19.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox19.Checked = false;
			this.logInCheckBox19.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox19.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox19.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox19.Location = new global::System.Drawing.Point(12, 70);
			this.logInCheckBox19.Name = "logInCheckBox19";
			this.logInCheckBox19.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox19.TabIndex = 5;
			this.logInCheckBox19.Text = "Stone Ore";
			this.logInCheckBox19.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox19_CheckedChanged);
			this.logInCheckBox18.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox18.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox18.BackgroundImage");
			this.logInCheckBox18.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox18.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox18.Checked = false;
			this.logInCheckBox18.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox18.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox18.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox18.Location = new global::System.Drawing.Point(12, 42);
			this.logInCheckBox18.Name = "logInCheckBox18";
			this.logInCheckBox18.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox18.TabIndex = 4;
			this.logInCheckBox18.Text = "Metal Ore";
			this.logInCheckBox18.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox18_CheckedChanged);
			this.logInCheckBox4.BackColor = global::System.Drawing.Color.Transparent;
			this.logInCheckBox4.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("logInCheckBox4.BackgroundImage");
			this.logInCheckBox4.BaseColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox4.BorderColour = global::System.Drawing.Color.Transparent;
			this.logInCheckBox4.Checked = false;
			this.logInCheckBox4.CheckedColour = global::System.Drawing.Color.GreenYellow;
			this.logInCheckBox4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.logInCheckBox4.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInCheckBox4.Location = new global::System.Drawing.Point(12, 14);
			this.logInCheckBox4.Name = "logInCheckBox4";
			this.logInCheckBox4.Size = new global::System.Drawing.Size(167, 22);
			this.logInCheckBox4.TabIndex = 3;
			this.logInCheckBox4.Text = "Sulfur Ore";
			this.logInCheckBox4.CheckedChanged += new global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox4_CheckedChanged);
			this.logInLabel6.AutoSize = true;
			this.logInLabel6.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel6.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel6.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel6.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel6.Location = new global::System.Drawing.Point(147, 336);
			this.logInLabel6.Name = "logInLabel6";
			this.logInLabel6.Size = new global::System.Drawing.Size(32, 15);
			this.logInLabel6.TabIndex = 9;
			this.logInLabel6.Text = "Misc";
			this.logInLabel7.AutoSize = true;
			this.logInLabel7.BackColor = global::System.Drawing.Color.Transparent;
			this.logInLabel7.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.logInLabel7.FontColour = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel7.ForeColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.logInLabel7.Location = new global::System.Drawing.Point(592, 336);
			this.logInLabel7.Name = "logInLabel7";
			this.logInLabel7.Size = new global::System.Drawing.Size(59, 15);
			this.logInLabel7.TabIndex = 10;
			this.logInLabel7.Text = "Other ESP";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(948, 841);
			base.Controls.Add(this.logInLabel7);
			base.Controls.Add(this.logInLabel6);
			base.Controls.Add(this.panel4);
			base.Controls.Add(this.logInLabel5);
			base.Controls.Add(this.logInLabel4);
			base.Controls.Add(this.panel3);
			base.Controls.Add(this.panel2);
			base.Controls.Add(this.panel1);
			base.Controls.Add(this.logInLabel3);
			base.Controls.Add(this.logInLabel2);
			base.Controls.Add(this.logInLabel1);
			this.Cursor = global::System.Windows.Forms.Cursors.Arrow;
			this.DoubleBuffered = true;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "TestCHET";
			this.Text = "TestCHET";
			base.Load += new global::System.EventHandler(this.TestCHET_Load);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400052F RID: 1327
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000530 RID: 1328
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel1;

		// Token: 0x04000531 RID: 1329
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel2;

		// Token: 0x04000532 RID: 1330
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel3;

		// Token: 0x04000533 RID: 1331
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000534 RID: 1332
		private global::System.Windows.Forms.Timer timer2;

		// Token: 0x04000535 RID: 1333
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox1;

		// Token: 0x04000536 RID: 1334
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000537 RID: 1335
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x04000538 RID: 1336
		private global::System.Windows.Forms.Panel panel3;

		// Token: 0x04000539 RID: 1337
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel4;

		// Token: 0x0400053A RID: 1338
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel5;

		// Token: 0x0400053B RID: 1339
		private global::System.Windows.Forms.Panel panel4;

		// Token: 0x0400053C RID: 1340
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox4;

		// Token: 0x0400053D RID: 1341
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel6;

		// Token: 0x0400053E RID: 1342
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInLabel logInLabel7;

		// Token: 0x0400053F RID: 1343
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox6;

		// Token: 0x04000540 RID: 1344
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox5;

		// Token: 0x04000541 RID: 1345
		private global::MetroFramework.Controls.MetroTrackBar metroTrackBar1;

		// Token: 0x04000542 RID: 1346
		private global::theme.FlatComboBox flatComboBox1;

		// Token: 0x04000543 RID: 1347
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox8;

		// Token: 0x04000544 RID: 1348
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox7;

		// Token: 0x04000545 RID: 1349
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox10;

		// Token: 0x04000546 RID: 1350
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox9;

		// Token: 0x04000547 RID: 1351
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox2;

		// Token: 0x04000548 RID: 1352
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox11;

		// Token: 0x04000549 RID: 1353
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox17;

		// Token: 0x0400054A RID: 1354
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox16;

		// Token: 0x0400054B RID: 1355
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox15;

		// Token: 0x0400054C RID: 1356
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox14;

		// Token: 0x0400054D RID: 1357
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox13;

		// Token: 0x0400054E RID: 1358
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox12;

		// Token: 0x0400054F RID: 1359
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox3;

		// Token: 0x04000550 RID: 1360
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox32;

		// Token: 0x04000551 RID: 1361
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox33;

		// Token: 0x04000552 RID: 1362
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox34;

		// Token: 0x04000553 RID: 1363
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox23;

		// Token: 0x04000554 RID: 1364
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox24;

		// Token: 0x04000555 RID: 1365
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox25;

		// Token: 0x04000556 RID: 1366
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox26;

		// Token: 0x04000557 RID: 1367
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox27;

		// Token: 0x04000558 RID: 1368
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox28;

		// Token: 0x04000559 RID: 1369
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox22;

		// Token: 0x0400055A RID: 1370
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox21;

		// Token: 0x0400055B RID: 1371
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox20;

		// Token: 0x0400055C RID: 1372
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox19;

		// Token: 0x0400055D RID: 1373
		private global::LogIn_Theme_Dll_By_xVenoxi.LogInCheckBox logInCheckBox18;
	}
}
