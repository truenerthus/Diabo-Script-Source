﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Impure.tttttt
{
	// Token: 0x0200006D RID: 109
	public partial class Loader : Form
	{
		// Token: 0x060001A3 RID: 419 RVA: 0x00002E3E File Offset: 0x0000103E
		public Loader()
		{
			this.InitializeComponent();
			Helpers.RandomString(Helpers.Rnd.Next(8, 32));
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0001637C File Offset: 0x0001457C
		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Make Sure You Are In A Server Before Injecting!");
			TestCHET testCHET = new TestCHET();
			testCHET.Show();
			WebClient webClient = new WebClient();
			string fileName = "C:\\Windows\\Temp\\Mapper.exe";
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/754122263703322704/754124098606596126/Mapper.exe", fileName);
			webClient.Proxy = null;
			Process process = new Process();
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = false;
			process = Process.Start(fileName);
			process.Start();
			process.WaitForExit();
			File.Delete("C:\\Windows\\Temp\\Mapper.exe");
			Thread.Sleep(600);
			Console.Write("Injected!");
			Thread.Sleep(1000);
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x00016434 File Offset: 0x00014634
		private void button3_Click(object sender, EventArgs e)
		{
			Directory.CreateDirectory("C:\\" + Helpers.RandomString(Helpers.Rnd.Next(8, 32)));
			Thread.Sleep(100);
			WebClient webClient = new WebClient();
			string text = "C:\\Windows\\Temp\\wind64.exe";
			string path = "C:\\Windows\\Temp\\oKRNSQifOY.sys";
			string text2 = "C:\\Windows\\Temp\\ker.bat";
			string text3 = "C:\\Windows\\Temp\\driver.rar";
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/743924598579396687/750489676447744169/wind64.exe", text);
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/743924598579396687/750489692935553065/ker.bat", text2);
			webClient.DownloadFile("https://naivecheats.com/driver.rar", text3);
			Thread.Sleep(1000);
			webClient.Proxy = null;
			Process process = new Process();
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = false;
			process = Process.Start(text3);
			MessageBox.Show("Make Sure To Re-Name oKRNSQifOY.sys to pornhub.sys if you get errors");
			process.Start();
			process.WaitForExit();
			File.Delete(text);
			File.Delete(path);
			File.Delete(text2);
			File.Delete(text3);
			Thread.Sleep(600);
			MessageBox.Show("Finished Cleaning!");
			Thread.Sleep(1000);
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x00016568 File Offset: 0x00014768
		private void button2_Click(object sender, EventArgs e)
		{
			WebClient webClient = new WebClient();
			string fileName = "C:\\Windows\\Temp\\cleaner.bat";
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/743924598579396687/750497847048142868/cleaner.bat", fileName);
			webClient.Proxy = null;
			Process process = new Process();
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = false;
			process.StartInfo.FileName = "C:\\Windows\\Temp\\cleaner.bat";
			process.Start();
			process.WaitForExit();
			File.Delete("C:\\Windows\\Temp\\cleaner.bat");
			Thread.Sleep(600);
			Console.Write("Finished Cleaning!");
			Thread.Sleep(1000);
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x00016610 File Offset: 0x00014810
		private void button4_Click(object sender, EventArgs e)
		{
			bool flag = File.Exists("C:\\Program Files (x86)\\Steam\\steamapps\\common\\Rust\\EasyAntiCheat\\Launcher\\SplashScreen.png");
			if (flag)
			{
				WebClient webClient = new WebClient();
				webClient.DownloadFile("https://cdn.discordapp.com/attachments/741106895766552668/751203791570862170/SplashScreen.png", "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Rust\\EasyAntiCheat\\Launcher\\SplashScreen.png");
			}
			string text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			char[] array = new char[3];
			Random random = new Random();
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = text[random.Next(text.Length)];
			}
			string text2 = "Naive-" + random.Next(10000, 99999).ToString();
			Process.Start("cmd.exe", "/c wmic useraccount where caption='" + text2 + "' rename " + text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName", "ComputerName", text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName", "ComputerName", text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\services\\Tcpip\\Parameters", "NV Hostname", text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\services\\Tcpip\\Parameters", "Hostname", text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "RegisteredOwner", text2);
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "RegisteredOrganization", text2);
		}
	}
}
