﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Impure.Object_Classes;
using Impure.Overlay;
using Impure.Properties;
using LogIn_Theme_Dll_By_xVenoxi;
using MDriver.MEME;
using MetroFramework.Controls;
using theme;

namespace Impure.tttttt
{
	// Token: 0x0200006F RID: 111
	public partial class TestCHET : Form
	{
		// Token: 0x060001BE RID: 446 RVA: 0x00002EEF File Offset: 0x000010EF
		public TestCHET()
		{
			this.InitializeComponent();
			this.timer1.Start();
		}

		// Token: 0x060001BF RID: 447 RVA: 0x00017C78 File Offset: 0x00015E78
		private void timer1_Tick(object sender, EventArgs e)
		{
			Random random = new Random();
			int alpha = random.Next(0, 255);
			int red = random.Next(0, 255);
			int green = random.Next(0, 255);
			int blue = random.Next(0, 255);
			this.logInLabel3.ForeColor = Color.FromArgb(alpha, red, green, blue);
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x00017CD8 File Offset: 0x00015ED8
		private void TestCHET_Load(object sender, EventArgs e)
		{
			for (;;)
			{
				Process[] processesByName = Process.GetProcessesByName("RustClient");
				bool flag = processesByName.Length != 0;
				if (flag)
				{
					break;
				}
				Thread.Sleep(3000);
			}
			bigbrain.LoadMemory("RustClient");
			while (bigbrain.Memory.GetModuleBase(0) == 0UL || bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base) == 0UL)
			{
				Thread.Sleep(1000);
			}
			UnityFunctions.UnityPlayer_Address = bigbrain.Memory.GetModuleBase(0);
			UnityFunctions.BaseNetworkable = bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base);
			TestCHET.Overlay = new DRAW();
			TestCHET.Overlay.Initialize();
			TestCHET.Renderer = new Render();
			TestCHET.ObjectUpdater = new GameMem();
			TestCHET.Gamer = new Aimbot();
			TestCHET.LocalClass = new Local();
			Thread thread = new Thread(new ThreadStart(TestCHET.ObjectUpdater.UpdateEntityList));
			thread.Start();
			thread.IsBackground = true;
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x000024D7 File Offset: 0x000006D7
		private void logInProgressBar1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x000024D7 File Offset: 0x000006D7
		private void timer2_Tick(object sender, EventArgs e)
		{
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x00002F13 File Offset: 0x00001113
		private void logInCheckBox1_CheckedChanged(object sender)
		{
			Options.CB_Aimbot = !Options.CB_Aimbot;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00002F23 File Offset: 0x00001123
		private void logInCheckBox5_CheckedChanged(object sender)
		{
			Options.CB_RecoilScale = !Options.CB_RecoilScale;
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x00002F33 File Offset: 0x00001133
		private void metroTrackBar1_Scroll(object sender, ScrollEventArgs e)
		{
			Options.RecoilScale = (float)this.metroTrackBar1.Value;
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x00017DF4 File Offset: 0x00015FF4
		private void flatComboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool flag = this.flatComboBox1.SelectedIndex == 0;
			if (flag)
			{
				Aimbot.AimBone = 49;
				Aimbot.AimBone = 49;
			}
			bool flag2 = this.flatComboBox1.SelectedIndex == 1;
			if (flag2)
			{
				Aimbot.AimBone = 47;
				Aimbot.AimBone = 47;
			}
			bool flag3 = this.flatComboBox1.SelectedIndex == 2;
			if (flag3)
			{
				Aimbot.AimBone = 80;
				Aimbot.AimBone = 80;
			}
			bool flag4 = this.flatComboBox1.SelectedIndex != 3;
			if (!flag4)
			{
				Aimbot.AimBone = 21;
				Aimbot.AimBone = 21;
			}
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x00002F47 File Offset: 0x00001147
		private void logInCheckBox7_CheckedChanged(object sender)
		{
			Options.FOVChangerr = !Options.FOVChangerr;
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x00002F57 File Offset: 0x00001157
		private void logInCheckBox8_CheckedChanged(object sender)
		{
			Options.CB_Aimbot_Nodes = !Options.CB_Aimbot_Nodes;
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x00002F67 File Offset: 0x00001167
		private void logInCheckBox6_CheckedChanged(object sender)
		{
			Options.FOVCircle = !Options.FOVCircle;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x000024D7 File Offset: 0x000006D7
		private void logInCheckBox10_CheckedChanged(object sender)
		{
		}

		// Token: 0x060001CB RID: 459 RVA: 0x00002F77 File Offset: 0x00001177
		private void logInCheckBox2_CheckedChanged(object sender)
		{
			Options.CB_ESP_Players = !Options.CB_ESP_Players;
		}

		// Token: 0x060001CC RID: 460 RVA: 0x000024DA File Offset: 0x000006DA
		private void logInCheckBox9_CheckedChanged(object sender)
		{
			Options.CB_ESP_Bones = !Options.CB_ESP_Bones;
		}

		// Token: 0x060001CD RID: 461 RVA: 0x00002F87 File Offset: 0x00001187
		private void logInCheckBox10_CheckedChanged_1(object sender)
		{
			Options.CB_ESP_Sleepers = !Options.CB_ESP_Sleepers;
		}

		// Token: 0x060001CE RID: 462 RVA: 0x00002F97 File Offset: 0x00001197
		private void logInCheckBox11_CheckedChanged(object sender)
		{
			Options.tracers = !Options.tracers;
		}

		// Token: 0x060001CF RID: 463 RVA: 0x00002FA7 File Offset: 0x000011A7
		private void logInCheckBox3_CheckedChanged(object sender)
		{
			Options.CB_Spooder = !Options.CB_Spooder;
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x00017E90 File Offset: 0x00016090
		private void logInCheckBox12_CheckedChanged(object sender)
		{
			Requests memory = bigbrain.Memory;
			ulong[] array = new ulong[2];
			array[0] = Local.LocalPlayer._ComponentAddress + Offsets.BasePlayer.movement;
			ulong pointer = memory.GetPointer(array);
			bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.gravityMultiplier, 1.5f, false);
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x00002FB7 File Offset: 0x000011B7
		private void logInCheckBox13_CheckedChanged(object sender)
		{
			Options.slidewalk = !Options.slidewalk;
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00002FC7 File Offset: 0x000011C7
		private void logInCheckBox14_CheckedChanged(object sender)
		{
			Options.walkkkwater2 = !Options.walkkkwater2;
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00002FD7 File Offset: 0x000011D7
		private void logInCheckBox15_CheckedChanged(object sender)
		{
			Options.CB_Debug = !Options.CB_Debug;
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x00002FE7 File Offset: 0x000011E7
		private void logInCheckBox16_CheckedChanged(object sender)
		{
			Options.lolll = !Options.lolll;
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00002FF7 File Offset: 0x000011F7
		private void logInCheckBox17_CheckedChanged(object sender)
		{
			Options.sprintaim = !Options.sprintaim;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x00003007 File Offset: 0x00001207
		private void logInCheckBox4_CheckedChanged(object sender)
		{
			Options.CB_ESP_Sulfur = !Options.CB_ESP_Sulfur;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00003017 File Offset: 0x00001217
		private void logInCheckBox19_CheckedChanged(object sender)
		{
			Options.CB_ESP_Stone = !Options.CB_ESP_Stone;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x00003027 File Offset: 0x00001227
		private void logInCheckBox18_CheckedChanged(object sender)
		{
			Options.CB_ESP_Metal = !Options.CB_ESP_Metal;
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x00003037 File Offset: 0x00001237
		private void logInCheckBox28_CheckedChanged(object sender)
		{
			Options.CB_ESP_DroppedGuns = !Options.CB_ESP_DroppedGuns;
		}

		// Token: 0x060001DA RID: 474 RVA: 0x00003047 File Offset: 0x00001247
		private void logInCheckBox27_CheckedChanged(object sender)
		{
			Options.CB_ESP_DroppedItems = !Options.CB_ESP_DroppedItems;
		}

		// Token: 0x060001DB RID: 475 RVA: 0x00003057 File Offset: 0x00001257
		private void logInCheckBox26_CheckedChanged(object sender)
		{
			Options.CB_ESP_Traps = !Options.CB_ESP_Traps;
			Options.CB_ESP_Heli = !Options.CB_ESP_Heli;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x00003074 File Offset: 0x00001274
		private void logInCheckBox34_CheckedChanged(object sender)
		{
			Options.CB_ESP_Stashes = !Options.CB_ESP_Stashes;
		}

		// Token: 0x060001DD RID: 477 RVA: 0x00003084 File Offset: 0x00001284
		private void logInCheckBox33_CheckedChanged(object sender)
		{
			Options.CB_ESP_Vehicles = true;
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000308D File Offset: 0x0000128D
		private void logInCheckBox32_CheckedChanged(object sender)
		{
			Options.CB_ESP_Vehicles = !Options.CB_ESP_Vehicles;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000309D File Offset: 0x0000129D
		private void logInCheckBox20_CheckedChanged(object sender)
		{
			Options.CB_ESP_Bags = !Options.CB_ESP_Bags;
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x000030AD File Offset: 0x000012AD
		private void logInCheckBox21_CheckedChanged(object sender)
		{
			Options.CB_ESP_Hemp = !Options.CB_ESP_Hemp;
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x000030BD File Offset: 0x000012BD
		private void logInCheckBox22_CheckedChanged(object sender)
		{
			Options.CB_ESP_Food = !Options.CB_ESP_Food;
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x000030CD File Offset: 0x000012CD
		private void logInCheckBox25_CheckedChanged(object sender)
		{
			Options.tc = !Options.tc;
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x000030DD File Offset: 0x000012DD
		private void logInCheckBox24_CheckedChanged(object sender)
		{
			Options.CB_ESP_LowLoot = !Options.CB_ESP_LowLoot;
			Options.CB_ESP_HighLoot = !Options.CB_ESP_HighLoot;
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x000030FA File Offset: 0x000012FA
		private void logInCheckBox23_CheckedChanged(object sender)
		{
			Options.CB_ESP_Animals = !Options.CB_ESP_Animals;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x000024D7 File Offset: 0x000006D7
		private void panel4_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x0400052A RID: 1322
		public static GameMem ObjectUpdater;

		// Token: 0x0400052B RID: 1323
		public static DRAW Overlay;

		// Token: 0x0400052C RID: 1324
		public static Local LocalClass;

		// Token: 0x0400052D RID: 1325
		public static Render Renderer;

		// Token: 0x0400052E RID: 1326
		public static Aimbot Gamer;
	}
}
