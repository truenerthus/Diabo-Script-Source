﻿namespace Impure.tttttt
{
	// Token: 0x0200006D RID: 109
	public partial class Loader : global::System.Windows.Forms.Form
	{
		// Token: 0x060001A8 RID: 424 RVA: 0x00016734 File Offset: 0x00014934
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0001676C File Offset: 0x0001496C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.tttttt.Loader));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.button3 = new global::System.Windows.Forms.Button();
			this.button1 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.button4 = new global::System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel1.BackgroundImage");
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(651, 151);
			this.panel1.TabIndex = 6;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(52, 133);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(163, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "NaiveCheats - Loader";
			this.button3.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button3.FlatAppearance.BorderSize = 0;
			this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button3.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button3.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button3.Location = new global::System.Drawing.Point(0, 151);
			this.button3.Name = "button3";
			this.button3.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button3.Size = new global::System.Drawing.Size(651, 45);
			this.button3.TabIndex = 7;
			this.button3.Text = "Load Driver";
			this.button3.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.button1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button1.Location = new global::System.Drawing.Point(0, 196);
			this.button1.Name = "button1";
			this.button1.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button1.Size = new global::System.Drawing.Size(651, 45);
			this.button1.TabIndex = 8;
			this.button1.Text = "Inject";
			this.button1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button2.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button2.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button2.Location = new global::System.Drawing.Point(0, 241);
			this.button2.Name = "button2";
			this.button2.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button2.Size = new global::System.Drawing.Size(651, 45);
			this.button2.TabIndex = 9;
			this.button2.Text = "Cleaner";
			this.button2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.button4.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button4.FlatAppearance.BorderSize = 0;
			this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button4.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button4.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button4.Location = new global::System.Drawing.Point(0, 286);
			this.button4.Name = "button4";
			this.button4.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button4.Size = new global::System.Drawing.Size(651, 45);
			this.button4.TabIndex = 10;
			this.button4.Text = "Spoofer";
			this.button4.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			base.ClientSize = new global::System.Drawing.Size(651, 470);
			base.Controls.Add(this.button4);
			base.Controls.Add(this.button2);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.button3);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Loader";
			this.Text = "Loader";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x04000511 RID: 1297
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000512 RID: 1298
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000513 RID: 1299
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000514 RID: 1300
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04000515 RID: 1301
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000516 RID: 1302
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04000517 RID: 1303
		private global::System.Windows.Forms.Button button4;
	}
}
