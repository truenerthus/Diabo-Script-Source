﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Impure.tttttt
{
	// Token: 0x0200006E RID: 110
	public partial class Form1 : Form
	{
		// Token: 0x060001AA RID: 426 RVA: 0x00002E69 File Offset: 0x00001069
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x060001AB RID: 427 RVA: 0x000024D7 File Offset: 0x000006D7
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x060001AC RID: 428
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x060001AD RID: 429
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x060001AE RID: 430 RVA: 0x00002E88 File Offset: 0x00001088
		private void panel1_MouseDown(object sender, MouseEventArgs e)
		{
			Form1.ReleaseCapture();
			Form1.SendMessage(base.Handle, 161, 2, 0);
		}

		// Token: 0x060001AF RID: 431 RVA: 0x00016E50 File Offset: 0x00015050
		private void openChildForm(Form childForm)
		{
			bool flag = this.activeForm != null;
			if (flag)
			{
				this.activeForm.Close();
			}
			this.activeForm = childForm;
			childForm.TopLevel = false;
			childForm.FormBorderStyle = FormBorderStyle.None;
			childForm.Dock = DockStyle.Fill;
			this.panelChildForm.Controls.Add(childForm);
			this.panelChildForm.Tag = childForm;
			childForm.BringToFront();
			childForm.Show();
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x000024D7 File Offset: 0x000006D7
		private void button1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x000024D7 File Offset: 0x000006D7
		private void panel4_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x000024D7 File Offset: 0x000006D7
		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x00002EA4 File Offset: 0x000010A4
		private void button2_Click(object sender, EventArgs e)
		{
			this.openChildForm(new Home());
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x000024D7 File Offset: 0x000006D7
		private void panel5_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x00002EB3 File Offset: 0x000010B3
		private void button3_Click(object sender, EventArgs e)
		{
			this.openChildForm(new Info());
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x000024D7 File Offset: 0x000006D7
		private void button6_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x000024D7 File Offset: 0x000006D7
		private void panelChildForm_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x000024D7 File Offset: 0x000006D7
		private void label1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x00002EC2 File Offset: 0x000010C2
		private void button5_Click(object sender, EventArgs e)
		{
			this.openChildForm(new Perfom());
		}

		// Token: 0x060001BA RID: 442 RVA: 0x00002ED1 File Offset: 0x000010D1
		private void button4_Click(object sender, EventArgs e)
		{
			this.openChildForm(new Cheats());
		}

		// Token: 0x060001BB RID: 443 RVA: 0x00002EE0 File Offset: 0x000010E0
		private void button1_Click_1(object sender, EventArgs e)
		{
			this.openChildForm(new Loader());
		}

		// Token: 0x04000518 RID: 1304
		public const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04000519 RID: 1305
		public const int HT_CAPTION = 2;

		// Token: 0x0400051A RID: 1306
		private Form activeForm = null;
	}
}
