﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Impure.tttttt
{
	// Token: 0x0200006C RID: 108
	public partial class Info : Form
	{
		// Token: 0x060001A0 RID: 416 RVA: 0x00002E26 File Offset: 0x00001026
		public Info()
		{
			this.InitializeComponent();
		}
	}
}
