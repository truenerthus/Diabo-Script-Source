﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Impure.tttttt
{
	// Token: 0x0200006B RID: 107
	public partial class Cheats : Form
	{
		// Token: 0x0600019B RID: 411 RVA: 0x00002DEA File Offset: 0x00000FEA
		public Cheats()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600019C RID: 412 RVA: 0x000024D7 File Offset: 0x000006D7
		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600019D RID: 413 RVA: 0x00002E02 File Offset: 0x00001002
		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Sorry We Are Not Ready Yet, We Are Still In Development Join Our Discord Instead.");
			Thread.Sleep(2000);
			Process.Start("https://discord.gg/gFqtDkU");
		}
	}
}
