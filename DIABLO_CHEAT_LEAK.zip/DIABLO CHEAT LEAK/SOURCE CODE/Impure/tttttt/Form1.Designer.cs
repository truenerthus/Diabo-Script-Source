﻿namespace Impure.tttttt
{
	// Token: 0x0200006E RID: 110
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x060001BC RID: 444 RVA: 0x00016EC4 File Offset: 0x000150C4
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00016EFC File Offset: 0x000150FC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.tttttt.Form1));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.panel4 = new global::System.Windows.Forms.Panel();
			this.button5 = new global::System.Windows.Forms.Button();
			this.button4 = new global::System.Windows.Forms.Button();
			this.button1 = new global::System.Windows.Forms.Button();
			this.button3 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.panel6 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.panel3 = new global::System.Windows.Forms.Panel();
			this.panelChildForm = new global::System.Windows.Forms.Panel();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panelChildForm.SuspendLayout();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.FromArgb(61, 72, 85);
			this.panel1.Controls.Add(this.panel4);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new global::System.Drawing.Point(0, 32);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(185, 462);
			this.panel1.TabIndex = 0;
			this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			this.panel4.BackColor = global::System.Drawing.Color.FromArgb(61, 72, 85);
			this.panel4.Controls.Add(this.button5);
			this.panel4.Controls.Add(this.button4);
			this.panel4.Controls.Add(this.button1);
			this.panel4.Controls.Add(this.button3);
			this.panel4.Controls.Add(this.button2);
			this.panel4.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel4.Location = new global::System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new global::System.Drawing.Size(185, 462);
			this.panel4.TabIndex = 0;
			this.panel4.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
			this.button5.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.None;
			this.button5.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button5.FlatAppearance.BorderSize = 0;
			this.button5.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button5.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button5.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button5.Location = new global::System.Drawing.Point(0, 180);
			this.button5.Name = "button5";
			this.button5.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button5.Size = new global::System.Drawing.Size(185, 45);
			this.button5.TabIndex = 5;
			this.button5.Text = "Performance Settings";
			this.button5.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new global::System.EventHandler(this.button5_Click);
			this.button4.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button4.FlatAppearance.BorderSize = 0;
			this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button4.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button4.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button4.Location = new global::System.Drawing.Point(0, 135);
			this.button4.Name = "button4";
			this.button4.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button4.Size = new global::System.Drawing.Size(185, 45);
			this.button4.TabIndex = 4;
			this.button4.Text = "Cheats";
			this.button4.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			this.button1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button1.Location = new global::System.Drawing.Point(0, 90);
			this.button1.Name = "button1";
			this.button1.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button1.Size = new global::System.Drawing.Size(185, 45);
			this.button1.TabIndex = 3;
			this.button1.Text = "Loader";
			this.button1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click_1);
			this.button3.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button3.FlatAppearance.BorderSize = 0;
			this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button3.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.button3.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button3.Location = new global::System.Drawing.Point(0, 45);
			this.button3.Name = "button3";
			this.button3.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button3.Size = new global::System.Drawing.Size(185, 45);
			this.button3.TabIndex = 2;
			this.button3.Text = "Info";
			this.button3.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.button2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Center;
			this.button2.Cursor = global::System.Windows.Forms.Cursors.Arrow;
			this.button2.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button2.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.button2.Location = new global::System.Drawing.Point(0, 0);
			this.button2.Name = "button2";
			this.button2.Padding = new global::System.Windows.Forms.Padding(15, 0, 0, 0);
			this.button2.Size = new global::System.Drawing.Size(185, 45);
			this.button2.TabIndex = 0;
			this.button2.Text = "HOME";
			this.button2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.panel2.BackColor = global::System.Drawing.Color.FromArgb(61, 72, 85);
			this.panel2.Controls.Add(this.panel6);
			this.panel2.Controls.Add(this.panel3);
			this.panel2.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new global::System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(800, 32);
			this.panel2.TabIndex = 1;
			this.panel6.BackColor = global::System.Drawing.Color.FromArgb(61, 72, 85);
			this.panel6.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel6.BackgroundImage");
			this.panel6.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel6.Controls.Add(this.label1);
			this.panel6.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel6.Location = new global::System.Drawing.Point(0, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new global::System.Drawing.Size(800, 32);
			this.panel6.TabIndex = 1;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(422, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(100, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "NaiveCheats";
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.panel3.Location = new global::System.Drawing.Point(0, 32);
			this.panel3.Name = "panel3";
			this.panel3.Size = new global::System.Drawing.Size(129, 459);
			this.panel3.TabIndex = 0;
			this.panelChildForm.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panelChildForm.BackgroundImage");
			this.panelChildForm.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panelChildForm.Controls.Add(this.label3);
			this.panelChildForm.Controls.Add(this.label2);
			this.panelChildForm.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.panelChildForm.Location = new global::System.Drawing.Point(191, 32);
			this.panelChildForm.Name = "panelChildForm";
			this.panelChildForm.Size = new global::System.Drawing.Size(609, 462);
			this.panelChildForm.TabIndex = 2;
			this.panelChildForm.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panelChildForm_Paint);
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label3.ForeColor = global::System.Drawing.SystemColors.HighlightText;
			this.label3.Location = new global::System.Drawing.Point(249, 193);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(114, 18);
			this.label3.TabIndex = 5;
			this.label3.Text = "NAIVE CHEATS";
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.ForeColor = global::System.Drawing.Color.Green;
			this.label2.Location = new global::System.Drawing.Point(258, 220);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(94, 18);
			this.label2.TabIndex = 4;
			this.label2.Text = "Undetected";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			base.ClientSize = new global::System.Drawing.Size(800, 494);
			base.Controls.Add(this.panelChildForm);
			base.Controls.Add(this.panel1);
			base.Controls.Add(this.panel2);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Form1";
			this.Text = "Form1";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel6.PerformLayout();
			this.panelChildForm.ResumeLayout(false);
			this.panelChildForm.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x0400051B RID: 1307
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x0400051C RID: 1308
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x0400051D RID: 1309
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x0400051E RID: 1310
		private global::System.Windows.Forms.Panel panel4;

		// Token: 0x0400051F RID: 1311
		private global::System.Windows.Forms.Panel panel3;

		// Token: 0x04000520 RID: 1312
		private global::System.Windows.Forms.Button button2;

		// Token: 0x04000521 RID: 1313
		private global::System.Windows.Forms.Button button4;

		// Token: 0x04000522 RID: 1314
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000523 RID: 1315
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04000524 RID: 1316
		private global::System.Windows.Forms.Panel panel6;

		// Token: 0x04000525 RID: 1317
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000526 RID: 1318
		private global::System.Windows.Forms.Button button5;

		// Token: 0x04000527 RID: 1319
		private global::System.Windows.Forms.Panel panelChildForm;

		// Token: 0x04000528 RID: 1320
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000529 RID: 1321
		private global::System.Windows.Forms.Label label2;
	}
}
