﻿using System;
using System.Runtime.InteropServices;

namespace Impure.GameStuff
{
	// Token: 0x02000073 RID: 115
	internal class Vanguard
	{
		// Token: 0x060001F7 RID: 503
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		public static extern bool Login();

		// Token: 0x060001F8 RID: 504
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		public static extern bool Logout();

		// Token: 0x060001F9 RID: 505
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		public static extern bool Inject(string modName, bool _ignore_ = false);

		// Token: 0x060001FA RID: 506
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		private static extern IntPtr GetUsername();

		// Token: 0x060001FB RID: 507
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		private static extern IntPtr GetModuleList();

		// Token: 0x060001FC RID: 508
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		private static extern IntPtr GetStatus();

		// Token: 0x060001FD RID: 509
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		private static extern IntPtr GetLastLog();

		// Token: 0x060001FE RID: 510
		[DllImport("vanguard.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		private static extern IntPtr GetLoadLibraryPath();

		// Token: 0x060001FF RID: 511 RVA: 0x00002699 File Offset: 0x00000899
		private Vanguard()
		{
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0001B914 File Offset: 0x00019B14
		public static string Username()
		{
			return Marshal.PtrToStringAnsi(Vanguard.GetUsername());
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0001B930 File Offset: 0x00019B30
		public static string[] Modules()
		{
			string text = Marshal.PtrToStringAnsi(Vanguard.GetModuleList());
			return text.Split(new string[]
			{
				"##"
			}, StringSplitOptions.None);
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0001B964 File Offset: 0x00019B64
		public static string Status()
		{
			return Marshal.PtrToStringAnsi(Vanguard.GetStatus());
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0001B980 File Offset: 0x00019B80
		public static string LastLog()
		{
			return Marshal.PtrToStringAnsi(Vanguard.GetLastLog());
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0001B99C File Offset: 0x00019B9C
		public static string LoadLibraryPath()
		{
			return Marshal.PtrToStringAnsi(Vanguard.GetLoadLibraryPath());
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0001B9B8 File Offset: 0x00019BB8
		public static bool InjectModule(string module)
		{
			return Vanguard.Inject(module, false);
		}

		// Token: 0x06000206 RID: 518 RVA: 0x0001B9B8 File Offset: 0x00019BB8
		public static bool InjectLL(string module, string _useless_)
		{
			return Vanguard.Inject(module, false);
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0001B9B8 File Offset: 0x00019BB8
		public static bool InjectProxy(string module, string _useless_)
		{
			return Vanguard.Inject(module, false);
		}
	}
}
