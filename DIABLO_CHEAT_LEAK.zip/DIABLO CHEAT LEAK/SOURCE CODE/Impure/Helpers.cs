﻿using System;
using System.Linq;

namespace Impure
{
	// Token: 0x02000017 RID: 23
	public class Helpers
	{
		// Token: 0x060000A2 RID: 162 RVA: 0x00006308 File Offset: 0x00004508
		public static string RandomString(int length)
		{
			return new string((from s in Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", length)
			select s[Helpers.Rnd.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x04000053 RID: 83
		public static readonly Random Rnd = new Random();
	}
}
