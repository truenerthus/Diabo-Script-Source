﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Impure.Properties
{
	// Token: 0x0200001D RID: 29
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x060000BB RID: 187 RVA: 0x00002699 File Offset: 0x00000899
		internal Resources()
		{
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000BC RID: 188 RVA: 0x000065D4 File Offset: 0x000047D4
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager resourceManager = new ResourceManager("Impure.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000BD RID: 189 RVA: 0x0000661C File Offset: 0x0000481C
		// (set) Token: 0x060000BE RID: 190 RVA: 0x000026A3 File Offset: 0x000008A3
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00006634 File Offset: 0x00004834
		internal static Bitmap lol
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("lol", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x04000070 RID: 112
		private static ResourceManager resourceMan;

		// Token: 0x04000071 RID: 113
		private static CultureInfo resourceCulture;
	}
}
