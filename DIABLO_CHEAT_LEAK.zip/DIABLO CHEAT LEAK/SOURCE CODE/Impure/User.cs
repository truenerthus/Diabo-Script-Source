﻿using System;

namespace Impure
{
	// Token: 0x02000006 RID: 6
	internal class User
	{
		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000017 RID: 23 RVA: 0x00002293 File Offset: 0x00000493
		// (set) Token: 0x06000018 RID: 24 RVA: 0x0000229A File Offset: 0x0000049A
		public static string ID { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000019 RID: 25 RVA: 0x000022A2 File Offset: 0x000004A2
		// (set) Token: 0x0600001A RID: 26 RVA: 0x000022A9 File Offset: 0x000004A9
		public static string Username { get; set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600001B RID: 27 RVA: 0x000022B1 File Offset: 0x000004B1
		// (set) Token: 0x0600001C RID: 28 RVA: 0x000022B8 File Offset: 0x000004B8
		public static string Password { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600001D RID: 29 RVA: 0x000022C0 File Offset: 0x000004C0
		// (set) Token: 0x0600001E RID: 30 RVA: 0x000022C7 File Offset: 0x000004C7
		public static string Email { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001F RID: 31 RVA: 0x000022CF File Offset: 0x000004CF
		// (set) Token: 0x06000020 RID: 32 RVA: 0x000022D6 File Offset: 0x000004D6
		public static string HWID { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000021 RID: 33 RVA: 0x000022DE File Offset: 0x000004DE
		// (set) Token: 0x06000022 RID: 34 RVA: 0x000022E5 File Offset: 0x000004E5
		public static string IP { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000023 RID: 35 RVA: 0x000022ED File Offset: 0x000004ED
		// (set) Token: 0x06000024 RID: 36 RVA: 0x000022F4 File Offset: 0x000004F4
		public static string UserVariable { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000025 RID: 37 RVA: 0x000022FC File Offset: 0x000004FC
		// (set) Token: 0x06000026 RID: 38 RVA: 0x00002303 File Offset: 0x00000503
		public static string Rank { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000027 RID: 39 RVA: 0x0000230B File Offset: 0x0000050B
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00002312 File Offset: 0x00000512
		public static string Expiry { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000029 RID: 41 RVA: 0x0000231A File Offset: 0x0000051A
		// (set) Token: 0x0600002A RID: 42 RVA: 0x00002321 File Offset: 0x00000521
		public static string LastLogin { get; set; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600002B RID: 43 RVA: 0x00002329 File Offset: 0x00000529
		// (set) Token: 0x0600002C RID: 44 RVA: 0x00002330 File Offset: 0x00000530
		public static string RegisterDate { get; set; }
	}
}
