﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Impure.Securityyy
{
	// Token: 0x02000071 RID: 113
	public partial class Form1 : Form
	{
		// Token: 0x060001EE RID: 494 RVA: 0x0000310A File Offset: 0x0000130A
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x000024D7 File Offset: 0x000006D7
		private void Form1_Load(object sender, EventArgs e)
		{
		}
	}
}
