﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace Impure.Securityyy
{
	// Token: 0x02000072 RID: 114
	internal class Scanner
	{
		// Token: 0x060001F2 RID: 498 RVA: 0x0001B510 File Offset: 0x00019710
		public static void ScanAndKill()
		{
			bool flag = Scanner.Scan(true) != 0;
			if (flag)
			{
				MessageBox.Show("Debugger Found Please Close!!!");
				Console.Beep(30000, 50000);
			}
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0001B548 File Offset: 0x00019748
		private static int Scan(bool KillProcess)
		{
			int result = 0;
			bool flag = Scanner.BadProcessnameList.Count == 0 && Scanner.BadWindowTextList.Count == 0;
			if (flag)
			{
				Scanner.Init();
			}
			Process[] processes = Process.GetProcesses();
			foreach (Process process in processes)
			{
				bool flag2 = Scanner.BadProcessnameList.Contains(process.ProcessName) || Scanner.BadWindowTextList.Contains(process.MainWindowTitle);
				if (flag2)
				{
					Console.ForegroundColor = ConsoleColor.Red;
					MessageBox.Show("BAD PROCESS FOUND: " + process.ProcessName);
					result = 1;
					if (KillProcess)
					{
						try
						{
							process.Kill();
						}
						catch (Win32Exception ex)
						{
							MessageBox.Show("Win32Exception: " + ex.Message);
						}
						catch (NotSupportedException ex2)
						{
							MessageBox.Show("NotSupportedException: " + ex2.Message);
						}
						catch (InvalidOperationException ex3)
						{
							MessageBox.Show("InvalidOperationException: " + ex3.Message);
						}
					}
					break;
				}
			}
			return result;
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0001B698 File Offset: 0x00019898
		private static int Init()
		{
			bool flag = Scanner.BadProcessnameList.Count > 0 && Scanner.BadWindowTextList.Count > 0;
			int result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				Scanner.BadProcessnameList.Add("ollydbg");
				Scanner.BadProcessnameList.Add("ida");
				Scanner.BadProcessnameList.Add("ida64");
				Scanner.BadProcessnameList.Add("idag");
				Scanner.BadProcessnameList.Add("idag64");
				Scanner.BadProcessnameList.Add("idaw");
				Scanner.BadProcessnameList.Add("idaw64");
				Scanner.BadProcessnameList.Add("idaq");
				Scanner.BadProcessnameList.Add("idaq64");
				Scanner.BadProcessnameList.Add("idau");
				Scanner.BadProcessnameList.Add("idau64");
				Scanner.BadProcessnameList.Add("scylla");
				Scanner.BadProcessnameList.Add("scylla_x64");
				Scanner.BadProcessnameList.Add("scylla_x86");
				Scanner.BadProcessnameList.Add("protection_id");
				Scanner.BadProcessnameList.Add("x64dbg");
				Scanner.BadProcessnameList.Add("x32dbg");
				Scanner.BadProcessnameList.Add("windbg");
				Scanner.BadProcessnameList.Add("reshacker");
				Scanner.BadProcessnameList.Add("ImportREC");
				Scanner.BadProcessnameList.Add("IMMUNITYDEBUGGER");
				Scanner.BadProcessnameList.Add("MegaDumper");
				Scanner.BadWindowTextList.Add("OLLYDBG");
				Scanner.BadWindowTextList.Add("ida");
				Scanner.BadWindowTextList.Add("disassembly");
				Scanner.BadWindowTextList.Add("scylla");
				Scanner.BadWindowTextList.Add("Debug");
				Scanner.BadWindowTextList.Add("[CPU");
				Scanner.BadWindowTextList.Add("Immunity");
				Scanner.BadWindowTextList.Add("WinDbg");
				Scanner.BadWindowTextList.Add("DnSpy");
				Scanner.BadWindowTextList.Add("x32dbg");
				Scanner.BadWindowTextList.Add("x64dbg");
				Scanner.BadWindowTextList.Add("Import reconstructor");
				Scanner.BadWindowTextList.Add("MegaDumper");
				Scanner.BadWindowTextList.Add("MegaDumper 1.0 by CodeCracker / SnD");
				result = 0;
			}
			return result;
		}

		// Token: 0x04000564 RID: 1380
		private static HashSet<string> BadProcessnameList = new HashSet<string>();

		// Token: 0x04000565 RID: 1381
		private static HashSet<string> BadWindowTextList = new HashSet<string>();
	}
}
