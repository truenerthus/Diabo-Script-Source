﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Impure.Securityyy
{
	// Token: 0x02000070 RID: 112
	internal class DumpProt
	{
		// Token: 0x060001E8 RID: 488
		[DllImport("kernel32.dll")]
		private static extern IntPtr ZeroMemory(IntPtr addr, IntPtr size);

		// Token: 0x060001E9 RID: 489
		[DllImport("kernel32.dll")]
		private static extern IntPtr VirtualProtect(IntPtr lpAddress, IntPtr dwSize, IntPtr flNewProtect, ref IntPtr lpflOldProtect);

		// Token: 0x060001EA RID: 490 RVA: 0x0001B154 File Offset: 0x00019354
		private static void EraseSection(IntPtr address, int size)
		{
			IntPtr intPtr = (IntPtr)size;
			IntPtr flNewProtect = 0;
			DumpProt.VirtualProtect(address, intPtr, (IntPtr)64, ref flNewProtect);
			DumpProt.ZeroMemory(address, intPtr);
			IntPtr intPtr2 = 0;
			DumpProt.VirtualProtect(address, intPtr, flNewProtect, ref intPtr2);
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0001B1A0 File Offset: 0x000193A0
		public static void AntiDump()
		{
			Process currentProcess = Process.GetCurrentProcess();
			IntPtr baseAddress = currentProcess.MainModule.BaseAddress;
			int num = Marshal.ReadInt32((IntPtr)(baseAddress.ToInt32() + 60));
			short num2 = Marshal.ReadInt16((IntPtr)(baseAddress.ToInt32() + num + 6));
			DumpProt.EraseSection(baseAddress, 30);
			for (int i = 0; i < DumpProt.peheaderdwords.Length; i++)
			{
				DumpProt.EraseSection((IntPtr)(baseAddress.ToInt32() + num + DumpProt.peheaderdwords[i]), 4);
			}
			for (int j = 0; j < DumpProt.peheaderwords.Length; j++)
			{
				DumpProt.EraseSection((IntPtr)(baseAddress.ToInt32() + num + DumpProt.peheaderwords[j]), 2);
			}
			for (int k = 0; k < DumpProt.peheaderbytes.Length; k++)
			{
				DumpProt.EraseSection((IntPtr)(baseAddress.ToInt32() + num + DumpProt.peheaderbytes[k]), 1);
			}
			int l = 0;
			int num3 = 0;
			while (l <= (int)num2)
			{
				bool flag = num3 == 0;
				if (flag)
				{
					DumpProt.EraseSection((IntPtr)(baseAddress.ToInt32() + num + 250 + 40 * l + 32), 2);
				}
				DumpProt.EraseSection((IntPtr)(baseAddress.ToInt32() + num + 250 + 40 * l + DumpProt.sectiontabledwords[num3]), 4);
				num3++;
				bool flag2 = num3 == DumpProt.sectiontabledwords.Length;
				if (flag2)
				{
					l++;
					num3 = 0;
				}
			}
		}

		// Token: 0x0400055E RID: 1374
		private static int[] sectiontabledwords = new int[]
		{
			8,
			12,
			16,
			20,
			24,
			28,
			36
		};

		// Token: 0x0400055F RID: 1375
		private static int[] peheaderbytes = new int[]
		{
			26,
			27
		};

		// Token: 0x04000560 RID: 1376
		private static int[] peheaderwords = new int[]
		{
			4,
			22,
			24,
			64,
			66,
			68,
			70,
			72,
			74,
			76,
			92,
			94
		};

		// Token: 0x04000561 RID: 1377
		private static int[] peheaderdwords = new int[]
		{
			0,
			8,
			12,
			16,
			22,
			28,
			32,
			40,
			44,
			52,
			60,
			76,
			80,
			84,
			88,
			96,
			100,
			104,
			108,
			112,
			116,
			260,
			264,
			268,
			272,
			276,
			284
		};
	}
}
