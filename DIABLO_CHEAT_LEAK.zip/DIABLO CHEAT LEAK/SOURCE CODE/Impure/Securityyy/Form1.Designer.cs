﻿namespace Impure.Securityyy
{
	// Token: 0x02000071 RID: 113
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x060001F0 RID: 496 RVA: 0x0001B3A8 File Offset: 0x000195A8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0001B3E0 File Offset: 0x000195E0
		private void InitializeComponent()
		{
			this.label1 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.Location = new global::System.Drawing.Point(119, 9);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(326, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "INFORMATION CHEAT HAS BEEN DISCONNECTED";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(559, 166);
			base.Controls.Add(this.label1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Form1";
			this.Text = "Form1";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000562 RID: 1378
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000563 RID: 1379
		private global::System.Windows.Forms.Label label1;
	}
}
