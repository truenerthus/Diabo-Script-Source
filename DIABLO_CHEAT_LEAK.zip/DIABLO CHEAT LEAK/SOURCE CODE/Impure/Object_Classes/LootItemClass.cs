﻿using System;
using GameOverlay.Drawing;
using Impure.Overlay;
using MDriver.MEME;

namespace Impure.Object_Classes
{
	// Token: 0x0200003A RID: 58
	public class LootItemClass
	{
		// Token: 0x06000127 RID: 295 RVA: 0x00013A14 File Offset: 0x00011C14
		public LootItemClass(ulong address)
		{
			this._gameObjectAddress = address;
			Requests memory = bigbrain.Memory;
			ulong[] array = new ulong[4];
			array[0] = this._gameObjectAddress + 48UL;
			array[1] = 24UL;
			array[2] = 40UL;
			this._ComponentAddress = memory.GetPointer(array);
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000128 RID: 296 RVA: 0x00013ABC File Offset: 0x00011CBC
		// (set) Token: 0x06000129 RID: 297 RVA: 0x00002ADC File Offset: 0x00000CDC
		public ulong TransformAddress
		{
			get
			{
				bool flag = this._TransformAddress != 0UL && this.Type != LootItemClass.LootType.Ore_Bonus && this.Type != LootItemClass.LootType.Animal && this.Type != LootItemClass.LootType.PatrolHeli;
				ulong transformAddress;
				if (flag)
				{
					transformAddress = this._TransformAddress;
				}
				else
				{
					Requests memory = bigbrain.Memory;
					ulong[] array = new ulong[]
					{
						0UL,
						8UL,
						56UL,
						144UL
					};
					array[0] = this._gameObjectAddress + 48UL;
					this._TransformAddress = memory.GetPointer(array);
					transformAddress = this._TransformAddress;
				}
				return transformAddress;
			}
			set
			{
				this._TransformAddress = value;
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600012A RID: 298 RVA: 0x00013B3C File Offset: 0x00011D3C
		// (set) Token: 0x0600012B RID: 299 RVA: 0x00002AE6 File Offset: 0x00000CE6
		public Requests.Vector3.Vector3f Position
		{
			get
			{
				bool flag = this._Position == Requests.Vector3.Vector3f.Zero || this.Type == LootItemClass.LootType.Brad || this.Type == LootItemClass.LootType.PatrolHeli || this.Type == LootItemClass.LootType.Vehicle || this.Type == LootItemClass.LootType.Animal || this.Type == LootItemClass.LootType.Ore_Bonus;
				if (flag)
				{
					this._Position = bigbrain.Memory.ReadVector3f(this.TransformAddress);
				}
				return this._Position;
			}
			set
			{
				this._Position = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600012C RID: 300 RVA: 0x00013BB4 File Offset: 0x00011DB4
		// (set) Token: 0x0600012D RID: 301 RVA: 0x000024D7 File Offset: 0x000006D7
		public string GameObjectName
		{
			get
			{
				bool flag = this._gameobjectname != "";
				string gameobjectname;
				if (flag)
				{
					gameobjectname = this._gameobjectname;
				}
				else
				{
					this._gameobjectname = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(this._gameObjectAddress + 96UL), 128, false);
					bool flag2 = this._gameobjectname.Contains("/");
					if (flag2)
					{
						this._gameobjectname = this._gameobjectname.Substring(this._gameobjectname.LastIndexOf("/") + 1);
					}
					gameobjectname = this._gameobjectname;
				}
				return gameobjectname;
			}
			set
			{
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600012E RID: 302 RVA: 0x00013C50 File Offset: 0x00011E50
		// (set) Token: 0x0600012F RID: 303 RVA: 0x00002AF0 File Offset: 0x00000CF0
		public string GameObjectNameCleaned
		{
			get
			{
				bool flag = this._gameobjectnamecleaned != "";
				string result;
				if (flag)
				{
					result = this._gameobjectnamecleaned;
				}
				else
				{
					bool flag2 = this.GameObjectName.Length <= 1;
					if (flag2)
					{
						result = "INVALID";
					}
					else
					{
						this._gameobjectnamecleaned = this.GameObjectName;
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace(".prefab", "");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace(".entity", "");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace(".deployed", "");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace(" (world)", "");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("-", "");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("_", " ");
						this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace(".", " ");
						bool flag3 = this.Type == LootItemClass.LootType.Vehicle;
						if (flag3)
						{
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("testridablehorse", "Rideable Horse");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("scraptransporthelicopter", "Scrap Heli");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rowboat", "Boat");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rhib", "Rhib");
						}
						bool flag4 = this.Type == LootItemClass.LootType.Weapon;
						if (flag4)
						{
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("smg 2", "Custom SMG");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("shotgun waterpipe", "Water Pipe");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("smg thompson", "Tommy");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle ak", "AK47");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle bolt", "Bolt Rifle");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol python", "Python");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol revolver", "Revolver");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rocket launcher", "Rocket Launcher");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol semiauto", "P2");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle semiauto", "SAR");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle m39", "M39");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol m92", "M92");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("smg mp5", "MP5");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol nailgun", "Nail Gun");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("shotgun double", "Double-Barrel Shotgun");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("pistol eoka", "Eoka");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle l96", "L96");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("rifle lr300", "lr300");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("lmg m249", "M249");
							this._gameobjectnamecleaned = this._gameobjectnamecleaned.Replace("shotgun pump", "Pump shotgun");
						}
						this._gameobjectnamecleaned = char.ToUpper(this._gameobjectnamecleaned[0]).ToString() + this._gameobjectnamecleaned.Substring(1);
						result = this._gameobjectnamecleaned;
					}
				}
				return result;
			}
			set
			{
				this._gameobjectnamecleaned = value;
			}
		}

		// Token: 0x040001B6 RID: 438
		public ulong _ComponentAddress = 0UL;

		// Token: 0x040001B7 RID: 439
		public ulong _gameObjectAddress = 0UL;

		// Token: 0x040001B8 RID: 440
		public ulong _TransformAddress = 0UL;

		// Token: 0x040001B9 RID: 441
		public Requests.Vector3.Vector3f _Position = Requests.Vector3.Vector3f.Zero;

		// Token: 0x040001BA RID: 442
		public bool GC = false;

		// Token: 0x040001BB RID: 443
		private string _gameobjectname = "";

		// Token: 0x040001BC RID: 444
		private string _gameobjectnamecleaned = "";

		// Token: 0x040001BD RID: 445
		public LootItemClass.LootType Type = LootItemClass.LootType.NULL;

		// Token: 0x040001BE RID: 446
		public SolidBrush Color = DRAW.Electric_Cyan;

		// Token: 0x040001BF RID: 447
		public float Render_Distance = 250f;

		// Token: 0x0200003B RID: 59
		public enum LootType
		{
			// Token: 0x040001C1 RID: 449
			NULL,
			// Token: 0x040001C2 RID: 450
			PatrolHeli,
			// Token: 0x040001C3 RID: 451
			Brad,
			// Token: 0x040001C4 RID: 452
			Corpse,
			// Token: 0x040001C5 RID: 453
			Hemp,
			// Token: 0x040001C6 RID: 454
			Food,
			// Token: 0x040001C7 RID: 455
			Barrel,
			// Token: 0x040001C8 RID: 456
			Vehicle,
			// Token: 0x040001C9 RID: 457
			Stash,
			// Token: 0x040001CA RID: 458
			Ores,
			// Token: 0x040001CB RID: 459
			Ore_Bonus,
			// Token: 0x040001CC RID: 460
			Trap,
			// Token: 0x040001CD RID: 461
			AutoTurret,
			// Token: 0x040001CE RID: 462
			Weapon,
			// Token: 0x040001CF RID: 463
			Ammo,
			// Token: 0x040001D0 RID: 464
			TC,
			// Token: 0x040001D1 RID: 465
			World,
			// Token: 0x040001D2 RID: 466
			Loot_Basic,
			// Token: 0x040001D3 RID: 467
			Loot_Elite,
			// Token: 0x040001D4 RID: 468
			Animal,
			// Token: 0x040001D5 RID: 469
			Explosion,
			// Token: 0x040001D6 RID: 470
			Electrical,
			// Token: 0x040001D7 RID: 471
			SupplyDrop,
			// Token: 0x040001D8 RID: 472
			ShipWreck
		}
	}
}
