﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using Impure.Overlay;
using MDriver.MEME;

namespace Impure.Object_Classes
{
	// Token: 0x02000026 RID: 38
	public class Local
	{
		// Token: 0x060000FC RID: 252
		[DllImport("user32.dll")]
		public static extern int GetKeyState(int vKey);

		// Token: 0x060000FD RID: 253 RVA: 0x000114F0 File Offset: 0x0000F6F0
		public void Fast_Thread()
		{
			for (;;)
			{
				bool flag = Local.LocalPlayer != null;
				if (flag)
				{
					int keyState = Local.GetKeyState(90);
					bool flag2 = (keyState & 32768) != 0;
					if (flag2)
					{
						bool flag3 = this.tap;
						if (flag3)
						{
							this.tap = false;
							Options.CB_wateWrite = !Options.CB_wateWrite;
						}
					}
					else
					{
						this.tap = true;
					}
					bool cb_Debug = Options.CB_Debug;
					if (cb_Debug)
					{
						bigbrain.Memory.WriteInt32(Local.LocalPlayer._ComponentAddress + Offsets.BasePlayer.playerFlags, 260, false);
					}
					bool cb_Spooder = Options.CB_Spooder;
					if (cb_Spooder)
					{
						Requests memory = bigbrain.Memory;
						ulong[] array = new ulong[2];
						array[0] = Local.LocalPlayer._ComponentAddress + Offsets.BasePlayer.movement;
						ulong pointer = memory.GetPointer(array);
						bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.groundAngle, 0f, false);
						bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.groundAngleNew, 0f, false);
						bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.maxAngleClimbing, 999f, false);
						bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.maxAngleWalking, 999f, false);
						bigbrain.Memory.WriteFloat(pointer + Offsets.PlayerWalkMovement.groundTime, 1E+14f, false);
					}
				}
				Thread.Sleep(1);
			}
		}

		// Token: 0x060000FE RID: 254 RVA: 0x00011648 File Offset: 0x0000F848
		public void Slow_Thread()
		{
			bool flag = Local.LocalPlayer != null;
			if (!flag)
			{
				return;
			}
			string text = "ASS";
			for (;;)
			{
				try
				{
					string heldItem = Local.LocalPlayer.HeldItem;
					bool flag2 = Options.CB_ExtendedMelee && (Local.LocalPlayer.HeldWeaponCategory == 0 || Local.LocalPlayer.HeldWeaponCategory == 5);
					if (flag2)
					{
						bool flag3 = heldItem == "bone.club";
						if (flag3)
						{
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseMelee.maxDistance
							}), 3f, false);
						}
						else
						{
							bool flag4 = heldItem == "knife.bone";
							if (flag4)
							{
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseMelee.maxDistance
								}), 3f, false);
							}
							else
							{
								bool flag5 = heldItem == "knife.butcher";
								if (flag5)
								{
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseMelee.maxDistance
									}), 3f, false);
								}
								else
								{
									bool flag6 = heldItem == "candycaneclub";
									if (flag6)
									{
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseMelee.maxDistance
										}), 3.2f, false);
									}
									else
									{
										bool flag7 = heldItem == "knife.combat";
										if (flag7)
										{
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseMelee.maxDistance
											}), 3f, false);
										}
										else
										{
											bool flag8 = heldItem == "longsword";
											if (flag8)
											{
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseMelee.maxDistance
												}), 3f, false);
											}
											else
											{
												bool flag9 = heldItem == "mace";
												if (flag9)
												{
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseMelee.maxDistance
													}), 3f, false);
												}
												else
												{
													bool flag10 = heldItem == "machete";
													if (flag10)
													{
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseMelee.maxDistance
														}), 3f, false);
													}
													else
													{
														bool flag11 = heldItem == "pitchfork";
														if (flag11)
														{
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseMelee.maxDistance
															}), 5.5f, false);
														}
														else
														{
															bool flag12 = heldItem == "salvaged.cleaver";
															if (flag12)
															{
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseMelee.maxDistance
																}), 3f, false);
															}
															else
															{
																bool flag13 = heldItem == "salvaged.sword";
																if (flag13)
																{
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseMelee.maxDistance
																	}), 3f, false);
																}
																else
																{
																	bool flag14 = heldItem == "spear.stone";
																	if (flag14)
																	{
																		bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																		{
																			Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																			Offsets.BaseMelee.maxDistance
																		}), 5.5f, false);
																	}
																	else
																	{
																		bool flag15 = heldItem == "spear.wooden";
																		if (flag15)
																		{
																			bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																			{
																				Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																				Offsets.BaseMelee.maxDistance
																			}), 5.2f, false);
																		}
																		else
																		{
																			bool flag16 = heldItem == "chainsaw";
																			if (flag16)
																			{
																				bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																				{
																					Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																					Offsets.BaseMelee.maxDistance
																				}), 5.5f, false);
																			}
																			else
																			{
																				bool flag17 = heldItem == "hatchet";
																				if (flag17)
																				{
																					bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																					{
																						Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																						Offsets.BaseMelee.maxDistance
																					}), 5.5f, false);
																				}
																				else
																				{
																					bool flag18 = heldItem == "hatchet";
																					if (flag18)
																					{
																						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																						{
																							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																							Offsets.BaseMelee.attackRadius,
																							Offsets.BaseMelee.maxDistance
																						}), 5.5f, false);
																					}
																					else
																					{
																						bool flag19 = heldItem == "jackhammer";
																						if (flag19)
																						{
																							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																							{
																								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																								Offsets.BaseMelee.maxDistance
																							}), 5.5f, false);
																						}
																						else
																						{
																							bool flag20 = heldItem == "pickaxe";
																							if (flag20)
																							{
																								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																								{
																									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																									Offsets.BaseMelee.attackRadius,
																									Offsets.BaseMelee.maxDistance
																								}), 5.5f, false);
																							}
																							else
																							{
																								bool flag21 = heldItem == "rock";
																								if (flag21)
																								{
																									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																									{
																										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																										Offsets.BaseMelee.attackRadius,
																										Offsets.BaseMelee.maxDistance
																									}), 5.5f, false);
																								}
																								else
																								{
																									bool flag22 = heldItem == "axe.salvaged";
																									if (flag22)
																									{
																										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																										{
																											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																											Offsets.BaseMelee.maxDistance
																										}), 5.5f, false);
																									}
																									else
																									{
																										bool flag23 = heldItem == "hammer.salvaged";
																										if (flag23)
																										{
																											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																											{
																												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																												Offsets.BaseMelee.maxDistance
																											}), 3f, false);
																										}
																										else
																										{
																											bool flag24 = heldItem == "icepick.salvaged";
																											if (flag24)
																											{
																												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																												{
																													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																													Offsets.BaseMelee.maxDistance
																												}), 3f, false);
																											}
																											else
																											{
																												bool flag25 = heldItem == "stonehatchet";
																												if (flag25)
																												{
																													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																													{
																														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																														Offsets.BaseMelee.maxDistance
																													}), 5.5f, false);
																												}
																												else
																												{
																													bool flag26 = heldItem == "stone.pickaxe";
																													if (flag26)
																													{
																														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																														{
																															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																															Offsets.BaseMelee.maxDistance
																														}), 5.5f, false);
																													}
																													else
																													{
																														bool flag27 = heldItem == "torch";
																														if (flag27)
																														{
																															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																															{
																																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																																Offsets.BaseMelee.maxDistance
																															}), 5.5f, false);
																														}
																														else
																														{
																															bool flag28 = heldItem == "medical.";
																															if (flag28)
																															{
																																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																																{
																																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																																	Offsets.BaseMelee.attackRadius,
																																	Offsets.BaseMelee.maxDistance
																																}), 5.5f, false);
																															}
																															else
																															{
																																bool flag29 = heldItem == "band";
																																if (flag29)
																																{
																																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																																	{
																																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																																		Offsets.BaseMelee.attackRadius,
																																		Offsets.BaseMelee.maxDistance
																																	}), 5.5f, false);
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					bool flag30 = Options.CB_RecoilScale && Local.LocalPlayer.HeldWeaponCategory == 0 && !heldItem.Contains("flame");
					if (flag30)
					{
						bool flag31 = Local.LocalPlayer.HeldWeapon != 0UL && Local.LocalPlayer.HeldItem != "";
						if (flag31)
						{
							ulong heldWeapon = Local.LocalPlayer.HeldWeapon;
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimSway
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.stancePenalty
							}), -1f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimconePenalty
							}), -1f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimSwaySpeed
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimCone
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimConePenaltyMax
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimconePenaltyRecoverTime
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimconePenaltyRecoverDelay
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.stancePenaltyScale
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.hipAimCone
							}), 0f, false);
							bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
							{
								Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
								Offsets.BaseProjectile.aimconePenaltyPerShot
							}), 0f, false);
							bool flag32 = heldItem == "rifle.ak";
							if (flag32)
							{
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilPitchMax
								}), Local.rifleak.recoilPitchMax * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilPitchMin
								}), Local.rifleak.recoilPitchMin * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilYawMax
								}), Local.rifleak.recoilYawMax * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilYawMin
								}), Local.rifleak.recoilYawMin * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.movementPenalty
								}), 0f, false);
							}
							bool flag33 = heldItem == "lmg.m249";
							if (flag33)
							{
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilPitchMax
								}), Local.lmgm249.recoilPitchMax * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilPitchMin
								}), Local.lmgm249.recoilPitchMin * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilYawMax
								}), Local.lmgm249.recoilYawMax * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.recoilYawMin
								}), Local.lmgm249.recoilYawMin * (Options.RecoilScale / 1000f), false);
								bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
								{
									Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
									Offsets.BaseProjectile.recoil,
									Offsets.RecoilProperties.movementPenalty
								}), 0f, false);
							}
							else
							{
								bool flag34 = heldItem == "pistol.nailgun";
								if (flag34)
								{
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseProjectile.recoil,
										Offsets.RecoilProperties.recoilPitchMax
									}), Local.pistolnailgun.recoilPitchMax * (Options.RecoilScale / 1000f), false);
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseProjectile.recoil,
										Offsets.RecoilProperties.recoilPitchMin
									}), Local.pistolnailgun.recoilPitchMin * (Options.RecoilScale / 1000f), false);
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseProjectile.recoil,
										Offsets.RecoilProperties.recoilYawMax
									}), Local.pistolnailgun.recoilYawMax * (Options.RecoilScale / 1000f), false);
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseProjectile.recoil,
										Offsets.RecoilProperties.recoilYawMin
									}), Local.pistolnailgun.recoilYawMin * (Options.RecoilScale / 1000f), false);
									bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
									{
										Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
										Offsets.BaseProjectile.recoil,
										Offsets.RecoilProperties.movementPenalty
									}), 0f, false);
								}
								else
								{
									bool flag35 = heldItem == "rifle.m39";
									if (flag35)
									{
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseProjectile.recoil,
											Offsets.RecoilProperties.recoilPitchMax
										}), Local.riflem39.recoilPitchMax * (Options.RecoilScale / 1000f), false);
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseProjectile.recoil,
											Offsets.RecoilProperties.recoilPitchMin
										}), Local.riflem39.recoilPitchMin * (Options.RecoilScale / 1000f), false);
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseProjectile.recoil,
											Offsets.RecoilProperties.recoilYawMax
										}), Local.riflem39.recoilYawMax * (Options.RecoilScale / 1000f), false);
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseProjectile.recoil,
											Offsets.RecoilProperties.recoilYawMin
										}), Local.riflem39.recoilYawMin * (Options.RecoilScale / 1000f), false);
										bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
										{
											Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
											Offsets.BaseProjectile.recoil,
											Offsets.RecoilProperties.movementPenalty
										}), 0f, false);
									}
									else
									{
										bool flag36 = heldItem == "rifle.lr300";
										if (flag36)
										{
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseProjectile.recoil,
												Offsets.RecoilProperties.recoilPitchMax
											}), Local.riflelr300.recoilPitchMax * (Options.RecoilScale / 1000f), false);
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseProjectile.recoil,
												Offsets.RecoilProperties.recoilPitchMin
											}), Local.riflelr300.recoilPitchMin * (Options.RecoilScale / 1000f), false);
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseProjectile.recoil,
												Offsets.RecoilProperties.recoilYawMax
											}), Local.riflelr300.recoilYawMax * (Options.RecoilScale / 1000f), false);
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseProjectile.recoil,
												Offsets.RecoilProperties.recoilYawMin
											}), Local.riflelr300.recoilYawMin * (Options.RecoilScale / 1000f), false);
											bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
											{
												Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
												Offsets.BaseProjectile.recoil,
												Offsets.RecoilProperties.movementPenalty
											}), 0f, false);
										}
										else
										{
											bool flag37 = heldItem == "rifle.semiauto";
											if (flag37)
											{
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseProjectile.recoil,
													Offsets.RecoilProperties.recoilPitchMax
												}), Local.riflesemiauto.recoilPitchMax * (Options.RecoilScale / 1000f), false);
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseProjectile.recoil,
													Offsets.RecoilProperties.recoilPitchMin
												}), Local.riflesemiauto.recoilPitchMin * (Options.RecoilScale / 1000f), false);
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseProjectile.recoil,
													Offsets.RecoilProperties.recoilYawMax
												}), Local.riflesemiauto.recoilYawMax * (Options.RecoilScale / 1000f), false);
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseProjectile.recoil,
													Offsets.RecoilProperties.recoilYawMin
												}), Local.riflesemiauto.recoilYawMin * (Options.RecoilScale / 1000f), false);
												bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
												{
													Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
													Offsets.BaseProjectile.recoil,
													Offsets.RecoilProperties.movementPenalty
												}), 0f, false);
											}
											else
											{
												bool flag38 = heldItem == "smg.2";
												if (flag38)
												{
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseProjectile.recoil,
														Offsets.RecoilProperties.recoilPitchMax
													}), Local.smg2.recoilPitchMax * (Options.RecoilScale / 1000f), false);
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseProjectile.recoil,
														Offsets.RecoilProperties.recoilPitchMin
													}), Local.smg2.recoilPitchMin * (Options.RecoilScale / 1000f), false);
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseProjectile.recoil,
														Offsets.RecoilProperties.recoilYawMax
													}), Local.smg2.recoilYawMax * (Options.RecoilScale / 1000f), false);
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseProjectile.recoil,
														Offsets.RecoilProperties.recoilYawMin
													}), Local.smg2.recoilYawMin * (Options.RecoilScale / 1000f), false);
													bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
													{
														Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
														Offsets.BaseProjectile.recoil,
														Offsets.RecoilProperties.movementPenalty
													}), 0f, false);
												}
												else
												{
													bool flag39 = heldItem == "smg.thompson";
													if (flag39)
													{
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseProjectile.recoil,
															Offsets.RecoilProperties.recoilPitchMax
														}), Local.smgthompson.recoilPitchMax * (Options.RecoilScale / 1000f), false);
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseProjectile.recoil,
															Offsets.RecoilProperties.recoilPitchMin
														}), Local.smgthompson.recoilPitchMin * (Options.RecoilScale / 1000f), false);
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseProjectile.recoil,
															Offsets.RecoilProperties.recoilYawMax
														}), Local.smgthompson.recoilYawMax * (Options.RecoilScale / 1000f), false);
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseProjectile.recoil,
															Offsets.RecoilProperties.recoilYawMin
														}), Local.smgthompson.recoilYawMin * (Options.RecoilScale / 1000f), false);
														bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
														{
															Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
															Offsets.BaseProjectile.recoil,
															Offsets.RecoilProperties.movementPenalty
														}), 0f, false);
													}
													else
													{
														bool flag40 = heldItem == "smg.mp5";
														if (flag40)
														{
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseProjectile.recoil,
																Offsets.RecoilProperties.recoilPitchMax
															}), Local.smgmp5.recoilPitchMax * (Options.RecoilScale / 1000f), false);
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseProjectile.recoil,
																Offsets.RecoilProperties.recoilPitchMin
															}), Local.smgmp5.recoilPitchMin * (Options.RecoilScale / 1000f), false);
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseProjectile.recoil,
																Offsets.RecoilProperties.recoilYawMax
															}), Local.smgmp5.recoilYawMax * (Options.RecoilScale / 1000f), false);
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseProjectile.recoil,
																Offsets.RecoilProperties.recoilYawMin
															}), Local.smgmp5.recoilYawMin * (Options.RecoilScale / 1000f), false);
															bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
															{
																Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																Offsets.BaseProjectile.recoil,
																Offsets.RecoilProperties.movementPenalty
															}), 0f, false);
														}
														else
														{
															bool flag41 = heldItem == "pistol.revolver";
															if (flag41)
															{
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseProjectile.recoil,
																	Offsets.RecoilProperties.recoilPitchMax
																}), Local.pistolrevolver.recoilPitchMax * (Options.RecoilScale / 1000f), false);
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseProjectile.recoil,
																	Offsets.RecoilProperties.recoilPitchMin
																}), Local.pistolrevolver.recoilPitchMin * (Options.RecoilScale / 1000f), false);
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseProjectile.recoil,
																	Offsets.RecoilProperties.recoilYawMax
																}), Local.pistolrevolver.recoilYawMax * (Options.RecoilScale / 1000f), false);
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseProjectile.recoil,
																	Offsets.RecoilProperties.recoilYawMin
																}), Local.pistolrevolver.recoilYawMin * (Options.RecoilScale / 1000f), false);
																bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																{
																	Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																	Offsets.BaseProjectile.recoil,
																	Offsets.RecoilProperties.movementPenalty
																}), 0f, false);
															}
															else
															{
																bool flag42 = heldItem == "pistol.python";
																if (flag42)
																{
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseProjectile.recoil,
																		Offsets.RecoilProperties.recoilPitchMax
																	}), Local.pistolpython.recoilPitchMax * (Options.RecoilScale / 1000f), false);
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseProjectile.recoil,
																		Offsets.RecoilProperties.recoilPitchMin
																	}), Local.pistolpython.recoilPitchMin * (Options.RecoilScale / 1000f), false);
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseProjectile.recoil,
																		Offsets.RecoilProperties.recoilYawMax
																	}), Local.pistolpython.recoilYawMax * (Options.RecoilScale / 1000f), false);
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseProjectile.recoil,
																		Offsets.RecoilProperties.recoilYawMin
																	}), Local.pistolpython.recoilYawMin * (Options.RecoilScale / 1000f), false);
																	bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
																	{
																		Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
																		Offsets.BaseProjectile.recoil,
																		Offsets.RecoilProperties.movementPenalty
																	}), 0f, false);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					bool flag43 = Options.CB_Eoka && Local.LocalPlayer.HeldItem == "pistol.eoka";
					if (flag43)
					{
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.FlintStrikeWeapon.successFraction
						}), 999f, true);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimSway
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.stancePenalty
						}), -1f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimconePenalty
						}), -1f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimSwaySpeed
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimCone
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimConePenaltyMax
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimconePenaltyRecoverTime
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimconePenaltyRecoverDelay
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.stancePenaltyScale
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.hipAimCone
						}), 0f, false);
						bigbrain.Memory.WriteFloat(bigbrain.Memory.GetPointer(new ulong[]
						{
							Local.LocalPlayer.HeldWeapon + Offsets.HeldEntity.BaseProjectile,
							Offsets.BaseProjectile.aimconePenaltyPerShot
						}), 0f, false);
					}
					bool flag44 = text != Local.LocalPlayer.HeldItem;
					if (flag44)
					{
						text = Local.LocalPlayer.HeldItem;
						bool flag45 = text.Contains("pistol.nailgun");
						if (flag45)
						{
							Aimbot.DickDrop = Aimbot.NailDrop;
							Aimbot.Horizontal_Factor = 5f;
						}
						else
						{
							bool flag46 = text.Contains("rifle.m39");
							if (flag46)
							{
								Aimbot.DickDrop = Aimbot.M39Drop;
								Aimbot.Horizontal_Factor = 375f;
							}
							else
							{
								bool flag47 = text.Contains("rifle.l96");
								if (flag47)
								{
									Aimbot.DickDrop = Aimbot.RifleDrop;
									Aimbot.Horizontal_Factor = 65f;
								}
								else
								{
									bool flag48 = text.Contains("rifle.bolt");
									if (flag48)
									{
										Aimbot.DickDrop = Aimbot.RifleDrop;
										Aimbot.Horizontal_Factor = 60f;
									}
									else
									{
										bool flag49 = text.Contains("rifle.semiauto");
										if (flag49)
										{
											Aimbot.DickDrop = Aimbot.RifleDrop;
											Aimbot.Horizontal_Factor = 60f;
										}
										else
										{
											bool flag50 = text.Contains("rifle.");
											if (flag50)
											{
												Aimbot.DickDrop = Aimbot.RifleDrop;
												Aimbot.Horizontal_Factor = 375f;
											}
											else
											{
												bool flag51 = text.Contains("pistol.");
												if (flag51)
												{
													Aimbot.DickDrop = Aimbot.PistolDrop;
													Aimbot.Horizontal_Factor = 26f;
												}
												else
												{
													bool flag52 = text.Contains("bow.hunting");
													if (flag52)
													{
														Aimbot.DickDrop = Aimbot.BowDrop;
														Aimbot.Horizontal_Factor = 60f;
													}
													else
													{
														bool flag53 = text.Contains("crossbow");
														if (flag53)
														{
															Aimbot.DickDrop = Aimbot.CrossyDrop;
															Aimbot.Horizontal_Factor = 8f;
														}
														else
														{
															bool flag54 = text.Contains("smg.");
															if (flag54)
															{
																Aimbot.DickDrop = Aimbot.SMGDrop;
																Aimbot.Horizontal_Factor = 33f;
															}
															else
															{
																bool flag55 = text.Contains("lmg.");
																if (flag55)
																{
																	Aimbot.DickDrop = Aimbot.LMGDrop;
																	Aimbot.Horizontal_Factor = 33f;
																}
																else
																{
																	bool flag56 = text.Contains("shotgun.");
																	if (flag56)
																	{
																		Aimbot.DickDrop = Aimbot.PumpyDrop;
																		Aimbot.Horizontal_Factor = 15f;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x04000154 RID: 340
		public static PlayerClass LocalPlayer = null;

		// Token: 0x04000155 RID: 341
		private bool tap = false;

		// Token: 0x04000156 RID: 342
		private bool shouldoff = false;

		// Token: 0x02000027 RID: 39
		public class rifleak
		{
			// Token: 0x04000157 RID: 343
			public static float recoilPitchMax = -10.14f;

			// Token: 0x04000158 RID: 344
			public static float recoilPitchMin = -1.352f;

			// Token: 0x04000159 RID: 345
			public static float recoilYawMax = 2.704f;

			// Token: 0x0400015A RID: 346
			public static float recoilYawMin = -0.676f;

			// Token: 0x0400015B RID: 347
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x02000028 RID: 40
		public class riflebolt
		{
			// Token: 0x0400015C RID: 348
			public static float recoilPitchMax = -3f;

			// Token: 0x0400015D RID: 349
			public static float recoilPitchMin = -2f;

			// Token: 0x0400015E RID: 350
			public static float recoilYawMax = 4f;

			// Token: 0x0400015F RID: 351
			public static float recoilYawMin = -4f;

			// Token: 0x04000160 RID: 352
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x02000029 RID: 41
		public class smg2
		{
			// Token: 0x04000161 RID: 353
			public static float recoilPitchMax = -15f;

			// Token: 0x04000162 RID: 354
			public static float recoilPitchMin = -2f;

			// Token: 0x04000163 RID: 355
			public static float recoilYawMax = 10f;

			// Token: 0x04000164 RID: 356
			public static float recoilYawMin = -1.5f;

			// Token: 0x04000165 RID: 357
			public static float movementPenalty = 0f;
		}

		// Token: 0x0200002A RID: 42
		public class shotgundouble
		{
			// Token: 0x04000166 RID: 358
			public static float recoilPitchMax = -15f;

			// Token: 0x04000167 RID: 359
			public static float recoilPitchMin = -10f;

			// Token: 0x04000168 RID: 360
			public static float recoilYawMax = 15f;

			// Token: 0x04000169 RID: 361
			public static float recoilYawMin = 8f;

			// Token: 0x0400016A RID: 362
			public static float movementPenalty = 0f;
		}

		// Token: 0x0200002B RID: 43
		public class riflel96
		{
			// Token: 0x0400016B RID: 363
			public static float recoilPitchMax = -1.5f;

			// Token: 0x0400016C RID: 364
			public static float recoilPitchMin = -1f;

			// Token: 0x0400016D RID: 365
			public static float recoilYawMax = 2f;

			// Token: 0x0400016E RID: 366
			public static float recoilYawMin = -2f;

			// Token: 0x0400016F RID: 367
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x0200002C RID: 44
		public class riflelr300
		{
			// Token: 0x04000170 RID: 368
			public static float recoilPitchMax = -12f;

			// Token: 0x04000171 RID: 369
			public static float recoilPitchMin = -2.5f;

			// Token: 0x04000172 RID: 370
			public static float recoilYawMax = 5f;

			// Token: 0x04000173 RID: 371
			public static float recoilYawMin = -1f;

			// Token: 0x04000174 RID: 372
			public static float movementPenalty = 0.2f;
		}

		// Token: 0x0200002D RID: 45
		public class lmgm249
		{
			// Token: 0x04000175 RID: 373
			public static float recoilPitchMax = -6f;

			// Token: 0x04000176 RID: 374
			public static float recoilPitchMin = -5f;

			// Token: 0x04000177 RID: 375
			public static float recoilYawMax = 1f;

			// Token: 0x04000178 RID: 376
			public static float recoilYawMin = -1f;

			// Token: 0x04000179 RID: 377
			public static float movementPenalty = 1.25f;
		}

		// Token: 0x0200002E RID: 46
		public class riflem39
		{
			// Token: 0x0400017A RID: 378
			public static float recoilPitchMax = -7f;

			// Token: 0x0400017B RID: 379
			public static float recoilPitchMin = -5f;

			// Token: 0x0400017C RID: 380
			public static float recoilYawMax = 1.5f;

			// Token: 0x0400017D RID: 381
			public static float recoilYawMin = -1.5f;

			// Token: 0x0400017E RID: 382
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x0200002F RID: 47
		public class pistolm92
		{
			// Token: 0x0400017F RID: 383
			public static float recoilPitchMax = -8f;

			// Token: 0x04000180 RID: 384
			public static float recoilPitchMin = -7f;

			// Token: 0x04000181 RID: 385
			public static float recoilYawMax = 1f;

			// Token: 0x04000182 RID: 386
			public static float recoilYawMin = -1f;

			// Token: 0x04000183 RID: 387
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000030 RID: 48
		public class smgmp5
		{
			// Token: 0x04000184 RID: 388
			public static float recoilPitchMax = -10f;

			// Token: 0x04000185 RID: 389
			public static float recoilPitchMin = -2f;

			// Token: 0x04000186 RID: 390
			public static float recoilYawMax = 6f;

			// Token: 0x04000187 RID: 391
			public static float recoilYawMin = -1.25f;

			// Token: 0x04000188 RID: 392
			public static float movementPenalty = 0.2f;
		}

		// Token: 0x02000031 RID: 49
		public class pistolnailgun
		{
			// Token: 0x04000189 RID: 393
			public static float recoilPitchMax = -6f;

			// Token: 0x0400018A RID: 394
			public static float recoilPitchMin = -3f;

			// Token: 0x0400018B RID: 395
			public static float recoilYawMax = 1f;

			// Token: 0x0400018C RID: 396
			public static float recoilYawMin = -1f;

			// Token: 0x0400018D RID: 397
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000032 RID: 50
		public class shotgunpump
		{
			// Token: 0x0400018E RID: 398
			public static float recoilPitchMax = -14f;

			// Token: 0x0400018F RID: 399
			public static float recoilPitchMin = -10f;

			// Token: 0x04000190 RID: 400
			public static float recoilYawMax = 8f;

			// Token: 0x04000191 RID: 401
			public static float recoilYawMin = 4f;

			// Token: 0x04000192 RID: 402
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000033 RID: 51
		public class pistolpython
		{
			// Token: 0x04000193 RID: 403
			public static float recoilPitchMax = -16f;

			// Token: 0x04000194 RID: 404
			public static float recoilPitchMin = -15f;

			// Token: 0x04000195 RID: 405
			public static float recoilYawMax = 2f;

			// Token: 0x04000196 RID: 406
			public static float recoilYawMin = -2f;

			// Token: 0x04000197 RID: 407
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000034 RID: 52
		public class pistolrevolver
		{
			// Token: 0x04000198 RID: 408
			public static float recoilPitchMax = -6f;

			// Token: 0x04000199 RID: 409
			public static float recoilPitchMin = -3f;

			// Token: 0x0400019A RID: 410
			public static float recoilYawMax = 1f;

			// Token: 0x0400019B RID: 411
			public static float recoilYawMin = -1f;

			// Token: 0x0400019C RID: 412
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000035 RID: 53
		public class pistolsemiauto
		{
			// Token: 0x0400019D RID: 413
			public static float recoilPitchMax = -8f;

			// Token: 0x0400019E RID: 414
			public static float recoilPitchMin = -6f;

			// Token: 0x0400019F RID: 415
			public static float recoilYawMax = 2f;

			// Token: 0x040001A0 RID: 416
			public static float recoilYawMin = -2f;

			// Token: 0x040001A1 RID: 417
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x02000036 RID: 54
		public class riflesemiauto
		{
			// Token: 0x040001A2 RID: 418
			public static float recoilPitchMax = -6f;

			// Token: 0x040001A3 RID: 419
			public static float recoilPitchMin = -5f;

			// Token: 0x040001A4 RID: 420
			public static float recoilYawMax = 1f;

			// Token: 0x040001A5 RID: 421
			public static float recoilYawMin = -1f;

			// Token: 0x040001A6 RID: 422
			public static float movementPenalty = 0.5f;
		}

		// Token: 0x02000037 RID: 55
		public class shotgunspas12
		{
			// Token: 0x040001A7 RID: 423
			public static float recoilPitchMax = -14f;

			// Token: 0x040001A8 RID: 424
			public static float recoilPitchMin = -10f;

			// Token: 0x040001A9 RID: 425
			public static float recoilYawMax = 8f;

			// Token: 0x040001AA RID: 426
			public static float recoilYawMin = 4f;

			// Token: 0x040001AB RID: 427
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000038 RID: 56
		public class smgthompson
		{
			// Token: 0x040001AC RID: 428
			public static float recoilPitchMax = -15f;

			// Token: 0x040001AD RID: 429
			public static float recoilPitchMin = -2f;

			// Token: 0x040001AE RID: 430
			public static float recoilYawMax = 10f;

			// Token: 0x040001AF RID: 431
			public static float recoilYawMin = -1.5f;

			// Token: 0x040001B0 RID: 432
			public static float movementPenalty = 0f;
		}

		// Token: 0x02000039 RID: 57
		public class shotgunwaterpipe
		{
			// Token: 0x040001B1 RID: 433
			public static float recoilPitchMax = -14f;

			// Token: 0x040001B2 RID: 434
			public static float recoilPitchMin = -10f;

			// Token: 0x040001B3 RID: 435
			public static float recoilYawMax = 8f;

			// Token: 0x040001B4 RID: 436
			public static float recoilYawMin = 4f;

			// Token: 0x040001B5 RID: 437
			public static float movementPenalty = 0f;
		}
	}
}
