﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Management;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using Microsoft.VisualBasic.Devices;

namespace Impure.Object_Classes
{
	// Token: 0x02000025 RID: 37
	internal class HWID
	{
		// Token: 0x060000E4 RID: 228 RVA: 0x000105CC File Offset: 0x0000E7CC
		private static string GetHash(string value)
		{
			MD5 md = new MD5CryptoServiceProvider();
			byte[] bytes = Encoding.ASCII.GetBytes(value);
			return HWID.GetHexString(md.ComputeHash(bytes));
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x000105FC File Offset: 0x0000E7FC
		private static string GetHexString(IList<byte> bt)
		{
			string text = string.Empty;
			for (int i = 0; i < bt.Count; i++)
			{
				byte b = bt[i];
				int num = (int)b;
				int num2 = num & 15;
				int num3 = num >> 4 & 15;
				bool flag = num3 > 9;
				if (flag)
				{
					text += ((char)(num3 - 10 + 65)).ToString(CultureInfo.InvariantCulture);
				}
				else
				{
					text += num3.ToString(CultureInfo.InvariantCulture);
				}
				bool flag2 = num2 > 9;
				if (flag2)
				{
					text += ((char)(num2 - 10 + 66)).ToString(CultureInfo.InvariantCulture);
				}
				else
				{
					text += num2.ToString(CultureInfo.InvariantCulture);
				}
			}
			return text;
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x000106CC File Offset: 0x0000E8CC
		public static string Get()
		{
			Computer computer = new Computer();
			string text = string.Empty;
			ManagementClass managementClass = new ManagementClass("win32_processor");
			ManagementObject managementObject = new ManagementObject("win32_logicaldisk.deviceid=\"C:\"");
			ManagementObjectCollection instances = managementClass.GetInstances();
			foreach (ManagementBaseObject managementBaseObject in instances)
			{
				ManagementObject managementObject2 = (ManagementObject)managementBaseObject;
				try
				{
					bool flag = text == "";
					if (flag)
					{
						text = managementObject2.Properties["processorID"].Value.ToString();
						break;
					}
				}
				catch
				{
				}
			}
			managementObject.Get();
			string info_volumeSerial = managementObject["VolumeSerialNumber"].ToString();
			HWID.INFO_cpuInfo = text;
			HWID.INFO_volumeSerial = info_volumeSerial;
			HWID.INFO_TotalPhysicalMemory = computer.Info.TotalPhysicalMemory.ToString();
			HWID.INFO_OSFullName = computer.Info.OSFullName;
			HWID.INFO_Screen_DeviceName = computer.Screen.DeviceName;
			HWID.INFO_Screen_DeviceName = HWID.INFO_Screen_DeviceName.Replace("\\\\.\\", "");
			HWID.INFO_Height = computer.Screen.Bounds.Height.ToString();
			HWID.INFO_Width = computer.Screen.Bounds.Width.ToString();
			HWID.INFO_PrimaryBusType = HWID.PrimaryBusType;
			HWID.INFO_Product = HWID.Product;
			HWID.INFO_PCName = computer.Name;
			HWID.INFO_User = WindowsIdentity.GetCurrent().Name;
			HWID.INFO_User = HWID.INFO_User.Replace(HWID.INFO_PCName + "\\", "");
			return HWID.GetHash(string.Concat(new string[]
			{
				HWID.INFO_cpuInfo,
				HWID.INFO_volumeSerial,
				HWID.INFO_TotalPhysicalMemory,
				HWID.INFO_OSFullName,
				HWID.INFO_Screen_DeviceName,
				HWID.INFO_Height,
				HWID.INFO_Width,
				HWID.INFO_PrimaryBusType,
				HWID.INFO_Product
			}));
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000E7 RID: 231 RVA: 0x000108FC File Offset: 0x0000EAFC
		public static string Availability
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return HWID.GetAvailability(int.Parse(managementObject["Availability"].ToString()));
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x0001098C File Offset: 0x0000EB8C
		public static bool HostingBoard
		{
			get
			{
				bool result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							bool flag = managementObject["HostingBoard"].ToString() == "True";
							if (flag)
							{
								return true;
							}
							return false;
						}
					}
					result = false;
				}
				catch
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x00010A20 File Offset: 0x0000EC20
		public static string InstallDate
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return HWID.ConvertToDateTime(managementObject["InstallDate"].ToString());
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000EA RID: 234 RVA: 0x00010AAC File Offset: 0x0000ECAC
		public static string Manufacturer
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["Manufacturer"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000EB RID: 235 RVA: 0x00010B34 File Offset: 0x0000ED34
		public static string Model
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["Model"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000EC RID: 236 RVA: 0x00010BBC File Offset: 0x0000EDBC
		public static string PartNumber
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["PartNumber"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000ED RID: 237 RVA: 0x00010C44 File Offset: 0x0000EE44
		public static string PNPDeviceID
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["PNPDeviceID"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000EE RID: 238 RVA: 0x00010CCC File Offset: 0x0000EECC
		public static string PrimaryBusType
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["PrimaryBusType"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060000EF RID: 239 RVA: 0x00010D54 File Offset: 0x0000EF54
		public static string Product
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["Product"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x00010DDC File Offset: 0x0000EFDC
		public static bool Removable
		{
			get
			{
				bool result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							bool flag = managementObject["Removable"].ToString() == "True";
							if (flag)
							{
								return true;
							}
							return false;
						}
					}
					result = false;
				}
				catch
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x00010E70 File Offset: 0x0000F070
		public static bool Replaceable
		{
			get
			{
				bool result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							bool flag = managementObject["Replaceable"].ToString() == "True";
							if (flag)
							{
								return true;
							}
							return false;
						}
					}
					result = false;
				}
				catch
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x00010F04 File Offset: 0x0000F104
		public static string RevisionNumber
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["RevisionNumber"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000F3 RID: 243 RVA: 0x00010F8C File Offset: 0x0000F18C
		public static string SecondaryBusType
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["SecondaryBusType"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x00011014 File Offset: 0x0000F214
		public static string SerialNumber
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["SerialNumber"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000F5 RID: 245 RVA: 0x0001109C File Offset: 0x0000F29C
		public static string Status
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["Status"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x00011124 File Offset: 0x0000F324
		public static string SystemName
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.motherboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["SystemName"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x000111AC File Offset: 0x0000F3AC
		public static string Version
		{
			get
			{
				string result;
				try
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = HWID.baseboardSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							return managementObject["Version"].ToString();
						}
					}
					result = "";
				}
				catch
				{
					result = "";
				}
				return result;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x00011234 File Offset: 0x0000F434
		private static string GetAvailability(int availability)
		{
			string result;
			switch (availability)
			{
			case 1:
				result = "Other";
				break;
			case 2:
				result = "Unknown";
				break;
			case 3:
				result = "Running or Full Power";
				break;
			case 4:
				result = "Warning";
				break;
			case 5:
				result = "In Test";
				break;
			case 6:
				result = "Not Applicable";
				break;
			case 7:
				result = "Power Off";
				break;
			case 8:
				result = "Off Line";
				break;
			case 9:
				result = "Off Duty";
				break;
			case 10:
				result = "Degraded";
				break;
			case 11:
				result = "Not Installed";
				break;
			case 12:
				result = "Install Error";
				break;
			case 13:
				result = "Power Save - Unknown";
				break;
			case 14:
				result = "Power Save - Low Power Mode";
				break;
			case 15:
				result = "Power Save - Standby";
				break;
			case 16:
				result = "Power Cycle";
				break;
			case 17:
				result = "Power Save - Warning";
				break;
			default:
				result = "Unknown";
				break;
			}
			return result;
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00011330 File Offset: 0x0000F530
		private static string ConvertToDateTime(string unconvertedTime)
		{
			int num = int.Parse(unconvertedTime.Substring(0, 4));
			int num2 = int.Parse(unconvertedTime.Substring(4, 2));
			int num3 = int.Parse(unconvertedTime.Substring(6, 2));
			int num4 = int.Parse(unconvertedTime.Substring(8, 2));
			int num5 = int.Parse(unconvertedTime.Substring(10, 2));
			int num6 = int.Parse(unconvertedTime.Substring(12, 2));
			string text = "AM";
			bool flag = num4 > 12;
			if (flag)
			{
				num4 -= 12;
				text = "PM";
			}
			return string.Concat(new string[]
			{
				num3.ToString(),
				"/",
				num2.ToString(),
				"/",
				num.ToString(),
				" ",
				num4.ToString(),
				":",
				num5.ToString(),
				":",
				num6.ToString(),
				" ",
				text
			});
		}

		// Token: 0x04000147 RID: 327
		public static string INFO_cpuInfo = "";

		// Token: 0x04000148 RID: 328
		public static string INFO_volumeSerial = "";

		// Token: 0x04000149 RID: 329
		public static string INFO_TotalPhysicalMemory = "";

		// Token: 0x0400014A RID: 330
		public static string INFO_OSFullName = "";

		// Token: 0x0400014B RID: 331
		public static string INFO_Screen_DeviceName = "";

		// Token: 0x0400014C RID: 332
		public static string INFO_Height = "";

		// Token: 0x0400014D RID: 333
		public static string INFO_Width = "";

		// Token: 0x0400014E RID: 334
		public static string INFO_PrimaryBusType = "";

		// Token: 0x0400014F RID: 335
		public static string INFO_Product = "";

		// Token: 0x04000150 RID: 336
		public static string INFO_User = "";

		// Token: 0x04000151 RID: 337
		public static string INFO_PCName = "";

		// Token: 0x04000152 RID: 338
		private static ManagementObjectSearcher baseboardSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");

		// Token: 0x04000153 RID: 339
		private static ManagementObjectSearcher motherboardSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_MotherboardDevice");
	}
}
