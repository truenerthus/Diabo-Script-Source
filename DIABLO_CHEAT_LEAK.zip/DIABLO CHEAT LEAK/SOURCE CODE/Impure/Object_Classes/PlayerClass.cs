﻿using System;
using System.Collections.Generic;
using MDriver.MEME;

namespace Impure.Object_Classes
{
	// Token: 0x0200003D RID: 61
	public class PlayerClass
	{
		// Token: 0x06000134 RID: 308 RVA: 0x00014114 File Offset: 0x00012314
		public PlayerClass(ulong address)
		{
			this._gameObjectAddress = address;
			Requests memory = bigbrain.Memory;
			ulong[] array = new ulong[4];
			array[0] = this._gameObjectAddress + 48UL;
			array[1] = 24UL;
			array[2] = 40UL;
			this._ComponentAddress = memory.GetPointer(array);
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000135 RID: 309 RVA: 0x00014238 File Offset: 0x00012438
		// (set) Token: 0x06000136 RID: 310 RVA: 0x00002AFA File Offset: 0x00000CFA
		public ulong TransformAddress
		{
			get
			{
				bool flag = this._TransformAddress > 0UL;
				ulong transformAddress;
				if (flag)
				{
					transformAddress = this._TransformAddress;
				}
				else
				{
					Requests memory = bigbrain.Memory;
					ulong[] array = new ulong[]
					{
						0UL,
						8UL,
						56UL,
						144UL
					};
					array[0] = this._gameObjectAddress + 48UL;
					this._TransformAddress = memory.GetPointer(array);
					transformAddress = this._TransformAddress;
				}
				return transformAddress;
			}
			set
			{
				this._TransformAddress = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000137 RID: 311 RVA: 0x00014298 File Offset: 0x00012498
		// (set) Token: 0x06000138 RID: 312 RVA: 0x00002B04 File Offset: 0x00000D04
		public Requests.Vector3.Vector3f Position
		{
			get
			{
				this._Position = bigbrain.Memory.ReadVector3f(this.TransformAddress);
				bool flag = this._Position == Requests.Vector3.Vector3f.Zero;
				if (flag)
				{
					this._TransformAddress = 0UL;
					this._Position = bigbrain.Memory.ReadVector3f(this.TransformAddress);
				}
				return this._Position;
			}
			set
			{
				this._Position = value;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000139 RID: 313 RVA: 0x000142FC File Offset: 0x000124FC
		// (set) Token: 0x0600013A RID: 314 RVA: 0x000024D7 File Offset: 0x000006D7
		public string GameObjectName
		{
			get
			{
				bool flag = this._gameobjectname != "";
				string gameobjectname;
				if (flag)
				{
					gameobjectname = this._gameobjectname;
				}
				else
				{
					this._gameobjectname = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(this._gameObjectAddress + 96UL), 128, false);
					this._gameobjectname = this._gameobjectname.Substring(this._gameobjectname.LastIndexOf("/") + 1);
					gameobjectname = this._gameobjectname;
				}
				return gameobjectname;
			}
			set
			{
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600013B RID: 315 RVA: 0x00014380 File Offset: 0x00012580
		// (set) Token: 0x0600013C RID: 316 RVA: 0x00002B0E File Offset: 0x00000D0E
		public string PlayerName
		{
			get
			{
				bool flag = this._playername != "";
				string playername;
				if (flag)
				{
					playername = this._playername;
				}
				else
				{
					ulong num = bigbrain.Memory.ReadInt64(this._ComponentAddress + Offsets.BasePlayer.displayName);
					int num2 = bigbrain.Memory.ReadInt32(num + 16UL);
					this._playername = bigbrain.Memory.ReadString(num + 20UL, num2, true);
					playername = this._playername;
				}
				return playername;
			}
			set
			{
				this._playername = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600013D RID: 317 RVA: 0x000143F8 File Offset: 0x000125F8
		// (set) Token: 0x0600013E RID: 318 RVA: 0x000024D7 File Offset: 0x000006D7
		public string HeldItem
		{
			get
			{
				bool flag = this._helditem != "" && this.LastReadTime.AddSeconds(3.0) > DateTime.Now;
				string helditem;
				if (flag)
				{
					helditem = this._helditem;
				}
				else
				{
					this._helditem = "";
					this.LastReadTime = DateTime.Now;
					int num = bigbrain.Memory.ReadInt32(this._ComponentAddress + Offsets.BasePlayer.clActiveItem);
					for (ulong num2 = 0UL; num2 <= 9UL; num2 += 1UL)
					{
						ulong num3 = bigbrain.Memory.ReadInt64(bigbrain.Memory.GetPointer(new ulong[]
						{
							this._ComponentAddress + Offsets.BasePlayer.inventory,
							Offsets.PlayerInventory.containerBelt,
							Offsets.itemList,
							Offsets.list,
							Offsets.index + 8UL * num2
						}));
						int num4 = bigbrain.Memory.ReadInt32(bigbrain.Memory.GetPointer(new ulong[]
						{
							num3 + Offsets.Item.info,
							Offsets.ItemDefinition.shortname,
							Offsets.m_stringLength
						}));
						bool flag2 = num4 > 0 && num4 < 32;
						if (flag2)
						{
							string helditem2 = bigbrain.Memory.ReadString(bigbrain.Memory.GetPointer(new ulong[]
							{
								num3 + Offsets.Item.info,
								Offsets.ItemDefinition.shortname,
								Offsets.m_firstChar
							}), num4, true);
							int heldWeaponCategory = bigbrain.Memory.ReadInt32(bigbrain.Memory.GetPointer(new ulong[]
							{
								num3 + Offsets.Item.info,
								Offsets.ItemDefinition.category
							}));
							bool flag3 = bigbrain.Memory.ReadInt32(num3 + Offsets.Item.uid) == num && num > 0;
							if (flag3)
							{
								this.HeldWeapon = num3;
								this.HeldWeaponCategory = heldWeaponCategory;
								this._helditem = helditem2;
							}
						}
					}
					helditem = this._helditem;
				}
				return helditem;
			}
			set
			{
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600013F RID: 319 RVA: 0x000145E8 File Offset: 0x000127E8
		// (set) Token: 0x06000140 RID: 320 RVA: 0x00002B18 File Offset: 0x00000D18
		public bool IsVisable
		{
			get
			{
				ulong num = bigbrain.Memory.ReadInt64(this._ComponentAddress + Offsets.BasePlayer.playerModel);
				return bigbrain.Memory.ReadInt16(num + Offsets.PlayerModel.visible) > 0;
			}
			set
			{
				this._visible = value;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000141 RID: 321 RVA: 0x00014628 File Offset: 0x00012828
		// (set) Token: 0x06000142 RID: 322 RVA: 0x00002B18 File Offset: 0x00000D18
		public bool IsDead
		{
			get
			{
				return bigbrain.Memory.Readbyte(this._ComponentAddress + Offsets.BaseCombatEntity.lifestate) == 1;
			}
			set
			{
				this._visible = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000143 RID: 323 RVA: 0x00014654 File Offset: 0x00012854
		// (set) Token: 0x06000144 RID: 324 RVA: 0x000024D7 File Offset: 0x000006D7
		public int flag
		{
			get
			{
				return (int)bigbrain.Memory.Readbyte(this._ComponentAddress + Offsets.BasePlayer.playerFlags);
			}
			set
			{
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000145 RID: 325 RVA: 0x0001467C File Offset: 0x0001287C
		// (set) Token: 0x06000146 RID: 326 RVA: 0x00002B22 File Offset: 0x00000D22
		public ulong BoneDict
		{
			get
			{
				bool flag = this._BoneDict > 0UL;
				ulong boneDict;
				if (flag)
				{
					boneDict = this._BoneDict;
				}
				else
				{
					this._BoneDict = bigbrain.Memory.GetPointer(new ulong[]
					{
						this._ComponentAddress + Offsets.BaseEntity.model,
						Offsets.Model.boneTransforms,
						32UL
					});
					boneDict = this._BoneDict;
				}
				return boneDict;
			}
			set
			{
				this._BoneDict = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000147 RID: 327 RVA: 0x000146E0 File Offset: 0x000128E0
		// (set) Token: 0x06000148 RID: 328 RVA: 0x00002B2C File Offset: 0x00000D2C
		public ulong HeadBone
		{
			get
			{
				bool flag = this._HeadBone > 0UL;
				ulong headBone;
				if (flag)
				{
					headBone = this._HeadBone;
				}
				else
				{
					Requests memory = bigbrain.Memory;
					ulong[] array = new ulong[3];
					array[0] = this._ComponentAddress + Offsets.BaseEntity.model;
					array[1] = Offsets.Model.headBone;
					this._HeadBone = memory.GetPointer(array);
					headBone = this._HeadBone;
				}
				return headBone;
			}
			set
			{
				this._HeadBone = value;
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00014740 File Offset: 0x00012940
		public ulong tryGetBone(int boneId)
		{
			bool flag = this.cachedBones.ContainsKey(boneId);
			ulong result;
			if (flag)
			{
				result = this.cachedBones[boneId];
			}
			else
			{
				ulong num = bigbrain.Memory.ReadInt64(this.BoneDict + (ulong)((long)(boneId * 8)));
				this.cachedBones[boneId] = num;
				result = num;
			}
			return result;
		}

		// Token: 0x040001D9 RID: 473
		public bool GC = false;

		// Token: 0x040001DA RID: 474
		public ulong _ComponentAddress = 0UL;

		// Token: 0x040001DB RID: 475
		public ulong _gameObjectAddress = 0UL;

		// Token: 0x040001DC RID: 476
		public ulong _TransformAddress = 0UL;

		// Token: 0x040001DD RID: 477
		public ulong _BoneDict = 0UL;

		// Token: 0x040001DE RID: 478
		public ulong _HeadBone = 0UL;

		// Token: 0x040001DF RID: 479
		public ulong _niggerhealth = 0UL;

		// Token: 0x040001E0 RID: 480
		public ulong HeldWeapon = 0UL;

		// Token: 0x040001E1 RID: 481
		public ulong _Health = 0UL;

		// Token: 0x040001E2 RID: 482
		public int HeldWeaponCategory = 0;

		// Token: 0x040001E3 RID: 483
		public float Render_Distance = 500f;

		// Token: 0x040001E4 RID: 484
		public float Bone_Render_Distance = 350f;

		// Token: 0x040001E5 RID: 485
		public bool isLocalPlayer = false;

		// Token: 0x040001E6 RID: 486
		public bool IsNPC = false;

		// Token: 0x040001E7 RID: 487
		public bool IsSleeping = false;

		// Token: 0x040001E8 RID: 488
		public bool IsFriend = false;

		// Token: 0x040001E9 RID: 489
		public bool IsHitlist = false;

		// Token: 0x040001EA RID: 490
		private Requests.Vector3.Vector3f _Position = Requests.Vector3.Vector3f.Zero;

		// Token: 0x040001EB RID: 491
		private string _gameobjectname = "";

		// Token: 0x040001EC RID: 492
		private string _playername = "";

		// Token: 0x040001ED RID: 493
		private string _helditem = "";

		// Token: 0x040001EE RID: 494
		private bool _visible = true;

		// Token: 0x040001EF RID: 495
		private bool _IsCorpse = true;

		// Token: 0x040001F0 RID: 496
		private DateTime LastReadTime = DateTime.Now;

		// Token: 0x040001F1 RID: 497
		public static List<string> Friends = new List<string>
		{
			"Работник",
			"",
			"",
			"",
			"",
			""
		};

		// Token: 0x040001F2 RID: 498
		public Dictionary<int, ulong> cachedBones = new Dictionary<int, ulong>();
	}
}
