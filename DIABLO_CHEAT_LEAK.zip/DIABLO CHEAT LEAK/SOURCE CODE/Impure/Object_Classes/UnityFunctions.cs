﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using MDriver.MEME;

namespace Impure.Object_Classes
{
	// Token: 0x0200005F RID: 95
	public static class UnityFunctions
	{
		// Token: 0x0600018C RID: 396 RVA: 0x00014AE8 File Offset: 0x00012CE8
		public static ulong FindTaggedObject(string name)
		{
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 8UL);
			ulong num3 = num2;
			ulong num4;
			for (;;)
			{
				num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				string a = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num4 + 96UL), 32, false);
				bool flag = a == name;
				if (flag)
				{
					break;
				}
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
				if (num3 == 0UL || num3 == num2 || num2 <= 0UL)
				{
					goto Block_4;
				}
			}
			return num4;
			Block_4:
			return 0UL;
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00014B90 File Offset: 0x00012D90
		public static ulong FindTaggedObjectTAG(short TAG)
		{
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 8UL);
			ulong num3 = num2;
			ulong num4;
			for (;;)
			{
				num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				short num5 = bigbrain.Memory.ReadInt16(num4 + 84UL);
				bool flag = num5 == TAG;
				if (flag)
				{
					break;
				}
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
				if (num3 == 0UL || num3 == num2 || num2 <= 0UL)
				{
					goto Block_4;
				}
			}
			return num4;
			Block_4:
			return 0UL;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00014C28 File Offset: 0x00012E28
		public static ulong FindActiveObject(string name)
		{
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 24UL);
			ulong num3 = num2;
			ulong num4;
			for (;;)
			{
				num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				string a = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num4 + 96UL), 32, false);
				bool flag = a == name;
				if (flag)
				{
					break;
				}
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
				if (num3 == 0UL || num3 == num2 || num2 <= 0UL)
				{
					goto Block_4;
				}
			}
			return num4;
			Block_4:
			return 0UL;
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00014CD0 File Offset: 0x00012ED0
		public static void ScanComponent(ulong obj)
		{
			ulong num = bigbrain.Memory.ReadInt64(obj + 48UL);
			for (ulong num2 = 8UL; num2 < 512UL; num2 += 8UL)
			{
				ulong num3 = bigbrain.Memory.ReadInt64(num + num2);
				ulong num4 = bigbrain.Memory.ReadInt64(num3 + 40UL);
				ulong num5 = bigbrain.Memory.ReadInt64(num4);
				ulong num6 = bigbrain.Memory.ReadInt64(num5);
				string text = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num6 + 72UL), 124, false);
				bool flag = text.Length > 1;
				if (flag)
				{
					Debug.WriteLine("----" + text + " : " + num4.ToString("X"));
				}
			}
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00014D9C File Offset: 0x00012F9C
		public static void ScanActiveObject(string name)
		{
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 24UL);
			ulong num3 = num2;
			do
			{
				ulong num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				string text = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num4 + 96UL), 32, false);
				bool flag = text.ToLower().Contains(name);
				if (flag)
				{
					Debug.WriteLine(text + " : " + num4.ToString("X"));
					UnityFunctions.ScanComponent(num4);
				}
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
			}
			while (num3 != 0UL && num3 != num2 && num2 > 0UL);
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00014E64 File Offset: 0x00013064
		public static ulong DumpObjects(string logif)
		{
			string text = "";
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 8UL);
			ulong num3 = num2;
			do
			{
				ulong num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				string text2 = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num4 + 96UL), 32, false);
				short num5 = bigbrain.Memory.ReadInt16(num4 + 84UL);
				text = string.Concat(new string[]
				{
					text,
					text2,
					Environment.NewLine,
					"    TagID: ",
					num5.ToString(),
					Environment.NewLine,
					"    Address: ",
					num4.ToString("X"),
					Environment.NewLine
				});
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
				bool flag = text2.ToLower().Contains(logif);
				if (flag)
				{
					Debug.WriteLine(text2 + " : " + num4.ToString("X"));
				}
			}
			while (num3 != 0UL && num3 != num2 && num2 > 0UL);
			File.WriteAllText("C:/TaggedObjects.txt", text);
			Debug.WriteLine("Done Dumping");
			return 0UL;
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00014FB4 File Offset: 0x000131B4
		public static ulong DumpActiveObjects(string logif)
		{
			string text = "";
			ulong num = bigbrain.Memory.ReadInt64(UnityFunctions.UnityPlayer_Address + UnityFunctions.GameObjectManager);
			ulong num2 = bigbrain.Memory.ReadInt64(num + 24UL);
			ulong num3 = num2;
			do
			{
				ulong num4 = bigbrain.Memory.ReadInt64(num3 + 16UL);
				string text2 = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num4 + 96UL), 32, false);
				text = text + text2 + Environment.NewLine;
				num3 = bigbrain.Memory.ReadInt64(num3 + 8UL);
				bool flag = text2.ToLower().Contains(logif);
				if (flag)
				{
					Debug.WriteLine(text2 + " : " + num4.ToString("X"));
				}
			}
			while (num3 != 0UL && num3 != num2 && num2 > 0UL);
			File.WriteAllText("C:/ActiveObjects.txt", text);
			Debug.WriteLine("Done Dumping");
			return 0UL;
		}

		// Token: 0x06000193 RID: 403 RVA: 0x000150AC File Offset: 0x000132AC
		public static ulong GetComponent(ulong obj, string classname)
		{
			ulong num = bigbrain.Memory.ReadInt64(obj + 48UL);
			for (ulong num2 = 8UL; num2 < 512UL; num2 += 8UL)
			{
				ulong num3 = bigbrain.Memory.ReadInt64(num + num2);
				ulong num4 = bigbrain.Memory.ReadInt64(num3 + 40UL);
				ulong num5 = bigbrain.Memory.ReadInt64(num4);
				ulong num6 = bigbrain.Memory.ReadInt64(num5);
				string text = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(num6 + 72UL), 124, false);
				bool flag = text.Length > 1 && classname.Length == 0;
				if (flag)
				{
					Debug.WriteLine(text);
					Debug.WriteLine(num4.ToString("X"));
				}
				bool flag2 = text == classname;
				if (flag2)
				{
					return num4;
				}
			}
			return 0UL;
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00015198 File Offset: 0x00013398
		public static Requests.Vector2.Vector2f WorldToScreen(Requests.Vector3.Vector3f origin, Requests.ViewMatrix viewMatrix)
		{
			Requests.Vector2.Vector2f vector2f;
			vector2f..ctor(0f);
			Requests.ViewMatrix viewMatrix2;
			Requests.ViewMatrix.Transpose(ref viewMatrix, ref viewMatrix2);
			Requests.Vector3.Vector3f vector3f;
			vector3f..ctor(viewMatrix2.M41, viewMatrix2.M42, viewMatrix2.M43);
			Requests.Vector3.Vector3f vector3f2;
			vector3f2..ctor(viewMatrix2.M21, viewMatrix2.M22, viewMatrix2.M23);
			Requests.Vector3.Vector3f vector3f3;
			vector3f3..ctor(viewMatrix2.M11, viewMatrix2.M12, viewMatrix2.M13);
			float num = Requests.Vector3.Vector3f.Dot(vector3f, origin) + viewMatrix2.M44;
			bool flag = num < 0.098f;
			Requests.Vector2.Vector2f result;
			if (flag)
			{
				result = vector2f;
			}
			else
			{
				float num2 = Requests.Vector3.Vector3f.Dot(vector3f2, origin) + viewMatrix2.M24;
				float num3 = Requests.Vector3.Vector3f.Dot(vector3f3, origin) + viewMatrix2.M14;
				vector2f.X = (float)(UnityFunctions.screen_Width / 2) * (1f + num3 / num);
				vector2f.Y = (float)(UnityFunctions.screen_Height / 2) * (1f - num2 / num);
				result = vector2f;
			}
			return result;
		}

		// Token: 0x06000195 RID: 405 RVA: 0x0001528C File Offset: 0x0001348C
		public unsafe static Requests.Vector4.Vector4f Shuffle(this Requests.Vector4.Vector4f v1, UnityFunctions.ShuffleSel sel)
		{
			float* ptr = (float*)(&v1);
			return new Requests.Vector4.Vector4f(ptr[(IntPtr)(sel & UnityFunctions.ShuffleSel.XFromW)], ptr[(IntPtr)(sel >> 2 & UnityFunctions.ShuffleSel.XFromW)], ptr[(IntPtr)(sel >> 4 & UnityFunctions.ShuffleSel.XFromW)], ptr[(IntPtr)(sel >> 6 & UnityFunctions.ShuffleSel.XFromW)]);
		}

		// Token: 0x06000196 RID: 406 RVA: 0x000152D4 File Offset: 0x000134D4
		public unsafe static Requests.Vector3.Vector3f GetBonePosition(ulong transform)
		{
			GCHandle gchandle = default(GCHandle);
			GCHandle gchandle2 = default(GCHandle);
			Requests.Vector3.Vector3f result;
			try
			{
				ulong num = bigbrain.Memory.ReadInt64(transform + 16UL);
				bool flag = num == 0UL;
				if (flag)
				{
					result = Requests.Vector3.Vector3f.Zero;
				}
				else
				{
					ulong num2 = bigbrain.Memory.ReadInt64(num + 56UL);
					int num3 = bigbrain.Memory.ReadInt32(num + 64UL);
					bool flag2 = num2 == 0UL;
					if (flag2)
					{
						result = Requests.Vector3.Vector3f.Zero;
					}
					else
					{
						ulong num4 = bigbrain.Memory.ReadInt64(num2 + 24UL);
						bool flag3 = num4 == 0UL;
						if (flag3)
						{
							result = Requests.Vector3.Vector3f.Zero;
						}
						else
						{
							ulong num5 = bigbrain.Memory.ReadInt64(num2 + 32UL);
							bool flag4 = num5 == 0UL;
							if (flag4)
							{
								result = Requests.Vector3.Vector3f.Zero;
							}
							else
							{
								byte[] value = bigbrain.Memory.ReadBytes(num4, sizeof(UnityFunctions.Matrix34) * num3 + sizeof(UnityFunctions.Matrix34));
								gchandle2 = GCHandle.Alloc(value, GCHandleType.Pinned);
								void* ptr = gchandle2.AddrOfPinnedObject().ToPointer();
								byte[] value2 = bigbrain.Memory.ReadBytes(num5, 4 * num3 + 4);
								gchandle = GCHandle.Alloc(value2, GCHandleType.Pinned);
								void* ptr2 = gchandle.AddrOfPinnedObject().ToPointer();
								Requests.Vector4.Vector4f vector4f = ((Requests.Vector4.Vector4f*)ptr)[48L * (long)num3 / (long)sizeof(Requests.Vector4.Vector4f)];
								int i = ((int*)ptr2)[4L * (long)num3 / 4L];
								Requests.Vector4.Vector4f vector4f2;
								vector4f2..ctor(-2f, 2f, -2f, 0f);
								Requests.Vector4.Vector4f vector4f3;
								vector4f3..ctor(2f, -2f, -2f, 0f);
								Requests.Vector4.Vector4f vector4f4;
								vector4f4..ctor(-2f, -2f, 2f, 0f);
								int num6 = 10000;
								int num7 = 0;
								try
								{
									while (i >= 0)
									{
										bool flag5 = num7++ > num6;
										if (flag5)
										{
											break;
										}
										UnityFunctions.Matrix34 matrix = ((UnityFunctions.Matrix34*)ptr)[48L * (long)i / (long)sizeof(UnityFunctions.Matrix34)];
										Requests.Vector4.Vector4f vector4f5 = matrix.vec2 * vector4f;
										Requests.Vector4.Vector4f vector4f6 = matrix.vec1.Shuffle(UnityFunctions.ShuffleSel.XFromX);
										Requests.Vector4.Vector4f vector4f7 = matrix.vec1.Shuffle(UnityFunctions.ShuffleSel.ExpandY);
										Requests.Vector4.Vector4f vector4f8 = matrix.vec1.Shuffle((UnityFunctions.ShuffleSel)142);
										Requests.Vector4.Vector4f vector4f9 = matrix.vec1.Shuffle((UnityFunctions.ShuffleSel)219);
										Requests.Vector4.Vector4f vector4f10 = matrix.vec1.Shuffle(UnityFunctions.ShuffleSel.ExpandZ);
										Requests.Vector4.Vector4f vector4f11 = matrix.vec1.Shuffle((UnityFunctions.ShuffleSel)113);
										vector4f = (vector4f6 * vector4f3 * vector4f8 - vector4f7 * vector4f4 * vector4f9) * vector4f5.Shuffle((UnityFunctions.ShuffleSel)(-86)) + (vector4f10 * vector4f4 * vector4f9 - vector4f6 * vector4f2 * vector4f11) * vector4f5.Shuffle(UnityFunctions.ShuffleSel.ExpandY) + ((vector4f7 * vector4f2 * vector4f11 - vector4f10 * vector4f3 * vector4f8) * vector4f5.Shuffle(UnityFunctions.ShuffleSel.XFromX) + vector4f5) + matrix.vec0;
										i = ((int*)ptr2)[4L * (long)i / 4L];
									}
									try
									{
										gchandle.Free();
									}
									catch
									{
									}
									try
									{
										gchandle2.Free();
									}
									catch
									{
									}
								}
								catch
								{
									try
									{
										gchandle.Free();
									}
									catch
									{
									}
									try
									{
										gchandle2.Free();
									}
									catch
									{
									}
								}
								result = new Requests.Vector3.Vector3f(vector4f.X, vector4f.Y, vector4f.Z);
							}
						}
					}
				}
			}
			catch
			{
				try
				{
					gchandle.Free();
				}
				catch
				{
				}
				try
				{
					gchandle2.Free();
				}
				catch
				{
				}
				result = new Requests.Vector3.Vector3f(0f, 0f, 0f);
			}
			return result;
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00015778 File Offset: 0x00013978
		public static Requests.Vector2.Vector2f getBoneScreen(ulong x, Requests.ViewMatrix y)
		{
			Requests.Vector3.Vector3f bonePosition = UnityFunctions.GetBonePosition(x);
			return UnityFunctions.WorldToScreen(bonePosition, y);
		}

		// Token: 0x0400027C RID: 636
		public static int screen_Width = Screen.PrimaryScreen.Bounds.Width;

		// Token: 0x0400027D RID: 637
		public static int screen_Height = Screen.PrimaryScreen.Bounds.Height;

		// Token: 0x0400027E RID: 638
		public static ulong UnityPlayer_Address = 0UL;

		// Token: 0x0400027F RID: 639
		public static ulong BaseNetworkable = 0UL;

		// Token: 0x04000280 RID: 640
		public static ulong GameObjectManager = 24799960UL;

		// Token: 0x04000281 RID: 641
		public static ulong BN_Base = 43538504UL;

		// Token: 0x02000060 RID: 96
		private struct Matrix34
		{
			// Token: 0x04000282 RID: 642
			public Requests.Vector4.Vector4f vec0;

			// Token: 0x04000283 RID: 643
			public Requests.Vector4.Vector4f vec1;

			// Token: 0x04000284 RID: 644
			public Requests.Vector4.Vector4f vec2;
		}

		// Token: 0x02000061 RID: 97
		public enum ShuffleSel
		{
			// Token: 0x04000286 RID: 646
			XFromX,
			// Token: 0x04000287 RID: 647
			XFromY,
			// Token: 0x04000288 RID: 648
			XFromZ,
			// Token: 0x04000289 RID: 649
			XFromW,
			// Token: 0x0400028A RID: 650
			YFromX = 0,
			// Token: 0x0400028B RID: 651
			YFromY = 4,
			// Token: 0x0400028C RID: 652
			YFromZ = 8,
			// Token: 0x0400028D RID: 653
			YFromW = 12,
			// Token: 0x0400028E RID: 654
			ZFromX = 0,
			// Token: 0x0400028F RID: 655
			ZFromY = 16,
			// Token: 0x04000290 RID: 656
			ZFromZ = 32,
			// Token: 0x04000291 RID: 657
			ZFromW = 48,
			// Token: 0x04000292 RID: 658
			WFromX = 0,
			// Token: 0x04000293 RID: 659
			WFromY = 64,
			// Token: 0x04000294 RID: 660
			WFromZ = 128,
			// Token: 0x04000295 RID: 661
			WFromW = 192,
			// Token: 0x04000296 RID: 662
			ExpandX = 0,
			// Token: 0x04000297 RID: 663
			ExpandY = 85,
			// Token: 0x04000298 RID: 664
			ExpandZ = 170,
			// Token: 0x04000299 RID: 665
			ExpandW = 255,
			// Token: 0x0400029A RID: 666
			ExpandXY = 80,
			// Token: 0x0400029B RID: 667
			ExpandZW = 250,
			// Token: 0x0400029C RID: 668
			ExpandInterleavedXY = 68,
			// Token: 0x0400029D RID: 669
			ExpandInterleavedZW = 238,
			// Token: 0x0400029E RID: 670
			RotateRight = 57,
			// Token: 0x0400029F RID: 671
			RotateLeft = 147,
			// Token: 0x040002A0 RID: 672
			Swap = 27
		}
	}
}
