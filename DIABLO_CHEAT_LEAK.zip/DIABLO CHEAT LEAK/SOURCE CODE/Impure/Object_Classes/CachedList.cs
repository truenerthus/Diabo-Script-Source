﻿using System;
using System.Collections.Generic;

namespace Impure.Object_Classes
{
	// Token: 0x02000024 RID: 36
	internal class CachedList
	{
		// Token: 0x060000DE RID: 222 RVA: 0x0001041C File Offset: 0x0000E61C
		public static Dictionary<ulong, PlayerClass> GetSafePlayers(bool _GC = false)
		{
			Dictionary<ulong, PlayerClass> dictionary = new Dictionary<ulong, PlayerClass>();
			foreach (KeyValuePair<ulong, PlayerClass> keyValuePair in CachedList.Players)
			{
				bool flag = _GC && keyValuePair.Value.GC;
				if (!flag)
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return dictionary;
		}

		// Token: 0x060000DF RID: 223 RVA: 0x000104A8 File Offset: 0x0000E6A8
		public static PlayerClass SetupPlayer(Dictionary<ulong, PlayerClass> Player_List, ulong key)
		{
			bool flag = Player_List.ContainsKey(key);
			PlayerClass playerClass;
			if (flag)
			{
				playerClass = Player_List[key];
				playerClass.GC = false;
			}
			else
			{
				playerClass = new PlayerClass(key);
				playerClass.GC = false;
				Player_List[key] = playerClass;
			}
			return playerClass;
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x000104F4 File Offset: 0x0000E6F4
		public static Dictionary<ulong, LootItemClass> GetSafeLoot(bool _GC = false)
		{
			Dictionary<ulong, LootItemClass> dictionary = new Dictionary<ulong, LootItemClass>();
			foreach (KeyValuePair<ulong, LootItemClass> keyValuePair in CachedList.LootItems)
			{
				bool flag = _GC && keyValuePair.Value.GC;
				if (!flag)
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return dictionary;
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00010580 File Offset: 0x0000E780
		public static LootItemClass SetupLoot(Dictionary<ulong, LootItemClass> Loot_List, ulong key)
		{
			bool flag = Loot_List.ContainsKey(key);
			LootItemClass lootItemClass;
			if (flag)
			{
				lootItemClass = Loot_List[key];
				lootItemClass.GC = false;
			}
			else
			{
				lootItemClass = new LootItemClass(key);
				lootItemClass.GC = false;
				Loot_List[key] = lootItemClass;
			}
			return lootItemClass;
		}

		// Token: 0x04000145 RID: 325
		public static Dictionary<ulong, PlayerClass> Players = new Dictionary<ulong, PlayerClass>();

		// Token: 0x04000146 RID: 326
		public static Dictionary<ulong, LootItemClass> LootItems = new Dictionary<ulong, LootItemClass>();
	}
}
