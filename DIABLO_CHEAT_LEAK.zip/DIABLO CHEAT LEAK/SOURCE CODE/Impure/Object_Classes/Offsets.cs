﻿using System;

namespace Impure.Object_Classes
{
	// Token: 0x0200003E RID: 62
	public static class Offsets
	{
		// Token: 0x040001F3 RID: 499
		public static ulong Sky_Dome = 0UL;

		// Token: 0x040001F4 RID: 500
		public static ulong DoMovement = 4750368UL;

		// Token: 0x040001F5 RID: 501
		public static ulong set_DateTime = 9930336UL;

		// Token: 0x040001F6 RID: 502
		public static ulong BlockSprint = 6668848UL;

		// Token: 0x040001F7 RID: 503
		public static ulong CanAttack = 3060560UL;

		// Token: 0x040001F8 RID: 504
		public static ulong GetJumpHeight = 3079936UL;

		// Token: 0x040001F9 RID: 505
		public static ulong isAdmin = 3159680UL;

		// Token: 0x040001FA RID: 506
		public static ulong CanJump = 4644576UL;

		// Token: 0x040001FB RID: 507
		public static ulong CreateProjectile = 4769776UL;

		// Token: 0x040001FC RID: 508
		public static ulong UpdateAmbientLight = 3271856UL;

		// Token: 0x040001FD RID: 509
		public static ulong CanHoldItems = 2614688UL;

		// Token: 0x040001FE RID: 510
		public static ulong CanSprint = 6612992UL;

		// Token: 0x040001FF RID: 511
		public static ulong GetIndexedSpreadScalar = 6452912UL;

		// Token: 0x04000200 RID: 512
		public static ulong BlockJump = 2896960UL;

		// Token: 0x04000201 RID: 513
		public static ulong itemList = 56UL;

		// Token: 0x04000202 RID: 514
		public static ulong list = 16UL;

		// Token: 0x04000203 RID: 515
		public static ulong index = 16UL;

		// Token: 0x04000204 RID: 516
		public static ulong m_stringLength = 16UL;

		// Token: 0x04000205 RID: 517
		public static ulong m_firstChar = 20UL;

		// Token: 0x0200003F RID: 63
		public class PlayerInput
		{
			// Token: 0x04000206 RID: 518
			public static ulong bodyAngles = 60UL;

			// Token: 0x04000207 RID: 519
			public static ulong InputState = 32UL;
		}

		// Token: 0x02000040 RID: 64
		public class Projectile
		{
			// Token: 0x04000208 RID: 520
			public static ulong initialDistance = 48UL;
		}

		// Token: 0x02000041 RID: 65
		public class InputMessage
		{
			// Token: 0x04000209 RID: 521
			public static ulong aimAngles = 24UL;
		}

		// Token: 0x02000042 RID: 66
		public class BasePlayer
		{
			// Token: 0x0400020A RID: 522
			public static ulong inventory = 1544UL;

			// Token: 0x0400020B RID: 523
			public static ulong lastSentTickTime = 1484UL;

			// Token: 0x0400020C RID: 524
			public static ulong clActiveItem = 1392UL;

			// Token: 0x0400020D RID: 525
			public static ulong health = 72UL;

			// Token: 0x0400020E RID: 526
			public static ulong movement = 1232UL;

			// Token: 0x0400020F RID: 527
			public static ulong playerFlags = 1528UL;

			// Token: 0x04000210 RID: 528
			public static ulong modelState = 1416UL;

			// Token: 0x04000211 RID: 529
			public static ulong input = 1224UL;

			// Token: 0x04000212 RID: 530
			public static ulong displayName = 1616UL;

			// Token: 0x04000213 RID: 531
			public static ulong userID = 1600UL;

			// Token: 0x04000214 RID: 532
			public static ulong clientTeam = 1344UL;

			// Token: 0x04000215 RID: 533
			public static ulong clothingWaterSpeedBonus = 1652UL;

			// Token: 0x04000216 RID: 534
			public static ulong playerModel = 1192UL;
		}

		// Token: 0x02000043 RID: 67
		public class BaseNetworkable
		{
			// Token: 0x04000217 RID: 535
			public static ulong IsDestroyed = 88UL;
		}

		// Token: 0x02000044 RID: 68
		public class PlayerWalkMovement
		{
			// Token: 0x04000218 RID: 536
			public static ulong gravityMultiplier = 116UL;

			// Token: 0x04000219 RID: 537
			public static ulong gravityMultiplierSwimming = 120UL;

			// Token: 0x0400021A RID: 538
			public static ulong maxAngleWalking = 124UL;

			// Token: 0x0400021B RID: 539
			public static ulong maxAngleClimbing = 128UL;

			// Token: 0x0400021C RID: 540
			public static ulong maxVelocity = 176UL;

			// Token: 0x0400021D RID: 541
			public static ulong groundAngle = 180UL;

			// Token: 0x0400021E RID: 542
			public static ulong groundAngleNew = 184UL;

			// Token: 0x0400021F RID: 543
			public static ulong grounded = 304UL;

			// Token: 0x04000220 RID: 544
			public static ulong groundTime = 188UL;

			// Token: 0x04000221 RID: 545
			public static ulong FallVelocity = 6674784UL;

			// Token: 0x04000222 RID: 546
			public static ulong Flying = 316UL;

			// Token: 0x04000223 RID: 547
			public static ulong sliding = 308UL;

			// Token: 0x04000224 RID: 548
			public static ulong swimming = 310UL;
		}

		// Token: 0x02000045 RID: 69
		public class PlayerInventory
		{
			// Token: 0x04000225 RID: 549
			public static ulong containerMain = 32UL;

			// Token: 0x04000226 RID: 550
			public static ulong containerBelt = 40UL;

			// Token: 0x04000227 RID: 551
			public static ulong containerWear = 48UL;
		}

		// Token: 0x02000046 RID: 70
		public class ItemModProjectile
		{
			// Token: 0x04000228 RID: 552
			public static ulong projectileSpread = 48UL;

			// Token: 0x04000229 RID: 553
			public static ulong projectileVelocity = 52UL;
		}

		// Token: 0x02000047 RID: 71
		public class HeldEntity
		{
			// Token: 0x0400022A RID: 554
			public static ulong BaseProjectile = 152UL;

			// Token: 0x0400022B RID: 555
			public static ulong ViewModel = 384UL;

			// Token: 0x0400022C RID: 556
			public static ulong ItemID = 32UL;

			// Token: 0x0400022D RID: 557
			public static ulong isDeployed = 392UL;
		}

		// Token: 0x02000048 RID: 72
		public class Attack
		{
			// Token: 0x0400022E RID: 558
			public static ulong hitID = 44UL;

			// Token: 0x0400022F RID: 559
			public static ulong hitBone = 48UL;

			// Token: 0x04000230 RID: 560
			public static ulong hitPartID = 100UL;

			// Token: 0x04000231 RID: 561
			public static ulong hitNormalLocal = 52UL;

			// Token: 0x04000232 RID: 562
			public static ulong hitPositionLocal = 64UL;
		}

		// Token: 0x02000049 RID: 73
		public class BowWeapon
		{
			// Token: 0x04000233 RID: 563
			public static ulong attackReady = 832UL;

			// Token: 0x04000234 RID: 564
			public static ulong arrowBack = 836UL;
		}

		// Token: 0x0200004A RID: 74
		public class Graphics
		{
			// Token: 0x04000235 RID: 565
			public static ulong _fov = 24UL;
		}

		// Token: 0x0200004B RID: 75
		public class BaseProjectile
		{
			// Token: 0x04000236 RID: 566
			public static ulong CreatedProjectiles = 824UL;

			// Token: 0x04000237 RID: 567
			public static ulong projectileVelocityScale = 620UL;

			// Token: 0x04000238 RID: 568
			public static ulong automatic = 624UL;

			// Token: 0x04000239 RID: 569
			public static ulong hasADS = 748UL;

			// Token: 0x0400023A RID: 570
			public static ulong recoil = 704UL;

			// Token: 0x0400023B RID: 571
			public static ulong HeldEntity = 152UL;

			// Token: 0x0400023C RID: 572
			public static ulong CreatedProjArray = 16UL;

			// Token: 0x0400023D RID: 573
			public static ulong currentPosition = 292UL;

			// Token: 0x0400023E RID: 574
			public static ulong nextReloadTime = 764UL;

			// Token: 0x0400023F RID: 575
			public static ulong startReloadTime = 768UL;

			// Token: 0x04000240 RID: 576
			public static ulong stancePenalty = 772UL;

			// Token: 0x04000241 RID: 577
			public static ulong aimconePenalty = 776UL;

			// Token: 0x04000242 RID: 578
			public static ulong aimSway = 696UL;

			// Token: 0x04000243 RID: 579
			public static ulong aimSwaySpeed = 700UL;

			// Token: 0x04000244 RID: 580
			public static ulong aimCone = 720UL;

			// Token: 0x04000245 RID: 581
			public static ulong hipAimCone = 724UL;

			// Token: 0x04000246 RID: 582
			public static ulong aimconePenaltyPerShot = 728UL;

			// Token: 0x04000247 RID: 583
			public static ulong aimConePenaltyMax = 732UL;

			// Token: 0x04000248 RID: 584
			public static ulong aimconePenaltyRecoverTime = 736UL;

			// Token: 0x04000249 RID: 585
			public static ulong aimconePenaltyRecoverDelay = 740UL;

			// Token: 0x0400024A RID: 586
			public static ulong stancePenaltyScale = 744UL;
		}

		// Token: 0x0200004C RID: 76
		public class BaseMovement
		{
			// Token: 0x0400024B RID: 587
			public static ulong Runningk__BackingField = 64UL;

			// Token: 0x0400024C RID: 588
			public static ulong adminCheat = 24UL;
		}

		// Token: 0x0200004D RID: 77
		public class ModelState
		{
			// Token: 0x0400024D RID: 589
			public static ulong flags = 36UL;

			// Token: 0x0400024E RID: 590
			public static ulong waterLevel = 20UL;
		}

		// Token: 0x0200004E RID: 78
		public class AttackEntity
		{
			// Token: 0x0400024F RID: 591
			public static ulong repeatDelay = 476UL;
		}

		// Token: 0x0200004F RID: 79
		public class RecoilProperties
		{
			// Token: 0x04000250 RID: 592
			public static ulong recoilYawMin = 24UL;

			// Token: 0x04000251 RID: 593
			public static ulong ADSScale = 48UL;

			// Token: 0x04000252 RID: 594
			public static ulong recoilYawMax = 28UL;

			// Token: 0x04000253 RID: 595
			public static ulong recoilPitchMin = 32UL;

			// Token: 0x04000254 RID: 596
			public static ulong recoilPitchMax = 36UL;

			// Token: 0x04000255 RID: 597
			public static ulong movementPenalty = 52UL;

			// Token: 0x04000256 RID: 598
			public static ulong shotsUntilMax = 84UL;
		}

		// Token: 0x02000050 RID: 80
		public class Item
		{
			// Token: 0x04000257 RID: 599
			public static ulong info = 32UL;

			// Token: 0x04000258 RID: 600
			public static ulong uid = 40UL;

			// Token: 0x04000259 RID: 601
			public static ulong amount = 48UL;

			// Token: 0x0400025A RID: 602
			public static ulong ItemContainerparent = 120UL;
		}

		// Token: 0x02000051 RID: 81
		public class ItemDefinition
		{
			// Token: 0x0400025B RID: 603
			public static ulong itemid = 24UL;

			// Token: 0x0400025C RID: 604
			public static ulong shortname = 32UL;

			// Token: 0x0400025D RID: 605
			public static ulong displayName = 40UL;

			// Token: 0x0400025E RID: 606
			public static ulong category = 64UL;

			// Token: 0x0400025F RID: 607
			public static ulong itemType = 76UL;

			// Token: 0x04000260 RID: 608
			public static ulong condition = 136UL;
		}

		// Token: 0x02000052 RID: 82
		public class WorldItem
		{
			// Token: 0x04000261 RID: 609
			public static ulong item = 336UL;
		}

		// Token: 0x02000053 RID: 83
		public class FlintStrikeWeapon
		{
			// Token: 0x04000262 RID: 610
			public static ulong successFraction = 832UL;

			// Token: 0x04000263 RID: 611
			public static ulong _isStriking = 849UL;
		}

		// Token: 0x02000054 RID: 84
		public class PlayerModel
		{
			// Token: 0x04000264 RID: 612
			public static ulong skinColor = 380UL;

			// Token: 0x04000265 RID: 613
			public static ulong visible = 584UL;

			// Token: 0x04000266 RID: 614
			public static ulong velocity = 484UL;

			// Token: 0x04000267 RID: 615
			public static ulong _multiMesh = 640UL;
		}

		// Token: 0x02000055 RID: 85
		public class Model
		{
			// Token: 0x04000268 RID: 616
			public static ulong headBone = 40UL;

			// Token: 0x04000269 RID: 617
			public static ulong boneTransforms = 72UL;
		}

		// Token: 0x02000056 RID: 86
		public class SkinnedMultiMesh
		{
			// Token: 0x0400026A RID: 618
			public static ulong boneDict = 40UL;
		}

		// Token: 0x02000057 RID: 87
		public class BoneDictionary
		{
			// Token: 0x0400026B RID: 619
			public static ulong transforms = 16UL;

			// Token: 0x0400026C RID: 620
			public static ulong names = 24UL;
		}

		// Token: 0x02000058 RID: 88
		public class ViewModel
		{
			// Token: 0x0400026D RID: 621
			public static ulong viewModelPrefab = 24UL;

			// Token: 0x0400026E RID: 622
			public static ulong targetEntity = 32UL;

			// Token: 0x0400026F RID: 623
			public static ulong instance = 40UL;
		}

		// Token: 0x02000059 RID: 89
		public class BaseViewModel
		{
			// Token: 0x04000270 RID: 624
			public static ulong ironSights = 96UL;
		}

		// Token: 0x0200005A RID: 90
		public class IronSights
		{
			// Token: 0x04000271 RID: 625
			public static ulong zoomFactor = 44UL;
		}

		// Token: 0x0200005B RID: 91
		public class BaseMelee
		{
			// Token: 0x04000272 RID: 626
			public static ulong maxDistance = 632UL;

			// Token: 0x04000273 RID: 627
			public static ulong attackRadius = 636UL;

			// Token: 0x04000274 RID: 628
			public static ulong blockSprintOnAttack = 641UL;
		}

		// Token: 0x0200005C RID: 92
		public class BaseEntity
		{
			// Token: 0x04000275 RID: 629
			public static ulong flags = 288UL;

			// Token: 0x04000276 RID: 630
			public static ulong model = 280UL;

			// Token: 0x04000277 RID: 631
			public static ulong ragdoll = 112UL;
		}

		// Token: 0x0200005D RID: 93
		public class BaseCombatEntity
		{
			// Token: 0x04000278 RID: 632
			public static ulong lifestate = 516UL;

			// Token: 0x04000279 RID: 633
			public static ulong clientTickInterval = 1480UL;

			// Token: 0x0400027A RID: 634
			public static ulong health = 524UL;
		}

		// Token: 0x0200005E RID: 94
		public class PlayerTeam
		{
			// Token: 0x0400027B RID: 635
			public static ulong members_List = 48UL;
		}
	}
}
