﻿using System;
using System.Runtime.InteropServices;
using MDriver.MEME;

namespace Impure.Object_Classes
{
	// Token: 0x0200003C RID: 60
	public class Noclip
	{
		// Token: 0x06000130 RID: 304
		[DllImport("user32.dll")]
		public static extern int GetKeyState(int vKey);

		// Token: 0x06000131 RID: 305 RVA: 0x00014054 File Offset: 0x00012254
		public static void MoveToAngle(ulong Address, Requests.Vector2.Vector2f BodyAngles, float Distance)
		{
			Requests.Vector3.Vector3f vector3f = bigbrain.Memory.ReadVector3f(Address);
			double num = 0.017453292519943295 * (double)(BodyAngles.Y - 90f);
			float num2 = Distance * (float)Math.Cos(num);
			float num3 = Distance * (float)Math.Sin(num);
			vector3f.X += num2;
			vector3f.Z -= num3;
			bigbrain.Memory.WriteVector3f(Address, vector3f);
		}

		// Token: 0x06000132 RID: 306 RVA: 0x000140C8 File Offset: 0x000122C8
		public void Fly()
		{
			int keyState = Noclip.GetKeyState(87);
			bool flag = (keyState & 32768) != 0;
			if (flag)
			{
				Requests.Vector2.Vector2f bodyAngles = bigbrain.Memory.ReadVector2f(Aimbot.Input);
				Noclip.MoveToAngle(Local.LocalPlayer.TransformAddress, bodyAngles, 10f);
			}
		}
	}
}
