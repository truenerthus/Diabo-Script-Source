﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Impure
{
	// Token: 0x02000013 RID: 19
	public partial class Home : Form
	{
		// Token: 0x06000080 RID: 128 RVA: 0x0000251A File Offset: 0x0000071A
		public Home()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000024D7 File Offset: 0x000006D7
		private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000082 RID: 130 RVA: 0x000024D7 File Offset: 0x000006D7
		private void Home_Load(object sender, EventArgs e)
		{
		}
	}
}
