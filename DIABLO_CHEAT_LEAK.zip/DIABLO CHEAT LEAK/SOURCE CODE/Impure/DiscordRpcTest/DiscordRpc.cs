﻿using System;
using DiscordRPC;

namespace Impure.DiscordRpcTest
{
	// Token: 0x02000074 RID: 116
	internal class DiscordRpc
	{
		// Token: 0x06000208 RID: 520 RVA: 0x0001B9D4 File Offset: 0x00019BD4
		public static void StartDiscordRPC()
		{
			try
			{
				DiscordRpc.client = new DiscordRpcClient("746867131903246376");
				DiscordRpc.client.Initialize();
				DiscordRpc.client.SetPresence(new RichPresence
				{
					Details = "Diablo Rust Cheat",
					State = "diablo.pub",
					Assets = new Assets
					{
						LargeImageKey = "rust-icon-16",
						LargeImageText = "naivecheats.com Best Cheating Software",
						SmallImageKey = "1568024750"
					}
				});
			}
			catch
			{
			}
		}

		// Token: 0x06000209 RID: 521 RVA: 0x0001BA70 File Offset: 0x00019C70
		public static void StopDiscordRPC()
		{
			try
			{
				DiscordRpc.client.Dispose();
			}
			catch
			{
			}
		}

		// Token: 0x04000566 RID: 1382
		public static DiscordRpcClient client;
	}
}
