﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace Impure
{
	// Token: 0x02000002 RID: 2
	public partial class App : Application
	{
	}
}
