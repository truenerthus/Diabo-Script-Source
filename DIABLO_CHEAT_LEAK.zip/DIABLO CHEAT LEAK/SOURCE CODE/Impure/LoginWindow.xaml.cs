﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace Impure
{
	// Token: 0x02000019 RID: 25
	public partial class LoginWindow : Window
	{
		// Token: 0x060000A8 RID: 168
		[DllImport("diablo.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool Initialize(string publicKey);

		// Token: 0x060000A9 RID: 169
		[DllImport("diablo.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool Authenticate(string license, string hwid);

		// Token: 0x060000AA RID: 170
		[DllImport("diablo.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr GetHardwareID();

		// Token: 0x060000AB RID: 171
		[DllImport("diablo.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr GetReturnMessage();

		// Token: 0x060000AC RID: 172 RVA: 0x00006354 File Offset: 0x00004554
		private string GetString(IntPtr ptr)
		{
			return Marshal.PtrToStringAnsi(ptr);
		}

		// Token: 0x060000AD RID: 173 RVA: 0x0000636C File Offset: 0x0000456C
		public LoginWindow()
		{
			this.InitializeComponent();
			bool flag;
			if (flag)
			{
			}
			bool flag2;
			if (flag2)
			{
			}
			bool flag3 = !LoginWindow.Initialize("lb7YX1VTgU3pQnVtXKOD12JQCY1ldGPXCZCL9egS1n6J5Yv81ytLEU2AvK33rOu4");
			if (flag3)
			{
				MessageBox.Show("Please check our status on diablo.pub", "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			Thread.Sleep(1);
		}

		// Token: 0x060000AE RID: 174 RVA: 0x000063D0 File Offset: 0x000045D0
		private void LoginButton_Click(object sender, RoutedEventArgs e)
		{
			bool flag = LoginWindow.Authenticate(this.UsernameBox1.Text, this.GetString(LoginWindow.GetHardwareID()));
			MessageBox.Show("Logged In Successfully To Diablo.pub", "Diablo.pub | Rust Cheat Beta", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			Window1 window = new Window1();
			window.Show();
			base.Hide();
		}

		// Token: 0x060000AF RID: 175 RVA: 0x000024C2 File Offset: 0x000006C2
		private void MiniButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0000263A File Offset: 0x0000083A
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			Application.Current.Shutdown();
			Environment.Exit(0);
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0000264F File Offset: 0x0000084F
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			base.Title = Helpers.RandomString(Helpers.Rnd.Next(8, 32));
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x000057B8 File Offset: 0x000039B8
		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed;
			if (flag)
			{
				base.DragMove();
			}
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x000024D7 File Offset: 0x000006D7
		private void UsernameBox_TextChanged(object sender, TextChangedEventArgs e)
		{
		}

		// Token: 0x04000056 RID: 86
		public static bool initialized = false;

		// Token: 0x04000057 RID: 87
		private string HWID;
	}
}
