﻿using System;
using System.Linq;
using System.Security.Principal;

namespace Impure
{
	// Token: 0x02000004 RID: 4
	internal class Constants
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000008 RID: 8 RVA: 0x000021FF File Offset: 0x000003FF
		// (set) Token: 0x06000009 RID: 9 RVA: 0x00002206 File Offset: 0x00000406
		public static string Token { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600000A RID: 10 RVA: 0x0000220E File Offset: 0x0000040E
		// (set) Token: 0x0600000B RID: 11 RVA: 0x00002215 File Offset: 0x00000415
		public static string Date { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000C RID: 12 RVA: 0x0000221D File Offset: 0x0000041D
		// (set) Token: 0x0600000D RID: 13 RVA: 0x00002224 File Offset: 0x00000424
		public static string APIENCRYPTKEY { get; set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600000E RID: 14 RVA: 0x0000222C File Offset: 0x0000042C
		// (set) Token: 0x0600000F RID: 15 RVA: 0x00002233 File Offset: 0x00000433
		public static string APIENCRYPTSALT { get; set; }

		// Token: 0x06000010 RID: 16 RVA: 0x00003248 File Offset: 0x00001448
		public static string RandomString(int length)
		{
			return new string((from s in Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", length)
			select s[Constants.random.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00003294 File Offset: 0x00001494
		public static string HWID()
		{
			return WindowsIdentity.GetCurrent().User.Value;
		}

		// Token: 0x04000008 RID: 8
		public static bool Breached = false;

		// Token: 0x04000009 RID: 9
		public static bool Started = false;

		// Token: 0x0400000A RID: 10
		public static string IV = null;

		// Token: 0x0400000B RID: 11
		public static string Key = null;

		// Token: 0x0400000C RID: 12
		public static string ApiUrl = "https://api.auth.gg/csharp/";

		// Token: 0x0400000D RID: 13
		public static bool Initialized = false;

		// Token: 0x0400000E RID: 14
		public static Random random = new Random();
	}
}
