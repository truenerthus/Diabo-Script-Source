﻿using System;
using Costura;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x000021D4 File Offset: 0x000003D4
	static <Module>()
	{
		AssemblyLoader.Attach();
	}
}
