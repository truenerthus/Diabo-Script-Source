﻿namespace Impure
{
	// Token: 0x02000013 RID: 19
	public partial class Home : global::System.Windows.Forms.Form
	{
		// Token: 0x06000083 RID: 131 RVA: 0x00005984 File Offset: 0x00003B84
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000084 RID: 132 RVA: 0x000059BC File Offset: 0x00003BBC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.Home));
			this.richTextBox1 = new global::System.Windows.Forms.RichTextBox();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.richTextBox1.BackColor = global::System.Drawing.Color.FromArgb(61, 72, 85);
			this.richTextBox1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.richTextBox1.Location = new global::System.Drawing.Point(152, 185);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new global::System.Drawing.Size(357, 96);
			this.richTextBox1.TabIndex = 4;
			this.richTextBox1.Text = "Thank you for choosing us !\nWe promise constant updates and active supportive staff";
			this.panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel1.BackgroundImage");
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(651, 151);
			this.panel1.TabIndex = 5;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(52, 133);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(154, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "NaiveCheats - Home";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			base.ClientSize = new global::System.Drawing.Size(651, 470);
			base.Controls.Add(this.panel1);
			base.Controls.Add(this.richTextBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Home";
			this.Text = "Home";
			base.Load += new global::System.EventHandler(this.Home_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x0400003F RID: 63
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.RichTextBox richTextBox1;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000042 RID: 66
		private global::System.Windows.Forms.Label label1;
	}
}
