﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Impure.Object_Classes;
using Impure.Overlay;

namespace Impure
{
	// Token: 0x02000011 RID: 17
	public partial class Cheatmenu : Window
	{
		// Token: 0x06000072 RID: 114 RVA: 0x000024AB File Offset: 0x000006AB
		public Cheatmenu()
		{
			this.InitializeComponent();
			Cheatmenu.self = this;
		}

		// Token: 0x06000073 RID: 115 RVA: 0x000024C2 File Offset: 0x000006C2
		private void MiniButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000024CD File Offset: 0x000006CD
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			Environment.Exit(0);
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00005684 File Offset: 0x00003884
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			base.Title = Helpers.RandomString(Helpers.Rnd.Next(8, 32));
			for (;;)
			{
				Process[] processesByName = Process.GetProcessesByName("RustClient");
				bool flag = processesByName.Length != 0;
				if (flag)
				{
					break;
				}
				Thread.Sleep(3000);
			}
			bigbrain.LoadMemory("RustClient");
			while (bigbrain.Memory.GetModuleBase(0) == 0UL || bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base) == 0UL)
			{
				Thread.Sleep(1000);
			}
			UnityFunctions.UnityPlayer_Address = bigbrain.Memory.GetModuleBase(0);
			UnityFunctions.BaseNetworkable = bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base);
			Cheatmenu.Overlay = new DRAW();
			Cheatmenu.Overlay.Initialize();
			Cheatmenu.Renderer = new Render();
			Cheatmenu.ObjectUpdater = new GameMem();
			Cheatmenu.Gamer = new Aimbot();
			Cheatmenu.LocalClass = new Local();
			Thread thread = new Thread(new ThreadStart(Cheatmenu.ObjectUpdater.UpdateEntityList));
			thread.Start();
			thread.IsBackground = true;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x000057B8 File Offset: 0x000039B8
		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Left && e.ButtonState == MouseButtonState.Pressed;
			if (flag)
			{
				base.DragMove();
			}
		}

		// Token: 0x06000077 RID: 119 RVA: 0x000024D7 File Offset: 0x000006D7
		private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
		}

		// Token: 0x06000078 RID: 120 RVA: 0x000024DA File Offset: 0x000006DA
		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			Options.CB_ESP_Bones = !Options.CB_ESP_Bones;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x000024EA File Offset: 0x000006EA
		private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
		{
			Options.CB_RecoilScale = true;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x000024F3 File Offset: 0x000006F3
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			Options.RecoilScale = (float)e.NewValue;
		}

		// Token: 0x04000037 RID: 55
		public static Window self;

		// Token: 0x04000038 RID: 56
		public static GameMem ObjectUpdater;

		// Token: 0x04000039 RID: 57
		public static DRAW Overlay;

		// Token: 0x0400003A RID: 58
		public static Local LocalClass;

		// Token: 0x0400003B RID: 59
		public static Render Renderer;

		// Token: 0x0400003C RID: 60
		public static Aimbot Gamer;
	}
}
