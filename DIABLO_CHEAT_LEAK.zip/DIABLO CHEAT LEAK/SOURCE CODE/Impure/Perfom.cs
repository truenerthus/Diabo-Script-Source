﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Impure
{
	// Token: 0x02000014 RID: 20
	public partial class Perfom : Form
	{
		// Token: 0x06000085 RID: 133 RVA: 0x00002532 File Offset: 0x00000732
		public Perfom()
		{
			this.InitializeComponent();
		}
	}
}
