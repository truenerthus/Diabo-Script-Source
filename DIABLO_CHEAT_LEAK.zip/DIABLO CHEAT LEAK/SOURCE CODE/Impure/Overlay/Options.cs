﻿using System;

namespace Impure.Overlay
{
	// Token: 0x02000020 RID: 32
	public static class Options
	{
		// Token: 0x040000C8 RID: 200
		public static float RecoilScale = 1000f;

		// Token: 0x040000C9 RID: 201
		public static float FOVChanger = 1000f;

		// Token: 0x040000CA RID: 202
		public static bool CB_waterWalk = false;

		// Token: 0x040000CB RID: 203
		public static bool CB_wateWrite = false;

		// Token: 0x040000CC RID: 204
		public static bool CB_Debug = false;

		// Token: 0x040000CD RID: 205
		public static bool CB_Spooder = false;

		// Token: 0x040000CE RID: 206
		public static bool CB_Flyz = false;

		// Token: 0x040000CF RID: 207
		public static bool CB_Eoka = false;

		// Token: 0x040000D0 RID: 208
		public static bool CB_RecoilScale = false;

		// Token: 0x040000D1 RID: 209
		public static bool CB_ExtendedMelee = false;

		// Token: 0x040000D2 RID: 210
		public static bool CB_Bright = false;

		// Token: 0x040000D3 RID: 211
		public static bool CB_Cave = false;

		// Token: 0x040000D4 RID: 212
		public static bool CB_MountAim = false;

		// Token: 0x040000D5 RID: 213
		public static bool CB_Gravity = false;

		// Token: 0x040000D6 RID: 214
		public static bool CB_MountAimv = false;

		// Token: 0x040000D7 RID: 215
		public static bool Bar_THICC = false;

		// Token: 0x040000D8 RID: 216
		public static bool EXPLOSIVE = false;

		// Token: 0x040000D9 RID: 217
		public static bool tc = false;

		// Token: 0x040000DA RID: 218
		public static bool lolll = false;

		// Token: 0x040000DB RID: 219
		public static bool walkkkwater2 = false;

		// Token: 0x040000DC RID: 220
		public static bool speedhackingtest1 = false;

		// Token: 0x040000DD RID: 221
		public static bool ooofooofofofo = false;

		// Token: 0x040000DE RID: 222
		public static bool NoSpread = false;

		// Token: 0x040000DF RID: 223
		public static bool fakelag = false;

		// Token: 0x040000E0 RID: 224
		public static bool slidewalk = false;

		// Token: 0x040000E1 RID: 225
		public static bool silantaim = false;

		// Token: 0x040000E2 RID: 226
		public static bool CB_X_CROSS = false;

		// Token: 0x040000E3 RID: 227
		public static bool CB_Y_CROSS = false;

		// Token: 0x040000E4 RID: 228
		public static bool CB_C_CROSS = false;

		// Token: 0x040000E5 RID: 229
		public static bool CB_SNAPLINE = false;

		// Token: 0x040000E6 RID: 230
		public static bool CB_RADAR = false;

		// Token: 0x040000E7 RID: 231
		public static bool CB_FATBULL = false;

		// Token: 0x040000E8 RID: 232
		public static bool CB_TESTING = false;

		// Token: 0x040000E9 RID: 233
		public static bool CB_FATBULLET2 = false;

		// Token: 0x040000EA RID: 234
		public static bool CB_Shotgun = false;

		// Token: 0x040000EB RID: 235
		public static bool sprintaim = false;

		// Token: 0x040000EC RID: 236
		public static bool jumpaim = false;

		// Token: 0x040000ED RID: 237
		public static bool tracers = false;

		// Token: 0x040000EE RID: 238
		public static bool waterspeed = false;

		// Token: 0x040000EF RID: 239
		public static bool speeeedhack = false;

		// Token: 0x040000F0 RID: 240
		public static bool RADAR2 = false;

		// Token: 0x040000F1 RID: 241
		public static bool TESTING1 = false;

		// Token: 0x040000F2 RID: 242
		public static bool TESTING2 = false;

		// Token: 0x040000F3 RID: 243
		public static bool FastMED = false;

		// Token: 0x040000F4 RID: 244
		public static bool Loll1 = false;

		// Token: 0x040000F5 RID: 245
		public static bool fastbulletts = false;

		// Token: 0x040000F6 RID: 246
		public static bool discord = false;

		// Token: 0x040000F7 RID: 247
		public static bool waterfly = false;

		// Token: 0x040000F8 RID: 248
		public static bool FOVChangerr = false;

		// Token: 0x040000F9 RID: 249
		public static bool MAINFOVChangerr = false;

		// Token: 0x040000FA RID: 250
		public static bool FOVCircle = false;

		// Token: 0x040000FB RID: 251
		public static bool CB_Aimbot = false;

		// Token: 0x040000FC RID: 252
		public static bool CB_Aimbot_Nodes = false;

		// Token: 0x040000FD RID: 253
		public static bool CB_Randomaim = false;

		// Token: 0x040000FE RID: 254
		public static bool CB_ESP_Players = false;

		// Token: 0x040000FF RID: 255
		public static bool CB_ESP_NPC = false;

		// Token: 0x04000100 RID: 256
		public static bool CB_ESP_Berry = false;

		// Token: 0x04000101 RID: 257
		public static bool CB_ESP_Bones = false;

		// Token: 0x04000102 RID: 258
		public static bool CB_ESP_Sleepers = false;

		// Token: 0x04000103 RID: 259
		public static bool CB_ESP_Sulfur = false;

		// Token: 0x04000104 RID: 260
		public static bool CB_ESP_Metal = false;

		// Token: 0x04000105 RID: 261
		public static bool CB_ESP_Stone = false;

		// Token: 0x04000106 RID: 262
		public static bool CB_ESP_Animals = false;

		// Token: 0x04000107 RID: 263
		public static bool CB_ESP_Vehicles = false;

		// Token: 0x04000108 RID: 264
		public static bool CB_ESP_Barrels = false;

		// Token: 0x04000109 RID: 265
		public static bool CB_ESP_Traps = false;

		// Token: 0x0400010A RID: 266
		public static bool CB_ESP_HighLoot = false;

		// Token: 0x0400010B RID: 267
		public static bool CB_ESP_LowLoot = false;

		// Token: 0x0400010C RID: 268
		public static bool CB_ESP_Supply = false;

		// Token: 0x0400010D RID: 269
		public static bool CB_ESP_Bags = false;

		// Token: 0x0400010E RID: 270
		public static bool CB_ESP_Food = false;

		// Token: 0x0400010F RID: 271
		public static bool CB_ESP_Hemp = false;

		// Token: 0x04000110 RID: 272
		public static bool CB_ESP_Stashes = false;

		// Token: 0x04000111 RID: 273
		public static bool CB_ESP_DroppedGuns = false;

		// Token: 0x04000112 RID: 274
		public static bool CB_ESP_DroppedItems = false;

		// Token: 0x04000113 RID: 275
		public static bool CB_ESP_Heli = false;

		// Token: 0x04000114 RID: 276
		public static bool CB_ESP_TC = false;

		// Token: 0x04000115 RID: 277
		public static bool CB_ESP_Electrical = false;

		// Token: 0x04000116 RID: 278
		public static bool CB_ESP_ShipWreck = false;

		// Token: 0x04000117 RID: 279
		public static bool CB_ESP_Ammo = false;

		// Token: 0x04000118 RID: 280
		public static bool CB_ESP_Snap = false;

		// Token: 0x04000119 RID: 281
		public static bool CB_ESP_BOX = false;

		// Token: 0x0400011A RID: 282
		public static bool CB_ESP_VIS = true;

		// Token: 0x0400011B RID: 283
		public static bool CB_ESP_VIS_AIM = true;
	}
}
