﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using GameOverlay.Drawing;
using Impure.Object_Classes;
using MDriver.MEME;

namespace Impure.Overlay
{
	// Token: 0x02000021 RID: 33
	public class Render
	{
		// Token: 0x060000C9 RID: 201
		[DllImport("user32.dll")]
		public static extern int GetKeyState(int vKey);

		// Token: 0x060000CA RID: 202 RVA: 0x00007468 File Offset: 0x00005668
		public static float Clamp(float value, float min, float max)
		{
			return ((double)value < (double)min) ? min : (((double)value > (double)max) ? max : value);
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00007490 File Offset: 0x00005690
		public static float Scale(int base_size, float Distance)
		{
			float num = 2.5f * (float)Math.Pow(0.95, (double)(1f * Distance + -100f));
			return Render.Clamp(num / 8f + (float)base_size, (float)base_size, (float)base_size * 3f);
		}

		// Token: 0x060000CC RID: 204 RVA: 0x000074E0 File Offset: 0x000056E0
		public static float Scale2(int base_size, float Distance)
		{
			float num = 2.5f * (float)Math.Pow(0.95, (double)(1f * Distance + -100f));
			return num / 8f + (float)base_size;
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00007520 File Offset: 0x00005720
		public static float Scale3(int base_size, float Distance, float Scale)
		{
			return (float)base_size / (Distance / (Render.FOV_Max / Render.FOV)) * Scale;
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00007544 File Offset: 0x00005744
		public Rectangle MakeRect(Requests.Vector2.Vector2f Base_Pos, float Distance, int left, int top, int right, int bottom)
		{
			return new Rectangle(Base_Pos.X - Render.Scale3(left, Distance, 12f), Base_Pos.Y - Render.Scale3(top, Distance, 12f), Base_Pos.X + Render.Scale3(right, Distance, 12f), Base_Pos.Y + Render.Scale3(bottom, Distance, 12f));
		}

		// Token: 0x060000CF RID: 207 RVA: 0x000075B0 File Offset: 0x000057B0
		public static float GetDistance(Requests.Vector3.Vector3f value1, Requests.Vector3.Vector3f value2)
		{
			float num = value1.X - value2.X;
			float num2 = value1.X - value2.Y;
			float num3 = value1.Z - value2.Z;
			return (float)Math.Sqrt((double)(num * num + num2 * num2 + num3 * num3));
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00007604 File Offset: 0x00005804
		public void Loop()
		{
			Thread.Sleep(2000);
			for (;;)
			{
				Graphics graphics = Cheatmenu.Overlay._graphics;
				graphics.BeginScene();
				graphics.ClearScene();
				bool flag = Local.LocalPlayer == null;
				if (flag)
				{
					graphics.EndScene();
				}
				else
				{
					bool flag2 = Requests.IsValidPtr(Render.Main_Camera);
					if (flag2)
					{
						Render.FOV = 75f;
						bool flag3 = !Options.FOVCircle;
						if (flag3)
						{
							graphics.OutlineCircle(DRAW.Black, DRAW.Radical_Red, this.ScreenCenter.X, this.ScreenCenter.Y, Render.aimfov, 1f);
						}
						Requests.ViewMatrix viewMatrix = Requests.ViewMatrix.ReadViewMatrix(Render.Main_Camera);
						Requests.Vector3.Vector3f vector3f = bigbrain.Memory.ReadVector3f(Render.Main_Camera + 328UL);
						bool loll = Options.Loll1;
						if (loll)
						{
							graphics.FillCircle(DRAW.Red, (float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2), 1f);
							graphics.DrawLine(DRAW.Red, (float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2 + 15), (float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2 + 5), 1f);
							graphics.DrawLine(DRAW.Red, (float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2 - 15), (float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2 - 5), 1f);
							graphics.DrawLine(DRAW.Red, (float)(Render.screen_Width / 2 + 15), (float)(Render.screen_Height / 2), (float)(Render.screen_Width / 2 + 5), (float)(Render.screen_Height / 2), 1f);
							graphics.DrawLine(DRAW.Red, (float)(Render.screen_Width / 2 - 15), (float)(Render.screen_Height / 2), (float)(Render.screen_Width / 2 - 5), (float)(Render.screen_Height / 2), 1f);
						}
						this.xft = vector3f.X;
						this.yft = vector3f.Z;
						bool flag4 = CachedList.Players != null;
						if (flag4)
						{
							PlayerClass playerClass = null;
							float num = 99999f;
							foreach (KeyValuePair<ulong, PlayerClass> keyValuePair in CachedList.GetSafePlayers(false))
							{
								PlayerClass value = keyValuePair.Value;
								Requests.Vector3.Vector3f position = value.Position;
								bool isLocalPlayer = value.isLocalPlayer;
								if (!isLocalPlayer)
								{
									bool isDead = value.IsDead;
									if (!isDead)
									{
										bool flag5 = value.flag == 16 && !Options.CB_ESP_Sleepers;
										if (!flag5)
										{
											SolidBrush solidBrush = DRAW.White;
											bool isNPC = value.IsNPC;
											if (isNPC)
											{
												solidBrush = DRAW.Gray;
											}
											else
											{
												bool isFriend = value.IsFriend;
												if (isFriend)
												{
													solidBrush = DRAW.Hot_Magenta;
												}
												else
												{
													bool isVisable = value.IsVisable;
													if (isVisable)
													{
														solidBrush = DRAW.Pinkish_Red_Neon;
													}
												}
											}
											float num2 = bigbrain.Memory.ReadFloat(value._ComponentAddress + Offsets.BaseCombatEntity.health);
											bool flag6 = (double)num2 > 0.0 && (double)num2 < 2000.0;
											if (flag6)
											{
											}
											float num3 = Requests.Vector3.Vector3f.Distance(vector3f, position);
											bool flag7 = num3 < value.Render_Distance;
											if (flag7)
											{
												Requests.Vector2.Vector2f vector2f = (UnityFunctions.getBoneScreen(value.tryGetBone(4), viewMatrix) + UnityFunctions.getBoneScreen(value.tryGetBone(15), viewMatrix)) / new Requests.Vector2.Vector2f(2f, 2f);
												Requests.Vector2.Vector2f vector2f2 = (UnityFunctions.getBoneScreen(value.tryGetBone(4), viewMatrix) + UnityFunctions.getBoneScreen(value.tryGetBone(49), viewMatrix)) / new Requests.Vector2.Vector2f(2f, 2f);
												bool flag8 = vector2f != Requests.Vector2.Vector2f.Zero;
												if (flag8)
												{
													bool flag9 = vector2f.X < 2f || vector2f.Y < 2f || vector2f.X > (float)Render.screen_Width || vector2f.Y > (float)Render.screen_Height;
													if (!flag9)
													{
														string playerName = value.PlayerName;
														graphics.DrawText(DRAW._font, Render.Clamp((float)(15.0 / ((double)num3 * 0.100000001490116)), (float)this.Min_Size, (float)this.Max_Size), DRAW.Red, (float)((double)vector2f2.X - (double)playerName.Length - (double)Render.Clamp((float)(75.0 / ((double)num3 * 0.100000001490116)), 8f, 35f)), (float)((double)vector2f2.Y - 25.0 - 25.0 / ((double)num3 * 0.100000001490116)), playerName + " ");
														graphics.DrawText(DRAW._font, solidBrush, vector2f.X, vector2f.Y, string.Concat(new string[]
														{
															Math.Round((double)num3).ToString(),
															"M\n",
															value.HeldItem,
															"\n",
															num2.ToString(),
															"\n"
														}));
														int num4 = (int)((double)vector2f.Y - (double)vector2f2.Y) + 10;
														bool flag10 = (double)num3 >= 5.0;
														if (flag10)
														{
															bool flag11 = !Options.tracers;
															if (flag11)
															{
																graphics.DrawHorizontalProgressBar(DRAW.Blizzard_Blue, DRAW.Green, Rectangle.Create(vector2f.X - Render.Clamp((float)(70.0 / ((double)num3 * 0.100000001490116)), 8f, 70f), vector2f2.Y - 5f, Render.Clamp((float)(6.0 / ((double)num3 * 0.0500000007450581)), 3f, 6f), (float)num4), 1f, num2);
															}
														}
														Requests.Vector2.Vector2f boneScreen = UnityFunctions.getBoneScreen(value.HeadBone, viewMatrix);
														Rectangle rectangle = this.MakeRect(UnityFunctions.getBoneScreen(value.tryGetBone(1), viewMatrix), num3, 15, 40, 15, 40);
														graphics.OutlineRectangle(DRAW.Black, solidBrush, rectangle, 2f);
														float num5 = Requests.Vector2.Vector2f.Distance(this.ScreenCenter, boneScreen);
														bool flag12 = num5 < num && !value.IsFriend && num3 < 250f && num5 < Render.aimfov && value.IsVisable;
														if (flag12)
														{
															num = num5;
															playerClass = value;
														}
														bool flag13 = num3 < value.Bone_Render_Distance && Options.CB_ESP_Bones;
														if (flag13)
														{
															Requests.Vector2.Vector2f boneScreen2 = UnityFunctions.getBoneScreen(value.tryGetBone(46), viewMatrix);
															Requests.Vector2.Vector2f boneScreen3 = UnityFunctions.getBoneScreen(value.tryGetBone(0), viewMatrix);
															Requests.Vector2.Vector2f boneScreen4 = UnityFunctions.getBoneScreen(value.tryGetBone(55), viewMatrix);
															Requests.Vector2.Vector2f boneScreen5 = UnityFunctions.getBoneScreen(value.tryGetBone(56), viewMatrix);
															Requests.Vector2.Vector2f boneScreen6 = UnityFunctions.getBoneScreen(value.tryGetBone(57), viewMatrix);
															Requests.Vector2.Vector2f boneScreen7 = UnityFunctions.getBoneScreen(value.tryGetBone(24), viewMatrix);
															Requests.Vector2.Vector2f boneScreen8 = UnityFunctions.getBoneScreen(value.tryGetBone(25), viewMatrix);
															Requests.Vector2.Vector2f boneScreen9 = UnityFunctions.getBoneScreen(value.tryGetBone(26), viewMatrix);
															Requests.Vector2.Vector2f boneScreen10 = UnityFunctions.getBoneScreen(value.tryGetBone(13), viewMatrix);
															Requests.Vector2.Vector2f boneScreen11 = UnityFunctions.getBoneScreen(value.tryGetBone(14), viewMatrix);
															Requests.Vector2.Vector2f boneScreen12 = UnityFunctions.getBoneScreen(value.tryGetBone(15), viewMatrix);
															Requests.Vector2.Vector2f boneScreen13 = UnityFunctions.getBoneScreen(value.tryGetBone(1), viewMatrix);
															Requests.Vector2.Vector2f boneScreen14 = UnityFunctions.getBoneScreen(value.tryGetBone(2), viewMatrix);
															Requests.Vector2.Vector2f boneScreen15 = UnityFunctions.getBoneScreen(value.tryGetBone(3), viewMatrix);
															graphics.DrawLine(solidBrush, boneScreen2.X, boneScreen2.Y, boneScreen.X, boneScreen.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen2.X, boneScreen2.Y, boneScreen7.X, boneScreen7.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen7.X, boneScreen7.Y, boneScreen8.X, boneScreen8.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen8.X, boneScreen8.Y, boneScreen9.X, boneScreen9.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen2.X, boneScreen2.Y, boneScreen4.X, boneScreen4.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen4.X, boneScreen4.Y, boneScreen5.X, boneScreen5.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen5.X, boneScreen5.Y, boneScreen6.X, boneScreen6.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen2.X, boneScreen2.Y, boneScreen3.X, boneScreen3.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen3.X, boneScreen3.Y, boneScreen10.X, boneScreen10.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen10.X, boneScreen10.Y, boneScreen11.X, boneScreen11.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen11.X, boneScreen11.Y, boneScreen12.X, boneScreen12.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen3.X, boneScreen3.Y, boneScreen13.X, boneScreen13.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen13.X, boneScreen13.Y, boneScreen14.X, boneScreen14.Y, 2f);
															graphics.DrawLine(solidBrush, boneScreen14.X, boneScreen14.Y, boneScreen15.X, boneScreen15.Y, 2f);
														}
													}
												}
											}
										}
									}
								}
							}
							bool flag14 = playerClass != null;
							if (flag14)
							{
								bool flag15 = !Aimbot.HasTarget;
								if (flag15)
								{
									Aimbot.TargetPlayer = playerClass;
								}
								Requests.Vector3.Vector3f bonePosition = UnityFunctions.GetBonePosition(playerClass.HeadBone);
								Requests.Vector2.Vector2f vector2f3 = UnityFunctions.WorldToScreen(bonePosition, viewMatrix);
								bool flag16 = bonePosition != Requests.Vector3.Vector3f.Zero;
								if (flag16)
								{
									int keyState = Render.GetKeyState(113);
									bool flag17 = (keyState & 32768) != 0;
									if (flag17)
									{
										bool flag18 = !PlayerClass.Friends.Contains(playerClass.PlayerName);
										if (flag18)
										{
											PlayerClass.Friends.Add(playerClass.PlayerName);
										}
									}
								}
							}
							else
							{
								bool flag19 = !Aimbot.HasTarget;
								if (flag19)
								{
									Aimbot.TargetPlayer = null;
								}
							}
						}
						bool flag20 = CachedList.LootItems != null;
						if (flag20)
						{
							Requests.Vector2.Vector2f vector2f4 = default(Requests.Vector2.Vector2f);
							foreach (KeyValuePair<ulong, LootItemClass> keyValuePair2 in CachedList.GetSafeLoot(false))
							{
								LootItemClass value2 = keyValuePair2.Value;
								Requests.Vector3.Vector3f position2 = value2.Position;
								float num6 = Requests.Vector3.Vector3f.Distance(vector3f, position2);
								bool flag21 = num6 < value2.Render_Distance;
								if (flag21)
								{
									vector2f4 = UnityFunctions.WorldToScreen(position2, viewMatrix);
									bool flag22 = vector2f4 != Requests.Vector2.Vector2f.Zero;
									if (flag22)
									{
										bool flag23 = vector2f4.X < 1f || vector2f4.Y < 1f || vector2f4.X > (float)Render.screen_Width || vector2f4.Y > (float)Render.screen_Height;
										if (!flag23)
										{
											bool flag24 = false;
											Rectangle rectangle2;
											rectangle2..ctor(0, 0, 0, 0);
											bool flag25 = value2.Type == LootItemClass.LootType.Ores;
											if (flag25)
											{
												flag24 = false;
												rectangle2 = this.MakeRect(vector2f4, num6, 50, 50, 50, 50);
											}
											else
											{
												bool flag26 = value2.Type == LootItemClass.LootType.Barrel;
												if (flag26)
												{
													flag24 = false;
													rectangle2 = this.MakeRect(vector2f4, num6, 25, 40, 25, 40);
												}
												else
												{
													bool flag27 = value2.Type == LootItemClass.LootType.Hemp;
													if (flag27)
													{
														flag24 = false;
														rectangle2 = this.MakeRect(vector2f4, num6, 15, 30, 15, 30);
													}
													else
													{
														bool flag28 = value2.Type == LootItemClass.LootType.Food;
														if (flag28)
														{
															flag24 = false;
															rectangle2 = this.MakeRect(vector2f4, num6, 15, 15, 15, 15);
														}
														else
														{
															bool flag29 = value2.Type == LootItemClass.LootType.Loot_Elite;
															if (flag29)
															{
																flag24 = false;
																rectangle2 = this.MakeRect(vector2f4, num6, 35, 20, 35, 20);
															}
															else
															{
																bool flag30 = value2.Type == LootItemClass.LootType.Loot_Basic;
																if (flag30)
																{
																	flag24 = false;
																	rectangle2 = this.MakeRect(vector2f4, num6, 35, 35, 35, 35);
																}
																else
																{
																	bool flag31 = value2.Type == LootItemClass.LootType.Ore_Bonus;
																	if (flag31)
																	{
																		bool flag32 = num6 < 5f;
																		if (flag32)
																		{
																			string heldItem = Local.LocalPlayer.HeldItem;
																			bool flag33 = bigbrain.Memory.Readbyte(value2._ComponentAddress + Offsets.BaseNetworkable.IsDestroyed) == 0 && Local.LocalPlayer.HeldWeaponCategory == 5;
																			if (flag33)
																			{
																				Requests.Vector3.Vector3f localPos = bigbrain.Memory.ReadVector3f(Aimbot.Camer_Pos);
																				Requests.Vector3.Vector3f position3 = value2.Position;
																				position3.Y -= 0.1f;
																				bool cb_Aimbot_Nodes = Options.CB_Aimbot_Nodes;
																				if (cb_Aimbot_Nodes)
																				{
																					bool flag34 = Options.CB_ExtendedMelee && num6 < 5f;
																					if (flag34)
																					{
																						bigbrain.Memory.WriteVector2f(Aimbot.Input, Aimbot.CalcAngles(localPos, position3));
																					}
																					else
																					{
																						bool flag35 = !Options.CB_ExtendedMelee && num6 < 2f;
																						if (flag35)
																						{
																							bigbrain.Memory.WriteVector2f(Aimbot.Input, Aimbot.CalcAngles(localPos, position3));
																						}
																					}
																				}
																			}
																		}
																		continue;
																	}
																}
															}
														}
													}
												}
											}
											bool flag36 = flag24;
											if (flag36)
											{
												graphics.OutlineRectangle(value2.Color, value2.Color, rectangle2, 1f);
											}
											else
											{
												graphics.DrawText(DRAW._font, 14f, value2.Color, vector2f4.X, vector2f4.Y, value2.GameObjectNameCleaned + "\n" + Math.Round((double)num6).ToString() + "M");
											}
										}
									}
								}
							}
						}
					}
					graphics.EndScene();
					Thread.Sleep(1);
				}
			}
		}

		// Token: 0x0400011C RID: 284
		public static int screen_Width = Screen.PrimaryScreen.Bounds.Width;

		// Token: 0x0400011D RID: 285
		public static int screen_Height = Screen.PrimaryScreen.Bounds.Height;

		// Token: 0x0400011E RID: 286
		public Requests.Vector2.Vector2f ScreenCenter = new Requests.Vector2.Vector2f((float)(Render.screen_Width / 2), (float)(Render.screen_Height / 2));

		// Token: 0x0400011F RID: 287
		public static ulong Main_Camera = 0UL;

		// Token: 0x04000120 RID: 288
		public int Min_Size = 10;

		// Token: 0x04000121 RID: 289
		public int Max_Size = 35;

		// Token: 0x04000122 RID: 290
		public static float aimfov = 100f;

		// Token: 0x04000123 RID: 291
		public static float fovchange = 100f;

		// Token: 0x04000124 RID: 292
		public static float FOV_Max = 75f;

		// Token: 0x04000125 RID: 293
		public static float FOV = 100f;

		// Token: 0x04000126 RID: 294
		public static ulong FOV_Address = 0UL;

		// Token: 0x04000127 RID: 295
		public float Render_distance = 500f;

		// Token: 0x04000128 RID: 296
		private float xb4;

		// Token: 0x04000129 RID: 297
		private float yb4;

		// Token: 0x0400012A RID: 298
		private float xft;

		// Token: 0x0400012B RID: 299
		private float yft;

		// Token: 0x0400012C RID: 300
		private float cav;

		// Token: 0x0400012D RID: 301
		private float cav2;

		// Token: 0x0400012E RID: 302
		private float oldX;

		// Token: 0x0400012F RID: 303
		private float oldZ;

		// Token: 0x04000130 RID: 304
		private int ctr = 0;

		// Token: 0x04000131 RID: 305
		private bool lastn0 = false;

		// Token: 0x04000132 RID: 306
		public static Requests.Vector3.Vector3f[] BULLSHIT = new Requests.Vector3.Vector3f[999999];
	}
}
