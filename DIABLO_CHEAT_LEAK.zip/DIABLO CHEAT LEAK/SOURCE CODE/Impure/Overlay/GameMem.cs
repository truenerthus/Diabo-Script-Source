﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Impure.Object_Classes;
using MDriver.MEME;

namespace Impure.Overlay
{
	// Token: 0x02000022 RID: 34
	public class GameMem
	{
		// Token: 0x060000D3 RID: 211 RVA: 0x00008580 File Offset: 0x00006780
		public void UpdateEntityList()
		{
			bool flag = false;
			for (;;)
			{
				Process[] processesByName = Process.GetProcessesByName("RustClient");
				bool flag2 = processesByName.Length == 0;
				if (flag2)
				{
					Render.Main_Camera = 0UL;
					Debug.WriteLine("Process Closed");
					for (;;)
					{
						Process[] processesByName2 = Process.GetProcessesByName("RustClient");
						bool flag3 = processesByName2.Length != 0;
						if (flag3)
						{
							break;
						}
						Thread.Sleep(3000);
					}
					bigbrain.LoadMemory("RustClient");
					while (bigbrain.Memory.GetModuleBase(0) == 0UL || bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base) == 0UL)
					{
						Thread.Sleep(3000);
					}
					UnityFunctions.UnityPlayer_Address = bigbrain.Memory.GetModuleBase(0);
					UnityFunctions.BaseNetworkable = bigbrain.Memory.ReadInt64(bigbrain.Memory.GetModuleBase(1) + UnityFunctions.BN_Base);
				}
				Render.Main_Camera = bigbrain.Memory.GetPointer(new ulong[]
				{
					UnityFunctions.FindTaggedObjectTAG(5) + 48UL,
					24UL,
					740UL
				});
				Aimbot.Camer_Pos = Render.Main_Camera + 328UL;
				Offsets.Sky_Dome = UnityFunctions.FindTaggedObject("Sky Dome");
				bool flag4 = Render.Main_Camera > 1000UL;
				if (flag4)
				{
					Dictionary<ulong, PlayerClass> safePlayers = CachedList.GetSafePlayers(true);
					foreach (KeyValuePair<ulong, PlayerClass> keyValuePair in safePlayers)
					{
						keyValuePair.Value.GC = true;
					}
					Dictionary<ulong, LootItemClass> safeLoot = CachedList.GetSafeLoot(true);
					foreach (KeyValuePair<ulong, LootItemClass> keyValuePair2 in safeLoot)
					{
						keyValuePair2.Value.GC = true;
					}
					Requests memory = bigbrain.Memory;
					Requests memory2 = bigbrain.Memory;
					ulong[] array = new ulong[]
					{
						0UL,
						0UL,
						16UL,
						40UL,
						16UL
					};
					array[0] = UnityFunctions.BaseNetworkable + 184UL;
					long num = (long)memory.ReadInt32(memory2.GetPointer(array));
					Requests memory3 = bigbrain.Memory;
					ulong[] array2 = new ulong[]
					{
						0UL,
						0UL,
						16UL,
						40UL,
						24UL,
						32UL
					};
					array2[0] = UnityFunctions.BaseNetworkable + 184UL;
					ulong pointer = memory3.GetPointer(array2);
					for (ulong num2 = 0UL; num2 <= (ulong)num; num2 += 1UL)
					{
						ulong num3 = bigbrain.Memory.ReadInt64(pointer + 8UL * num2);
						Requests memory4 = bigbrain.Memory;
						ulong[] array3 = new ulong[3];
						array3[0] = num3 + 16UL;
						array3[1] = 48UL;
						ulong pointer2 = memory4.GetPointer(array3);
						string text = bigbrain.Memory.ReadString(bigbrain.Memory.ReadInt64(pointer2 + 96UL), 124, false);
						string text2 = "";
						bool flag5 = text.Contains("/");
						if (flag5)
						{
							text2 = text.Substring(text.LastIndexOf("/") + 1);
						}
						short num4 = bigbrain.Memory.ReadInt16(pointer2 + 84UL);
						bool flag6 = text == "LocalPlayer";
						if (flag6)
						{
							PlayerClass playerClass = CachedList.SetupPlayer(safePlayers, pointer2);
							playerClass._ComponentAddress = num3;
							playerClass._gameObjectAddress = pointer2;
							playerClass.isLocalPlayer = true;
							Local.LocalPlayer = playerClass;
							Aimbot.Input = bigbrain.Memory.GetPointer(new ulong[]
							{
								num3 + Offsets.BasePlayer.input,
								Offsets.PlayerInput.bodyAngles
							});
						}
						else
						{
							bool cb_ESP_Players = Options.CB_ESP_Players;
							if (cb_ESP_Players)
							{
								bool flag7 = num4 == 6 && !text.Contains("npc");
								if (flag7)
								{
									PlayerClass playerClass2 = CachedList.SetupPlayer(safePlayers, pointer2);
									playerClass2._ComponentAddress = num3;
									playerClass2._gameObjectAddress = pointer2;
									bool flag8 = PlayerClass.Friends.Contains(playerClass2.PlayerName);
									if (flag8)
									{
										playerClass2.IsFriend = true;
									}
									playerClass2.HeadBone = 0UL;
									playerClass2.TransformAddress = 0UL;
									playerClass2.BoneDict = 0UL;
									playerClass2.cachedBones.Clear();
									goto IL_1308;
								}
							}
							bool cb_ESP_NPC = Options.CB_ESP_NPC;
							if (cb_ESP_NPC)
							{
								bool flag9 = num4 == 6 && text != "assets/prefabs/npc/scientist/scientistpeacekeeper.prefab";
								if (flag9)
								{
									PlayerClass playerClass3 = CachedList.SetupPlayer(safePlayers, pointer2);
									playerClass3._ComponentAddress = num3;
									playerClass3._gameObjectAddress = pointer2;
									playerClass3.IsNPC = true;
									playerClass3.PlayerName = "NPC";
									playerClass3.Render_Distance = 150f;
									playerClass3.Bone_Render_Distance = 75f;
									goto IL_1308;
								}
							}
							bool flag10 = Options.CB_ESP_Stone || Options.CB_ESP_Sulfur || Options.CB_ESP_Metal;
							if (flag10)
							{
								bool flag11 = text2.Contains("ore");
								if (flag11)
								{
									bool flag12 = !text2.Contains("bonus");
									if (flag12)
									{
										bool flag13 = text2.Contains("stone") && Options.CB_ESP_Stone;
										if (flag13)
										{
											LootItemClass lootItemClass = CachedList.SetupLoot(safeLoot, pointer2);
											lootItemClass._gameObjectAddress = pointer2;
											lootItemClass._ComponentAddress = num3;
											lootItemClass.Type = LootItemClass.LootType.Ores;
											lootItemClass.GameObjectNameCleaned = "Stone Ore";
											lootItemClass._Position = new Requests.Vector3.Vector3f(0f);
											lootItemClass._Position.Y = lootItemClass.Position.Y + 0.5f;
											lootItemClass.Color = DRAW.Blue;
										}
										bool flag14 = text2.Contains("metal") && Options.CB_ESP_Metal;
										if (flag14)
										{
											LootItemClass lootItemClass2 = CachedList.SetupLoot(safeLoot, pointer2);
											lootItemClass2._gameObjectAddress = pointer2;
											lootItemClass2._ComponentAddress = num3;
											lootItemClass2.Type = LootItemClass.LootType.Ores;
											lootItemClass2.GameObjectNameCleaned = "Metal Ore";
											lootItemClass2._Position = new Requests.Vector3.Vector3f(0f);
											lootItemClass2._Position.Y = lootItemClass2.Position.Y + 0.5f;
											lootItemClass2.Color = DRAW.Outrageous_Orange;
										}
										bool flag15 = text2.Contains("sulf") && Options.CB_ESP_Sulfur;
										if (flag15)
										{
											LootItemClass lootItemClass3 = CachedList.SetupLoot(safeLoot, pointer2);
											lootItemClass3._gameObjectAddress = pointer2;
											lootItemClass3._ComponentAddress = num3;
											lootItemClass3.Type = LootItemClass.LootType.Ores;
											lootItemClass3.GameObjectNameCleaned = "Sulfur Ore";
											lootItemClass3._Position = new Requests.Vector3.Vector3f(0f);
											lootItemClass3._Position.Y = lootItemClass3.Position.Y + 0.5f;
											lootItemClass3.Color = DRAW.Neon_Carrot;
										}
										goto IL_1308;
									}
									LootItemClass lootItemClass4 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass4._gameObjectAddress = pointer2;
									lootItemClass4._ComponentAddress = num3;
									lootItemClass4.Type = LootItemClass.LootType.Ore_Bonus;
								}
							}
							bool cb_ESP_Barrels = Options.CB_ESP_Barrels;
							if (cb_ESP_Barrels)
							{
								bool flag16 = text.Contains("barrel");
								if (flag16)
								{
									LootItemClass lootItemClass5 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass5._gameObjectAddress = pointer2;
									lootItemClass5._ComponentAddress = num3;
									lootItemClass5.Type = LootItemClass.LootType.Barrel;
									lootItemClass5._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass5._Position.Y = lootItemClass5.Position.Y + 0.5f;
									lootItemClass5.Color = DRAW.Fluorescent_Red;
									goto IL_1308;
								}
							}
							bool tc = Options.tc;
							if (tc)
							{
								bool flag17 = text == "assets/prefabs/deployable/tool cupboard/cupboard.tool.deployed.prefab";
								if (flag17)
								{
									LootItemClass lootItemClass6 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass6._gameObjectAddress = pointer2;
									lootItemClass6._ComponentAddress = num3;
									lootItemClass6.Type = LootItemClass.LootType.TC;
									lootItemClass6.GameObjectNameCleaned = "Tool Cupboared";
									lootItemClass6.Color = DRAW.Electric_Violet;
									lootItemClass6.Render_Distance = 150f;
									goto IL_1308;
								}
							}
							bool explosive = Options.EXPLOSIVE;
							if (explosive)
							{
								bool flag18 = text == "assets/prefabs/weapons/satchelcharge/effects/satchel-charge-explosion.prefab" || text == "assets/prefabs/weapons/satchelcharge/explosive.satchel.entity.prefab" || text == "assets/prefabs/tools/c4/explosive.timed.deployed.prefab" || text == "assets/prefabs/weapons/rocketlauncher/effects/rocket_explosion.prefab" || text == "assets/prefabs/weapons/rocketlauncher/rocket_launcher.entity.prefab" || text == "assets/prefabs/weapons/satchelcharge/explosive.satchel.deployed.prefab";
								if (flag18)
								{
									LootItemClass lootItemClass7 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass7._gameObjectAddress = pointer2;
									lootItemClass7._ComponentAddress = num3;
									lootItemClass7.Type = LootItemClass.LootType.Explosion;
									lootItemClass7.GameObjectNameCleaned = "ACTIVE RAID";
									lootItemClass7.Color = DRAW.Fluorescent_Green;
									lootItemClass7.Render_Distance = 2000f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Hemp = Options.CB_ESP_Hemp;
							if (cb_ESP_Hemp)
							{
								bool flag19 = text.Contains("hemp") && !text.Contains("seed");
								if (flag19)
								{
									LootItemClass lootItemClass8 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass8._gameObjectAddress = pointer2;
									lootItemClass8._ComponentAddress = num3;
									lootItemClass8.Type = LootItemClass.LootType.Hemp;
									lootItemClass8._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass8._Position.Y = lootItemClass8.Position.Y + 0.5f;
									lootItemClass8.Color = DRAW.Screamin_Green;
									lootItemClass8.Render_Distance = 100f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Food = Options.CB_ESP_Food;
							if (cb_ESP_Food)
							{
								bool flag20 = text.Contains("corn") || text.Contains("pumpkin") || text.Contains("mushrooms") || text.Contains("food") || (text.Contains("trash-pile-1") && !text.Contains("seed"));
								if (flag20)
								{
									LootItemClass lootItemClass9 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass9._gameObjectAddress = pointer2;
									lootItemClass9._ComponentAddress = num3;
									lootItemClass9.Type = LootItemClass.LootType.Food;
									lootItemClass9._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass9._Position.Y = lootItemClass9.Position.Y + 0.2f;
									lootItemClass9.Color = DRAW.Unmellow_Yellow;
									lootItemClass9.Render_Distance = 100f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Vehicles = Options.CB_ESP_Vehicles;
							if (cb_ESP_Vehicles)
							{
								bool flag21 = text == "assets/content/vehicles/scrap heli carrier/scraptransporthelicopter.prefab" || text == "assets/content/vehicles/minicopter/minicopter.entity.prefab" || text == "assets/content/vehicles/boats/rowboat/rowboat.prefab" || text == "assets/content/vehicles/boats/rhib/rhib.prefab" || text == "assets/rust.ai/nextai/testridablehorse.prefab";
								if (flag21)
								{
									LootItemClass lootItemClass10 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass10._gameObjectAddress = pointer2;
									lootItemClass10._ComponentAddress = num3;
									lootItemClass10.Type = LootItemClass.LootType.Vehicle;
									lootItemClass10.Color = DRAW.Electric_Lime;
									lootItemClass10.Render_Distance = 500f;
									goto IL_1308;
								}
							}
							bool cb_ESP_DroppedGuns = Options.CB_ESP_DroppedGuns;
							if (cb_ESP_DroppedGuns)
							{
								bool flag22 = text.Contains("rifle.") || text.Contains("smg.") || text.Contains("shotgun.") || text.Contains("pistol.") || text.Contains("lmg.") || text.Contains("multiplegrenadelauncher") || text.Contains("rocket.");
								if (flag22)
								{
									bool flag23 = text.Contains("(world)") && !text.Contains("ammo");
									if (flag23)
									{
										LootItemClass lootItemClass11 = CachedList.SetupLoot(safeLoot, pointer2);
										lootItemClass11._gameObjectAddress = pointer2;
										lootItemClass11._ComponentAddress = num3;
										lootItemClass11.Type = LootItemClass.LootType.Weapon;
										lootItemClass11._Position = new Requests.Vector3.Vector3f(0f);
										lootItemClass11.Color = DRAW.Razzle_Dazzle_Rose;
										lootItemClass11.Render_Distance = 250f;
										goto IL_1308;
									}
								}
							}
							bool cb_ESP_Ammo = Options.CB_ESP_Ammo;
							if (cb_ESP_Ammo)
							{
								bool flag24 = text.Contains("ammo.");
								if (flag24)
								{
									LootItemClass lootItemClass12 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass12._gameObjectAddress = pointer2;
									lootItemClass12._ComponentAddress = num3;
									lootItemClass12.Type = LootItemClass.LootType.Ammo;
									lootItemClass12.Color = DRAW.Razzle_Dazzle_Rose;
									lootItemClass12.Render_Distance = 275f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Animals = Options.CB_ESP_Animals;
							if (cb_ESP_Animals)
							{
								bool flag25 = text == "assets/rust.ai/agents/wolf/wolf.prefab" || text == "assets/rust.ai/agents/boar/boar.prefab" || text == "assets/rust.ai/agents/bear/bear.prefab" || text == "assets/rust.ai/agents/stag/stag.prefab" || text == "assets/rust.ai/agents/horse/horse.prefab";
								if (flag25)
								{
									LootItemClass lootItemClass13 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass13._gameObjectAddress = pointer2;
									lootItemClass13._ComponentAddress = num3;
									lootItemClass13.Type = LootItemClass.LootType.Animal;
									lootItemClass13.Color = DRAW.Green;
									lootItemClass13.Render_Distance = 150f;
									goto IL_1308;
								}
							}
							bool cb_ESP_HighLoot = Options.CB_ESP_HighLoot;
							if (cb_ESP_HighLoot)
							{
								bool flag26 = text == "assets/bundled/prefabs/radtown/crate_elite.prefab" || text == "assets/bundled/prefabs/radtown/crate_normal.prefab" || text == "assets/prefabs/deployable/chinooklockedcrate/codelockedhackablecrate.prefab" || text == "assets/prefabs/npc/m2bradley/bradley_crate.prefab" || text == "assets/prefabs/npc/patrol helicopter/heli_crate.prefab";
								if (flag26)
								{
									LootItemClass lootItemClass14 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass14._gameObjectAddress = pointer2;
									lootItemClass14._ComponentAddress = num3;
									lootItemClass14.Type = LootItemClass.LootType.Loot_Elite;
									lootItemClass14._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass14._Position.Y = lootItemClass14.Position.Y + 0.3f;
									lootItemClass14.Color = DRAW.Carnation_Pink;
									lootItemClass14.Render_Distance = 250f;
									goto IL_1308;
								}
							}
							bool cb_ESP_LowLoot = Options.CB_ESP_LowLoot;
							if (cb_ESP_LowLoot)
							{
								bool flag27 = text.Contains("mine") || text == "assets/bundled/prefabs/radtown/crate_basic.prefab" || text == "assets/bundled/prefabs/radtown/crate_normal.prefab" || text == "assets/bundled/prefabs/radtown/crate_normal_2.prefab" || text == "assets/bundled/prefabs/radtown/crate_normal_2_food.prefab" || text == "assets/bundled/prefabs/radtown/crate_normal_2_medical.prefab" || text == "assets/bundled/prefabs/radtown/crate_tools.prefab";
								if (flag27)
								{
									LootItemClass lootItemClass15 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass15._gameObjectAddress = pointer2;
									lootItemClass15._ComponentAddress = num3;
									lootItemClass15.Type = LootItemClass.LootType.Loot_Basic;
									lootItemClass15._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass15._Position.Y = lootItemClass15.Position.Y + 0.5f;
									lootItemClass15.Color = DRAW.Apricot;
									lootItemClass15.Render_Distance = 100f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Supply = Options.CB_ESP_Supply;
							if (cb_ESP_Supply)
							{
								bool flag28 = text == "assets/prefabs/misc/supply drop/supply_drop.prefab";
								if (flag28)
								{
									LootItemClass lootItemClass16 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass16._gameObjectAddress = pointer2;
									lootItemClass16._ComponentAddress = num3;
									lootItemClass16.Type = LootItemClass.LootType.SupplyDrop;
									lootItemClass16._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass16._Position.Y = lootItemClass16.Position.Y + 0.5f;
									lootItemClass16.Color = DRAW.Neon_Yellow;
									lootItemClass16.Render_Distance = 2000f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Berry = Options.CB_ESP_Berry;
							if (cb_ESP_Berry)
							{
								bool flag29 = text == "assets/bundled/prefabs/autospawn/collectable/berry-black/berry-black-collectable.prefab" || text == "assets/bundled/prefabs/autospawn/collectable/berry-green/berry-green-collectable.prefab" || text == "assets/bundled/prefabs/autospawn/collectable/berry-red/berry-red-collectable.prefab" || text == "assets/bundled/prefabs/autospawn/collectable/berry-yellow/berry-yellow-collectable.prefab" || text == "assets/bundled/prefabs/autospawn/collectable/berry-white/berry-white-collectable.prefab" || text == "assets/bundled/prefabs/autospawn/collectable/berry-blue/berry-blue-collectable.prefab";
								if (flag29)
								{
									LootItemClass lootItemClass17 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass17._gameObjectAddress = pointer2;
									lootItemClass17._ComponentAddress = num3;
									lootItemClass17._Position = new Requests.Vector3.Vector3f(0f);
									lootItemClass17._Position.Y = lootItemClass17.Position.Y + 0.5f;
									lootItemClass17.Color = DRAW.Cerulean;
									lootItemClass17.Render_Distance = 300f;
									goto IL_1308;
								}
							}
							bool cb_ESP_Bags = Options.CB_ESP_Bags;
							if (cb_ESP_Bags)
							{
								bool flag30 = num4 == 20009;
								if (flag30)
								{
									LootItemClass lootItemClass18 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass18._gameObjectAddress = pointer2;
									lootItemClass18._ComponentAddress = num3;
									lootItemClass18.Type = LootItemClass.LootType.Corpse;
									lootItemClass18.Color = DRAW.Red;
									lootItemClass18.Render_Distance = 200f;
									ulong num5 = bigbrain.Memory.ReadInt64(lootItemClass18._ComponentAddress + 656UL);
									int num6 = bigbrain.Memory.ReadInt32(num5 + 16UL);
									bool flag31 = text == "assets/prefabs/misc/item drop/item_drop_backpack.prefab";
									if (flag31)
									{
										bool flag32 = num6 > 0 && num6 < 32;
										if (flag32)
										{
											lootItemClass18.GameObjectNameCleaned = bigbrain.Memory.ReadString(num5 + 20UL, num6, true) + "Body";
										}
									}
									goto IL_1308;
								}
							}
							bool cb_ESP_Traps = Options.CB_ESP_Traps;
							if (cb_ESP_Traps)
							{
								bool flag33 = text == "assets/prefabs/deployable/landmine/landmine.prefab" || text == "assets/prefabs/npc/sam_site_turret/sam_site_turret_deployed.prefab" || text == "assets/prefabs/deployable/single shot trap/guntrap.deployed.prefab" || text == "assets/prefabs/deployable/bear trap/beartrap.prefab" || text == "assets/prefabs/deployable/floor spikes/spikes.floor.prefab" || text == "assets/prefabs/npc/flame turret/flameturret.deployed.prefab";
								if (flag33)
								{
									LootItemClass lootItemClass19 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass19._gameObjectAddress = pointer2;
									lootItemClass19._ComponentAddress = num3;
									lootItemClass19.Type = LootItemClass.LootType.Trap;
									lootItemClass19.Color = DRAW.Fluorescent_Red;
									lootItemClass19.Render_Distance = 25f;
									goto IL_1308;
								}
								bool flag34 = text == "assets/prefabs/npc/autoturret/autoturret_deployed.prefab";
								if (flag34)
								{
									LootItemClass lootItemClass20 = CachedList.SetupLoot(safeLoot, pointer2);
									lootItemClass20._gameObjectAddress = pointer2;
									lootItemClass20._ComponentAddress = num3;
									lootItemClass20.Type = LootItemClass.LootType.AutoTurret;
									lootItemClass20.Color = DRAW.Pinkish_Red_Neon;
									lootItemClass20.Render_Distance = 100f;
									goto IL_1308;
								}
								bool cb_ESP_Heli = Options.CB_ESP_Heli;
								if (cb_ESP_Heli)
								{
									bool flag35 = text.Contains("patrolhelicopter");
									if (flag35)
									{
										LootItemClass lootItemClass21 = CachedList.SetupLoot(safeLoot, pointer2);
										lootItemClass21._gameObjectAddress = pointer2;
										lootItemClass21._ComponentAddress = num3;
										lootItemClass21.Type = LootItemClass.LootType.PatrolHeli;
										lootItemClass21.Color = DRAW.Green;
										lootItemClass21.Render_Distance = 3000f;
										goto IL_1308;
									}
									bool flag36 = text.Contains("assets/prefabs/npc/m2bradley/bradleyapc.prefab");
									if (flag36)
									{
										LootItemClass lootItemClass22 = CachedList.SetupLoot(safeLoot, pointer2);
										lootItemClass22._gameObjectAddress = pointer2;
										lootItemClass22._ComponentAddress = num3;
										lootItemClass22.Type = LootItemClass.LootType.Brad;
										lootItemClass22.Color = DRAW.Bright_Green;
										lootItemClass22.Render_Distance = 300f;
										goto IL_1308;
									}
								}
							}
							bool cb_ESP_Stashes = Options.CB_ESP_Stashes;
							if (cb_ESP_Stashes)
							{
								bool flag37 = text == "assets/prefabs/deployable/small stash/small_stash_deployed.prefab";
								if (flag37)
								{
									bool flag38 = bigbrain.Memory.ReadInt32(bigbrain.Memory.GetPointer(new ulong[]
									{
										0UL,
										24UL,
										40UL,
										64UL,
										0UL,
										0UL
									})) == 2048;
									if (flag38)
									{
										LootItemClass lootItemClass23 = CachedList.SetupLoot(safeLoot, pointer2);
										lootItemClass23._gameObjectAddress = pointer2;
										lootItemClass23._ComponentAddress = num3;
										lootItemClass23.Type = LootItemClass.LootType.Ammo;
										lootItemClass23.GameObjectNameCleaned = "Small Stash";
										lootItemClass23.Color = DRAW.Apricot;
										lootItemClass23.Render_Distance = 300f;
									}
								}
							}
						}
						IL_1308:;
					}
					CachedList.Players = safePlayers;
					CachedList.LootItems = safeLoot;
				}
				else
				{
					Local.LocalPlayer = null;
				}
				bool flag39 = !flag;
				if (flag39)
				{
					flag = true;
					Thread thread = new Thread(new ThreadStart(Cheatmenu.LocalClass.Fast_Thread));
					thread.Start();
					thread.IsBackground = true;
					Thread thread2 = new Thread(new ThreadStart(Cheatmenu.LocalClass.Slow_Thread));
					thread2.Start();
					thread2.IsBackground = true;
					Thread thread3 = new Thread(new ThreadStart(Cheatmenu.Renderer.Loop));
					thread3.Start();
					thread3.IsBackground = true;
					Thread thread4 = new Thread(new ThreadStart(Cheatmenu.Gamer.GamerChair));
					thread4.Start();
					thread4.IsBackground = true;
					Thread thread5 = new Thread(new ThreadStart(Cheatmenu.Gamer.DumpPOS));
					thread5.Start();
					thread5.IsBackground = true;
				}
				Thread.Sleep(5000);
			}
		}
	}
}
