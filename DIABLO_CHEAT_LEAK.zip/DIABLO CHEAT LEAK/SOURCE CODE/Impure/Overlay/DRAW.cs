﻿using System;
using System.Windows.Forms;
using GameOverlay.Drawing;
using GameOverlay.Windows;
using MDriver.MEME;

namespace Impure.Overlay
{
	// Token: 0x0200001F RID: 31
	public class DRAW
	{
		// Token: 0x060000C3 RID: 195 RVA: 0x0000667C File Offset: 0x0000487C
		public DRAW()
		{
			this._window = new OverlayWindow(0, 0, DRAW.screen_Width, DRAW.screen_Height)
			{
				IsTopmost = true,
				IsVisible = true
			};
			this._window.SizeChanged += this._window_SizeChanged;
			this._graphics = new Graphics
			{
				MeasureFPS = true,
				Height = this._window.Height,
				Width = this._window.Width,
				PerPrimitiveAntiAliasing = true,
				TextAntiAliasing = true,
				UseMultiThreadedFactories = true,
				VSync = true,
				WindowHandle = IntPtr.Zero
			};
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00006750 File Offset: 0x00004950
		~DRAW()
		{
			this._graphics.Dispose();
			this._window.Dispose();
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00006794 File Offset: 0x00004994
		public void Initialize()
		{
			this._window.Create();
			this._graphics.WindowHandle = this._window.Handle;
			this._graphics.Setup();
			DRAW._font = this._graphics.CreateFont("Arial", 12f, false, false, false);
			DRAW.Clear = this._graphics.CreateSolidBrush(0, 0, 0, 0);
			DRAW.White_Washed = this._graphics.CreateSolidBrush(255, 255, 255, 75);
			DRAW.Red = this._graphics.CreateSolidBrush(237, 10, 63, 255);
			DRAW.Scarlet = this._graphics.CreateSolidBrush(253, 14, 53, 255);
			DRAW.Red_Orange = this._graphics.CreateSolidBrush(255, 104, 31, 255);
			DRAW.Orange = this._graphics.CreateSolidBrush(255, 136, 51, 255);
			DRAW.Yellow_Orange = this._graphics.CreateSolidBrush(255, 174, 66, 255);
			DRAW.Yellow = this._graphics.CreateSolidBrush(251, 232, 112, 255);
			DRAW.Green_Yellow = this._graphics.CreateSolidBrush(241, 231, 136, 255);
			DRAW.Yellow_Green = this._graphics.CreateSolidBrush(197, 225, 122, 255);
			DRAW.Green = this._graphics.CreateSolidBrush(58, 166, 85, 255);
			DRAW.Blue_Green = this._graphics.CreateSolidBrush(0, 149, 183, 255);
			DRAW.Cerulean = this._graphics.CreateSolidBrush(2, 164, 211, 255);
			DRAW.Blue = this._graphics.CreateSolidBrush(0, 102, 255, 255);
			DRAW.Bluetiful = this._graphics.CreateSolidBrush(60, 105, 231, 255);
			DRAW.Indigo = this._graphics.CreateSolidBrush(79, 105, 198, 255);
			DRAW.Blue_Violet = this._graphics.CreateSolidBrush(100, 86, 183, 255);
			DRAW.Violet = this._graphics.CreateSolidBrush(131, 89, 163, 255);
			DRAW.Red_Violet = this._graphics.CreateSolidBrush(187, 51, 133, 255);
			DRAW.Carnation_Pink = this._graphics.CreateSolidBrush(255, 166, 201, 255);
			DRAW.Violet_Red = this._graphics.CreateSolidBrush(247, 70, 138, 255);
			DRAW.Brown = this._graphics.CreateSolidBrush(175, 89, 62, 255);
			DRAW.Apricot = this._graphics.CreateSolidBrush(253, 213, 177, 255);
			DRAW.Black = this._graphics.CreateSolidBrush(0, 0, 0, 255);
			DRAW.Gray = this._graphics.CreateSolidBrush(139, 134, 128, 255);
			DRAW.White = this._graphics.CreateSolidBrush(255, 255, 255, 255);
			DRAW.Radical_Red = this._graphics.CreateSolidBrush(255, 53, 94, 255);
			DRAW.Wild_Watermelon = this._graphics.CreateSolidBrush(253, 91, 120, 255);
			DRAW.Outrageous_Orange = this._graphics.CreateSolidBrush(255, 96, 55, 255);
			DRAW.Atomic_Tangerine = this._graphics.CreateSolidBrush(255, 153, 102, 255);
			DRAW.Neon_Carrot = this._graphics.CreateSolidBrush(255, 153, 51, 255);
			DRAW.Sunglow = this._graphics.CreateSolidBrush(255, 204, 51, 255);
			DRAW.Laser_Lemon = this._graphics.CreateSolidBrush(255, 255, 102, 255);
			DRAW.Unmellow_Yellow = this._graphics.CreateSolidBrush(255, 255, 102, 255);
			DRAW.Electric_Lime = this._graphics.CreateSolidBrush(204, 255, 0, 255);
			DRAW.Screamin_Green = this._graphics.CreateSolidBrush(102, 255, 102, 255);
			DRAW.Magic_Mint = this._graphics.CreateSolidBrush(170, 240, 209, 255);
			DRAW.Blizzard_Blue = this._graphics.CreateSolidBrush(80, 191, 230, 255);
			DRAW.Shocking_Pink = this._graphics.CreateSolidBrush(255, 110, 255, 255);
			DRAW.Razzle_Dazzle_Rose = this._graphics.CreateSolidBrush(238, 52, 210, 255);
			DRAW.Hot_Magenta = this._graphics.CreateSolidBrush(255, 0, 204, 255);
			DRAW.Purple_Pizzazz = this._graphics.CreateSolidBrush(255, 0, 204, 255);
			DRAW.Bright_Chartreuse = this._graphics.CreateSolidBrush(223, 255, 17, 255);
			DRAW.Bright_Green = this._graphics.CreateSolidBrush(102, 255, 0, 255);
			DRAW.Bright_Magenta = this._graphics.CreateSolidBrush(255, 8, 232, 255);
			DRAW.Bright_Pink = this._graphics.CreateSolidBrush(254, 1, 177, 255);
			DRAW.Bright_Purple = this._graphics.CreateSolidBrush(190, 3, 253, 255);
			DRAW.Bright_Red = this._graphics.CreateSolidBrush(255, 0, 13, 255);
			DRAW.Bright_Saffron = this._graphics.CreateSolidBrush(255, 207, 9, 255);
			DRAW.Bright_Scarlet = this._graphics.CreateSolidBrush(252, 14, 52, 255);
			DRAW.Bright_Teal = this._graphics.CreateSolidBrush(1, 249, 198, 255);
			DRAW.Electric_Crimson = this._graphics.CreateSolidBrush(255, 0, 63, 255);
			DRAW.Electric_Cyan = this._graphics.CreateSolidBrush(15, 240, 252, 255);
			DRAW.Electric_Flamingo = this._graphics.CreateSolidBrush(252, 116, 253, 255);
			DRAW.Electric_Green = this._graphics.CreateSolidBrush(33, 252, 13, 255);
			DRAW.Electric_Indigo = this._graphics.CreateSolidBrush(102, 0, 255, 255);
			DRAW.Electric_Orange = this._graphics.CreateSolidBrush(255, 53, 3, 255);
			DRAW.Electric_Pink = this._graphics.CreateSolidBrush(255, 4, 144, 255);
			DRAW.Electric_Purple = this._graphics.CreateSolidBrush(191, 0, 255, 255);
			DRAW.Electric_Red = this._graphics.CreateSolidBrush(230, 0, 0, 255);
			DRAW.Electric_Sheep = this._graphics.CreateSolidBrush(85, 255, 255, 255);
			DRAW.Electric_Violet = this._graphics.CreateSolidBrush(143, 0, 241, 255);
			DRAW.Electric_Yellow = this._graphics.CreateSolidBrush(255, 252, 0, 255);
			DRAW.Fluorescent_Green = this._graphics.CreateSolidBrush(8, 255, 8, 255);
			DRAW.Fluorescent_Orange = this._graphics.CreateSolidBrush(255, 207, 0, 255);
			DRAW.Fluorescent_Pink = this._graphics.CreateSolidBrush(254, 20, 147, 255);
			DRAW.Fluorescent_Red = this._graphics.CreateSolidBrush(255, 85, 85, 255);
			DRAW.Fluorescent_Red_Orange = this._graphics.CreateSolidBrush(252, 132, 39, 255);
			DRAW.Fluorescent_Turquoise = this._graphics.CreateSolidBrush(0, 253, 255, 255);
			DRAW.Fluorescent_Yellow = this._graphics.CreateSolidBrush(204, 255, 2, 255);
			DRAW.Light_Neon_Pink = this._graphics.CreateSolidBrush(255, 17, 255, 255);
			DRAW.Neon_Blue = this._graphics.CreateSolidBrush(4, 217, 255, 255);
			DRAW.Neon_Fuchsia = this._graphics.CreateSolidBrush(254, 65, 100, 255);
			DRAW.Neon_Green = this._graphics.CreateSolidBrush(57, 255, 20, 255);
			DRAW.Neon_Pink = this._graphics.CreateSolidBrush(254, 1, 154, 255);
			DRAW.Neon_Purple = this._graphics.CreateSolidBrush(188, 19, 254, 255);
			DRAW.Neon_Red = this._graphics.CreateSolidBrush(255, 7, 58, 255);
			DRAW.Neon_Yellow = this._graphics.CreateSolidBrush(207, 255, 4, 255);
			DRAW.Pinkish_Red_Neon = this._graphics.CreateSolidBrush(255, 0, 85, 255);
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x000071AC File Offset: 0x000053AC
		private void _window_SizeChanged(object sender, OverlaySizeEventArgs e)
		{
			bool flag = this._graphics == null;
			if (!flag)
			{
				bool isInitialized = this._graphics.IsInitialized;
				if (isInitialized)
				{
					this._graphics.Resize(e.Width, e.Height);
				}
				else
				{
					this._graphics.Width = e.Width;
					this._graphics.Height = e.Height;
				}
			}
		}

		// Token: 0x04000073 RID: 115
		public static int screen_Width = Screen.PrimaryScreen.Bounds.Width;

		// Token: 0x04000074 RID: 116
		public static int screen_Height = Screen.PrimaryScreen.Bounds.Height;

		// Token: 0x04000075 RID: 117
		public Requests.Vector2.Vector2f ScreenCenter = new Requests.Vector2.Vector2f((float)(DRAW.screen_Width / 2), (float)(DRAW.screen_Height / 2));

		// Token: 0x04000076 RID: 118
		private readonly OverlayWindow _window;

		// Token: 0x04000077 RID: 119
		public readonly Graphics _graphics;

		// Token: 0x04000078 RID: 120
		public static Font _font;

		// Token: 0x04000079 RID: 121
		public static SolidBrush Clear;

		// Token: 0x0400007A RID: 122
		public static SolidBrush Red;

		// Token: 0x0400007B RID: 123
		public static SolidBrush Scarlet;

		// Token: 0x0400007C RID: 124
		public static SolidBrush Red_Orange;

		// Token: 0x0400007D RID: 125
		public static SolidBrush Orange;

		// Token: 0x0400007E RID: 126
		public static SolidBrush Yellow_Orange;

		// Token: 0x0400007F RID: 127
		public static SolidBrush Yellow;

		// Token: 0x04000080 RID: 128
		public static SolidBrush Green_Yellow;

		// Token: 0x04000081 RID: 129
		public static SolidBrush Yellow_Green;

		// Token: 0x04000082 RID: 130
		public static SolidBrush Green;

		// Token: 0x04000083 RID: 131
		public static SolidBrush Blue_Green;

		// Token: 0x04000084 RID: 132
		public static SolidBrush Cerulean;

		// Token: 0x04000085 RID: 133
		public static SolidBrush Blue;

		// Token: 0x04000086 RID: 134
		public static SolidBrush Bluetiful;

		// Token: 0x04000087 RID: 135
		public static SolidBrush Indigo;

		// Token: 0x04000088 RID: 136
		public static SolidBrush Blue_Violet;

		// Token: 0x04000089 RID: 137
		public static SolidBrush Violet;

		// Token: 0x0400008A RID: 138
		public static SolidBrush Red_Violet;

		// Token: 0x0400008B RID: 139
		public static SolidBrush Carnation_Pink;

		// Token: 0x0400008C RID: 140
		public static SolidBrush Violet_Red;

		// Token: 0x0400008D RID: 141
		public static SolidBrush Brown;

		// Token: 0x0400008E RID: 142
		public static SolidBrush Apricot;

		// Token: 0x0400008F RID: 143
		public static SolidBrush Black;

		// Token: 0x04000090 RID: 144
		public static SolidBrush Gray;

		// Token: 0x04000091 RID: 145
		public static SolidBrush White;

		// Token: 0x04000092 RID: 146
		public static SolidBrush White_Washed;

		// Token: 0x04000093 RID: 147
		public static SolidBrush Radical_Red;

		// Token: 0x04000094 RID: 148
		public static SolidBrush Wild_Watermelon;

		// Token: 0x04000095 RID: 149
		public static SolidBrush Outrageous_Orange;

		// Token: 0x04000096 RID: 150
		public static SolidBrush Atomic_Tangerine;

		// Token: 0x04000097 RID: 151
		public static SolidBrush Neon_Carrot;

		// Token: 0x04000098 RID: 152
		public static SolidBrush Sunglow;

		// Token: 0x04000099 RID: 153
		public static SolidBrush Laser_Lemon;

		// Token: 0x0400009A RID: 154
		public static SolidBrush Unmellow_Yellow;

		// Token: 0x0400009B RID: 155
		public static SolidBrush Electric_Lime;

		// Token: 0x0400009C RID: 156
		public static SolidBrush Screamin_Green;

		// Token: 0x0400009D RID: 157
		public static SolidBrush Magic_Mint;

		// Token: 0x0400009E RID: 158
		public static SolidBrush Blizzard_Blue;

		// Token: 0x0400009F RID: 159
		public static SolidBrush Shocking_Pink;

		// Token: 0x040000A0 RID: 160
		public static SolidBrush Razzle_Dazzle_Rose;

		// Token: 0x040000A1 RID: 161
		public static SolidBrush Hot_Magenta;

		// Token: 0x040000A2 RID: 162
		public static SolidBrush Purple_Pizzazz;

		// Token: 0x040000A3 RID: 163
		public static SolidBrush Bright_Chartreuse;

		// Token: 0x040000A4 RID: 164
		public static SolidBrush Bright_Green;

		// Token: 0x040000A5 RID: 165
		public static SolidBrush Bright_Magenta;

		// Token: 0x040000A6 RID: 166
		public static SolidBrush Bright_Pink;

		// Token: 0x040000A7 RID: 167
		public static SolidBrush Bright_Purple;

		// Token: 0x040000A8 RID: 168
		public static SolidBrush Bright_Red;

		// Token: 0x040000A9 RID: 169
		public static SolidBrush Bright_Saffron;

		// Token: 0x040000AA RID: 170
		public static SolidBrush Bright_Scarlet;

		// Token: 0x040000AB RID: 171
		public static SolidBrush Bright_Teal;

		// Token: 0x040000AC RID: 172
		public static SolidBrush Electric_Crimson;

		// Token: 0x040000AD RID: 173
		public static SolidBrush Electric_Cyan;

		// Token: 0x040000AE RID: 174
		public static SolidBrush Electric_Flamingo;

		// Token: 0x040000AF RID: 175
		public static SolidBrush Electric_Green;

		// Token: 0x040000B0 RID: 176
		public static SolidBrush Electric_Indigo;

		// Token: 0x040000B1 RID: 177
		public static SolidBrush Electric_Orange;

		// Token: 0x040000B2 RID: 178
		public static SolidBrush Electric_Pink;

		// Token: 0x040000B3 RID: 179
		public static SolidBrush Electric_Purple;

		// Token: 0x040000B4 RID: 180
		public static SolidBrush Electric_Red;

		// Token: 0x040000B5 RID: 181
		public static SolidBrush Electric_Sheep;

		// Token: 0x040000B6 RID: 182
		public static SolidBrush Electric_Violet;

		// Token: 0x040000B7 RID: 183
		public static SolidBrush Electric_Yellow;

		// Token: 0x040000B8 RID: 184
		public static SolidBrush Fluorescent_Green;

		// Token: 0x040000B9 RID: 185
		public static SolidBrush Fluorescent_Orange;

		// Token: 0x040000BA RID: 186
		public static SolidBrush Fluorescent_Pink;

		// Token: 0x040000BB RID: 187
		public static SolidBrush Fluorescent_Red;

		// Token: 0x040000BC RID: 188
		public static SolidBrush Fluorescent_Red_Orange;

		// Token: 0x040000BD RID: 189
		public static SolidBrush Fluorescent_Turquoise;

		// Token: 0x040000BE RID: 190
		public static SolidBrush Fluorescent_Yellow;

		// Token: 0x040000BF RID: 191
		public static SolidBrush Light_Neon_Pink;

		// Token: 0x040000C0 RID: 192
		public static SolidBrush Neon_Blue;

		// Token: 0x040000C1 RID: 193
		public static SolidBrush Neon_Fuchsia;

		// Token: 0x040000C2 RID: 194
		public static SolidBrush Neon_Green;

		// Token: 0x040000C3 RID: 195
		public static SolidBrush Neon_Pink;

		// Token: 0x040000C4 RID: 196
		public static SolidBrush Neon_Purple;

		// Token: 0x040000C5 RID: 197
		public static SolidBrush Neon_Red;

		// Token: 0x040000C6 RID: 198
		public static SolidBrush Neon_Yellow;

		// Token: 0x040000C7 RID: 199
		public static SolidBrush Pinkish_Red_Neon;
	}
}
