﻿using System;

namespace Impure.Utils
{
	// Token: 0x02000062 RID: 98
	internal class NTSTATUS
	{
		// Token: 0x02000063 RID: 99
		public enum NtStatus : uint
		{
			// Token: 0x040002A2 RID: 674
			Success,
			// Token: 0x040002A3 RID: 675
			Wait0 = 0U,
			// Token: 0x040002A4 RID: 676
			Wait1,
			// Token: 0x040002A5 RID: 677
			Wait2,
			// Token: 0x040002A6 RID: 678
			Wait3,
			// Token: 0x040002A7 RID: 679
			Wait63 = 63U,
			// Token: 0x040002A8 RID: 680
			Abandoned = 128U,
			// Token: 0x040002A9 RID: 681
			AbandonedWait0 = 128U,
			// Token: 0x040002AA RID: 682
			AbandonedWait1,
			// Token: 0x040002AB RID: 683
			AbandonedWait2,
			// Token: 0x040002AC RID: 684
			AbandonedWait3,
			// Token: 0x040002AD RID: 685
			AbandonedWait63 = 191U,
			// Token: 0x040002AE RID: 686
			UserApc,
			// Token: 0x040002AF RID: 687
			KernelApc = 256U,
			// Token: 0x040002B0 RID: 688
			Alerted,
			// Token: 0x040002B1 RID: 689
			Timeout,
			// Token: 0x040002B2 RID: 690
			Pending,
			// Token: 0x040002B3 RID: 691
			Reparse,
			// Token: 0x040002B4 RID: 692
			MoreEntries,
			// Token: 0x040002B5 RID: 693
			NotAllAssigned,
			// Token: 0x040002B6 RID: 694
			SomeNotMapped,
			// Token: 0x040002B7 RID: 695
			OpLockBreakInProgress,
			// Token: 0x040002B8 RID: 696
			VolumeMounted,
			// Token: 0x040002B9 RID: 697
			RxActCommitted,
			// Token: 0x040002BA RID: 698
			NotifyCleanup,
			// Token: 0x040002BB RID: 699
			NotifyEnumDir,
			// Token: 0x040002BC RID: 700
			NoQuotasForAccount,
			// Token: 0x040002BD RID: 701
			PrimaryTransportConnectFailed,
			// Token: 0x040002BE RID: 702
			PageFaultTransition = 272U,
			// Token: 0x040002BF RID: 703
			PageFaultDemandZero,
			// Token: 0x040002C0 RID: 704
			PageFaultCopyOnWrite,
			// Token: 0x040002C1 RID: 705
			PageFaultGuardPage,
			// Token: 0x040002C2 RID: 706
			PageFaultPagingFile,
			// Token: 0x040002C3 RID: 707
			CrashDump = 278U,
			// Token: 0x040002C4 RID: 708
			ReparseObject = 280U,
			// Token: 0x040002C5 RID: 709
			NothingToTerminate = 290U,
			// Token: 0x040002C6 RID: 710
			ProcessNotInJob,
			// Token: 0x040002C7 RID: 711
			ProcessInJob,
			// Token: 0x040002C8 RID: 712
			ProcessCloned = 297U,
			// Token: 0x040002C9 RID: 713
			FileLockedWithOnlyReaders,
			// Token: 0x040002CA RID: 714
			FileLockedWithWriters,
			// Token: 0x040002CB RID: 715
			Informational = 1073741824U,
			// Token: 0x040002CC RID: 716
			ObjectNameExists = 1073741824U,
			// Token: 0x040002CD RID: 717
			ThreadWasSuspended,
			// Token: 0x040002CE RID: 718
			WorkingSetLimitRange,
			// Token: 0x040002CF RID: 719
			ImageNotAtBase,
			// Token: 0x040002D0 RID: 720
			RegistryRecovered = 1073741833U,
			// Token: 0x040002D1 RID: 721
			Warning = 2147483648U,
			// Token: 0x040002D2 RID: 722
			GuardPageViolation,
			// Token: 0x040002D3 RID: 723
			DatatypeMisalignment,
			// Token: 0x040002D4 RID: 724
			Breakpoint,
			// Token: 0x040002D5 RID: 725
			SingleStep,
			// Token: 0x040002D6 RID: 726
			BufferOverflow,
			// Token: 0x040002D7 RID: 727
			NoMoreFiles,
			// Token: 0x040002D8 RID: 728
			HandlesClosed = 2147483658U,
			// Token: 0x040002D9 RID: 729
			PartialCopy = 2147483661U,
			// Token: 0x040002DA RID: 730
			DeviceBusy = 2147483665U,
			// Token: 0x040002DB RID: 731
			InvalidEaName = 2147483667U,
			// Token: 0x040002DC RID: 732
			EaListInconsistent,
			// Token: 0x040002DD RID: 733
			NoMoreEntries = 2147483674U,
			// Token: 0x040002DE RID: 734
			LongJump = 2147483686U,
			// Token: 0x040002DF RID: 735
			DllMightBeInsecure = 2147483691U,
			// Token: 0x040002E0 RID: 736
			Error = 3221225472U,
			// Token: 0x040002E1 RID: 737
			Unsuccessful,
			// Token: 0x040002E2 RID: 738
			NotImplemented,
			// Token: 0x040002E3 RID: 739
			InvalidInfoClass,
			// Token: 0x040002E4 RID: 740
			InfoLengthMismatch,
			// Token: 0x040002E5 RID: 741
			AccessViolation,
			// Token: 0x040002E6 RID: 742
			InPageError,
			// Token: 0x040002E7 RID: 743
			PagefileQuota,
			// Token: 0x040002E8 RID: 744
			InvalidHandle,
			// Token: 0x040002E9 RID: 745
			BadInitialStack,
			// Token: 0x040002EA RID: 746
			BadInitialPc,
			// Token: 0x040002EB RID: 747
			InvalidCid,
			// Token: 0x040002EC RID: 748
			TimerNotCanceled,
			// Token: 0x040002ED RID: 749
			InvalidParameter,
			// Token: 0x040002EE RID: 750
			NoSuchDevice,
			// Token: 0x040002EF RID: 751
			NoSuchFile,
			// Token: 0x040002F0 RID: 752
			InvalidDeviceRequest,
			// Token: 0x040002F1 RID: 753
			EndOfFile,
			// Token: 0x040002F2 RID: 754
			WrongVolume,
			// Token: 0x040002F3 RID: 755
			NoMediaInDevice,
			// Token: 0x040002F4 RID: 756
			NoMemory = 3221225495U,
			// Token: 0x040002F5 RID: 757
			NotMappedView = 3221225497U,
			// Token: 0x040002F6 RID: 758
			UnableToFreeVm,
			// Token: 0x040002F7 RID: 759
			UnableToDeleteSection,
			// Token: 0x040002F8 RID: 760
			IllegalInstruction = 3221225501U,
			// Token: 0x040002F9 RID: 761
			AlreadyCommitted = 3221225505U,
			// Token: 0x040002FA RID: 762
			AccessDenied,
			// Token: 0x040002FB RID: 763
			BufferTooSmall,
			// Token: 0x040002FC RID: 764
			ObjectTypeMismatch,
			// Token: 0x040002FD RID: 765
			NonContinuableException,
			// Token: 0x040002FE RID: 766
			BadStack = 3221225512U,
			// Token: 0x040002FF RID: 767
			NotLocked = 3221225514U,
			// Token: 0x04000300 RID: 768
			NotCommitted = 3221225517U,
			// Token: 0x04000301 RID: 769
			InvalidParameterMix = 3221225520U,
			// Token: 0x04000302 RID: 770
			ObjectNameInvalid = 3221225523U,
			// Token: 0x04000303 RID: 771
			ObjectNameNotFound,
			// Token: 0x04000304 RID: 772
			ObjectNameCollision,
			// Token: 0x04000305 RID: 773
			ObjectPathInvalid = 3221225529U,
			// Token: 0x04000306 RID: 774
			ObjectPathNotFound,
			// Token: 0x04000307 RID: 775
			ObjectPathSyntaxBad,
			// Token: 0x04000308 RID: 776
			DataOverrun,
			// Token: 0x04000309 RID: 777
			DataLate,
			// Token: 0x0400030A RID: 778
			DataError,
			// Token: 0x0400030B RID: 779
			CrcError,
			// Token: 0x0400030C RID: 780
			SectionTooBig,
			// Token: 0x0400030D RID: 781
			PortConnectionRefused,
			// Token: 0x0400030E RID: 782
			InvalidPortHandle,
			// Token: 0x0400030F RID: 783
			SharingViolation,
			// Token: 0x04000310 RID: 784
			QuotaExceeded,
			// Token: 0x04000311 RID: 785
			InvalidPageProtection,
			// Token: 0x04000312 RID: 786
			MutantNotOwned,
			// Token: 0x04000313 RID: 787
			SemaphoreLimitExceeded,
			// Token: 0x04000314 RID: 788
			PortAlreadySet,
			// Token: 0x04000315 RID: 789
			SectionNotImage,
			// Token: 0x04000316 RID: 790
			SuspendCountExceeded,
			// Token: 0x04000317 RID: 791
			ThreadIsTerminating,
			// Token: 0x04000318 RID: 792
			BadWorkingSetLimit,
			// Token: 0x04000319 RID: 793
			IncompatibleFileMap,
			// Token: 0x0400031A RID: 794
			SectionProtection,
			// Token: 0x0400031B RID: 795
			EasNotSupported,
			// Token: 0x0400031C RID: 796
			EaTooLarge,
			// Token: 0x0400031D RID: 797
			NonExistentEaEntry,
			// Token: 0x0400031E RID: 798
			NoEasOnFile,
			// Token: 0x0400031F RID: 799
			EaCorruptError,
			// Token: 0x04000320 RID: 800
			FileLockConflict,
			// Token: 0x04000321 RID: 801
			LockNotGranted,
			// Token: 0x04000322 RID: 802
			DeletePending,
			// Token: 0x04000323 RID: 803
			CtlFileNotSupported,
			// Token: 0x04000324 RID: 804
			UnknownRevision,
			// Token: 0x04000325 RID: 805
			RevisionMismatch,
			// Token: 0x04000326 RID: 806
			InvalidOwner,
			// Token: 0x04000327 RID: 807
			InvalidPrimaryGroup,
			// Token: 0x04000328 RID: 808
			NoImpersonationToken,
			// Token: 0x04000329 RID: 809
			CantDisableMandatory,
			// Token: 0x0400032A RID: 810
			NoLogonServers,
			// Token: 0x0400032B RID: 811
			NoSuchLogonSession,
			// Token: 0x0400032C RID: 812
			NoSuchPrivilege,
			// Token: 0x0400032D RID: 813
			PrivilegeNotHeld,
			// Token: 0x0400032E RID: 814
			InvalidAccountName,
			// Token: 0x0400032F RID: 815
			UserExists,
			// Token: 0x04000330 RID: 816
			NoSuchUser,
			// Token: 0x04000331 RID: 817
			GroupExists,
			// Token: 0x04000332 RID: 818
			NoSuchGroup,
			// Token: 0x04000333 RID: 819
			MemberInGroup,
			// Token: 0x04000334 RID: 820
			MemberNotInGroup,
			// Token: 0x04000335 RID: 821
			LastAdmin,
			// Token: 0x04000336 RID: 822
			WrongPassword,
			// Token: 0x04000337 RID: 823
			IllFormedPassword,
			// Token: 0x04000338 RID: 824
			PasswordRestriction,
			// Token: 0x04000339 RID: 825
			LogonFailure,
			// Token: 0x0400033A RID: 826
			AccountRestriction,
			// Token: 0x0400033B RID: 827
			InvalidLogonHours,
			// Token: 0x0400033C RID: 828
			InvalidWorkstation,
			// Token: 0x0400033D RID: 829
			PasswordExpired,
			// Token: 0x0400033E RID: 830
			AccountDisabled,
			// Token: 0x0400033F RID: 831
			NoneMapped,
			// Token: 0x04000340 RID: 832
			TooManyLuidsRequested,
			// Token: 0x04000341 RID: 833
			LuidsExhausted,
			// Token: 0x04000342 RID: 834
			InvalidSubAuthority,
			// Token: 0x04000343 RID: 835
			InvalidAcl,
			// Token: 0x04000344 RID: 836
			InvalidSid,
			// Token: 0x04000345 RID: 837
			InvalidSecurityDescr,
			// Token: 0x04000346 RID: 838
			ProcedureNotFound,
			// Token: 0x04000347 RID: 839
			InvalidImageFormat,
			// Token: 0x04000348 RID: 840
			NoToken,
			// Token: 0x04000349 RID: 841
			BadInheritanceAcl,
			// Token: 0x0400034A RID: 842
			RangeNotLocked,
			// Token: 0x0400034B RID: 843
			DiskFull,
			// Token: 0x0400034C RID: 844
			ServerDisabled,
			// Token: 0x0400034D RID: 845
			ServerNotDisabled,
			// Token: 0x0400034E RID: 846
			TooManyGuidsRequested,
			// Token: 0x0400034F RID: 847
			GuidsExhausted,
			// Token: 0x04000350 RID: 848
			InvalidIdAuthority,
			// Token: 0x04000351 RID: 849
			AgentsExhausted,
			// Token: 0x04000352 RID: 850
			InvalidVolumeLabel,
			// Token: 0x04000353 RID: 851
			SectionNotExtended,
			// Token: 0x04000354 RID: 852
			NotMappedData,
			// Token: 0x04000355 RID: 853
			ResourceDataNotFound,
			// Token: 0x04000356 RID: 854
			ResourceTypeNotFound,
			// Token: 0x04000357 RID: 855
			ResourceNameNotFound,
			// Token: 0x04000358 RID: 856
			ArrayBoundsExceeded,
			// Token: 0x04000359 RID: 857
			FloatDenormalOperand,
			// Token: 0x0400035A RID: 858
			FloatDivideByZero,
			// Token: 0x0400035B RID: 859
			FloatInexactResult,
			// Token: 0x0400035C RID: 860
			FloatInvalidOperation,
			// Token: 0x0400035D RID: 861
			FloatOverflow,
			// Token: 0x0400035E RID: 862
			FloatStackCheck,
			// Token: 0x0400035F RID: 863
			FloatUnderflow,
			// Token: 0x04000360 RID: 864
			IntegerDivideByZero,
			// Token: 0x04000361 RID: 865
			IntegerOverflow,
			// Token: 0x04000362 RID: 866
			PrivilegedInstruction,
			// Token: 0x04000363 RID: 867
			TooManyPagingFiles,
			// Token: 0x04000364 RID: 868
			FileInvalid,
			// Token: 0x04000365 RID: 869
			InstanceNotAvailable = 3221225643U,
			// Token: 0x04000366 RID: 870
			PipeNotAvailable,
			// Token: 0x04000367 RID: 871
			InvalidPipeState,
			// Token: 0x04000368 RID: 872
			PipeBusy,
			// Token: 0x04000369 RID: 873
			IllegalFunction,
			// Token: 0x0400036A RID: 874
			PipeDisconnected,
			// Token: 0x0400036B RID: 875
			PipeClosing,
			// Token: 0x0400036C RID: 876
			PipeConnected,
			// Token: 0x0400036D RID: 877
			PipeListening,
			// Token: 0x0400036E RID: 878
			InvalidReadMode,
			// Token: 0x0400036F RID: 879
			IoTimeout,
			// Token: 0x04000370 RID: 880
			FileForcedClosed,
			// Token: 0x04000371 RID: 881
			ProfilingNotStarted,
			// Token: 0x04000372 RID: 882
			ProfilingNotStopped,
			// Token: 0x04000373 RID: 883
			NotSameDevice = 3221225684U,
			// Token: 0x04000374 RID: 884
			FileRenamed,
			// Token: 0x04000375 RID: 885
			CantWait = 3221225688U,
			// Token: 0x04000376 RID: 886
			PipeEmpty,
			// Token: 0x04000377 RID: 887
			CantTerminateSelf = 3221225691U,
			// Token: 0x04000378 RID: 888
			InternalError = 3221225701U,
			// Token: 0x04000379 RID: 889
			InvalidParameter1 = 3221225711U,
			// Token: 0x0400037A RID: 890
			InvalidParameter2,
			// Token: 0x0400037B RID: 891
			InvalidParameter3,
			// Token: 0x0400037C RID: 892
			InvalidParameter4,
			// Token: 0x0400037D RID: 893
			InvalidParameter5,
			// Token: 0x0400037E RID: 894
			InvalidParameter6,
			// Token: 0x0400037F RID: 895
			InvalidParameter7,
			// Token: 0x04000380 RID: 896
			InvalidParameter8,
			// Token: 0x04000381 RID: 897
			InvalidParameter9,
			// Token: 0x04000382 RID: 898
			InvalidParameter10,
			// Token: 0x04000383 RID: 899
			InvalidParameter11,
			// Token: 0x04000384 RID: 900
			InvalidParameter12,
			// Token: 0x04000385 RID: 901
			MappedFileSizeZero = 3221225758U,
			// Token: 0x04000386 RID: 902
			TooManyOpenedFiles,
			// Token: 0x04000387 RID: 903
			Cancelled,
			// Token: 0x04000388 RID: 904
			CannotDelete,
			// Token: 0x04000389 RID: 905
			InvalidComputerName,
			// Token: 0x0400038A RID: 906
			FileDeleted,
			// Token: 0x0400038B RID: 907
			SpecialAccount,
			// Token: 0x0400038C RID: 908
			SpecialGroup,
			// Token: 0x0400038D RID: 909
			SpecialUser,
			// Token: 0x0400038E RID: 910
			MembersPrimaryGroup,
			// Token: 0x0400038F RID: 911
			FileClosed,
			// Token: 0x04000390 RID: 912
			TooManyThreads,
			// Token: 0x04000391 RID: 913
			ThreadNotInProcess,
			// Token: 0x04000392 RID: 914
			TokenAlreadyInUse,
			// Token: 0x04000393 RID: 915
			PagefileQuotaExceeded,
			// Token: 0x04000394 RID: 916
			CommitmentLimit,
			// Token: 0x04000395 RID: 917
			InvalidImageLeFormat,
			// Token: 0x04000396 RID: 918
			InvalidImageNotMz,
			// Token: 0x04000397 RID: 919
			InvalidImageProtect,
			// Token: 0x04000398 RID: 920
			InvalidImageWin16,
			// Token: 0x04000399 RID: 921
			LogonServer,
			// Token: 0x0400039A RID: 922
			DifferenceAtDc,
			// Token: 0x0400039B RID: 923
			SynchronizationRequired,
			// Token: 0x0400039C RID: 924
			DllNotFound,
			// Token: 0x0400039D RID: 925
			IoPrivilegeFailed = 3221225783U,
			// Token: 0x0400039E RID: 926
			OrdinalNotFound,
			// Token: 0x0400039F RID: 927
			EntryPointNotFound,
			// Token: 0x040003A0 RID: 928
			ControlCExit,
			// Token: 0x040003A1 RID: 929
			PortNotSet = 3221226323U,
			// Token: 0x040003A2 RID: 930
			DebuggerInactive,
			// Token: 0x040003A3 RID: 931
			CallbackBypass = 3221226755U,
			// Token: 0x040003A4 RID: 932
			PortClosed = 3221227264U,
			// Token: 0x040003A5 RID: 933
			MessageLost,
			// Token: 0x040003A6 RID: 934
			InvalidMessage,
			// Token: 0x040003A7 RID: 935
			RequestCanceled,
			// Token: 0x040003A8 RID: 936
			RecursiveDispatch,
			// Token: 0x040003A9 RID: 937
			LpcReceiveBufferExpected,
			// Token: 0x040003AA RID: 938
			LpcInvalidConnectionUsage,
			// Token: 0x040003AB RID: 939
			LpcRequestsNotAllowed,
			// Token: 0x040003AC RID: 940
			ResourceInUse,
			// Token: 0x040003AD RID: 941
			ProcessIsProtected = 3221227282U,
			// Token: 0x040003AE RID: 942
			VolumeDirty = 3221227526U,
			// Token: 0x040003AF RID: 943
			FileCheckedOut = 3221227777U,
			// Token: 0x040003B0 RID: 944
			CheckOutRequired,
			// Token: 0x040003B1 RID: 945
			BadFileType,
			// Token: 0x040003B2 RID: 946
			FileTooLarge,
			// Token: 0x040003B3 RID: 947
			FormsAuthRequired,
			// Token: 0x040003B4 RID: 948
			VirusInfected,
			// Token: 0x040003B5 RID: 949
			VirusDeleted,
			// Token: 0x040003B6 RID: 950
			TransactionalConflict = 3222863873U,
			// Token: 0x040003B7 RID: 951
			InvalidTransaction,
			// Token: 0x040003B8 RID: 952
			TransactionNotActive,
			// Token: 0x040003B9 RID: 953
			TmInitializationFailed,
			// Token: 0x040003BA RID: 954
			RmNotActive,
			// Token: 0x040003BB RID: 955
			RmMetadataCorrupt,
			// Token: 0x040003BC RID: 956
			TransactionNotJoined,
			// Token: 0x040003BD RID: 957
			DirectoryNotRm,
			// Token: 0x040003BE RID: 958
			CouldNotResizeLog,
			// Token: 0x040003BF RID: 959
			TransactionsUnsupportedRemote,
			// Token: 0x040003C0 RID: 960
			LogResizeInvalidSize,
			// Token: 0x040003C1 RID: 961
			RemoteFileVersionMismatch,
			// Token: 0x040003C2 RID: 962
			CrmProtocolAlreadyExists = 3222863887U,
			// Token: 0x040003C3 RID: 963
			TransactionPropagationFailed,
			// Token: 0x040003C4 RID: 964
			CrmProtocolNotFound,
			// Token: 0x040003C5 RID: 965
			TransactionSuperiorExists,
			// Token: 0x040003C6 RID: 966
			TransactionRequestNotValid,
			// Token: 0x040003C7 RID: 967
			TransactionNotRequested,
			// Token: 0x040003C8 RID: 968
			TransactionAlreadyAborted,
			// Token: 0x040003C9 RID: 969
			TransactionAlreadyCommitted,
			// Token: 0x040003CA RID: 970
			TransactionInvalidMarshallBuffer,
			// Token: 0x040003CB RID: 971
			CurrentTransactionNotValid,
			// Token: 0x040003CC RID: 972
			LogGrowthFailed,
			// Token: 0x040003CD RID: 973
			ObjectNoLongerExists = 3222863905U,
			// Token: 0x040003CE RID: 974
			StreamMiniversionNotFound,
			// Token: 0x040003CF RID: 975
			StreamMiniversionNotValid,
			// Token: 0x040003D0 RID: 976
			MiniversionInaccessibleFromSpecifiedTransaction,
			// Token: 0x040003D1 RID: 977
			CantOpenMiniversionWithModifyIntent,
			// Token: 0x040003D2 RID: 978
			CantCreateMoreStreamMiniversions,
			// Token: 0x040003D3 RID: 979
			HandleNoLongerValid = 3222863912U,
			// Token: 0x040003D4 RID: 980
			NoTxfMetadata,
			// Token: 0x040003D5 RID: 981
			LogCorruptionDetected = 3222863920U,
			// Token: 0x040003D6 RID: 982
			CantRecoverWithHandleOpen,
			// Token: 0x040003D7 RID: 983
			RmDisconnected,
			// Token: 0x040003D8 RID: 984
			EnlistmentNotSuperior,
			// Token: 0x040003D9 RID: 985
			RecoveryNotNeeded,
			// Token: 0x040003DA RID: 986
			RmAlreadyStarted,
			// Token: 0x040003DB RID: 987
			FileIdentityNotPersistent,
			// Token: 0x040003DC RID: 988
			CantBreakTransactionalDependency,
			// Token: 0x040003DD RID: 989
			CantCrossRmBoundary,
			// Token: 0x040003DE RID: 990
			TxfDirNotEmpty,
			// Token: 0x040003DF RID: 991
			IndoubtTransactionsExist,
			// Token: 0x040003E0 RID: 992
			TmVolatile,
			// Token: 0x040003E1 RID: 993
			RollbackTimerExpired,
			// Token: 0x040003E2 RID: 994
			TxfAttributeCorrupt,
			// Token: 0x040003E3 RID: 995
			EfsNotAllowedInTransaction,
			// Token: 0x040003E4 RID: 996
			TransactionalOpenNotAllowed,
			// Token: 0x040003E5 RID: 997
			TransactedMappingUnsupportedRemote,
			// Token: 0x040003E6 RID: 998
			TxfMetadataAlreadyPresent,
			// Token: 0x040003E7 RID: 999
			TransactionScopeCallbacksNotSet,
			// Token: 0x040003E8 RID: 1000
			TransactionRequiredPromotion,
			// Token: 0x040003E9 RID: 1001
			CannotExecuteFileInTransaction,
			// Token: 0x040003EA RID: 1002
			TransactionsNotFrozen,
			// Token: 0x040003EB RID: 1003
			MaximumNtStatus = 4294967295U
		}
	}
}
