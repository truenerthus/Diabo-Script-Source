﻿using System;
using System.Runtime.InteropServices;

namespace Impure.Utils
{
	// Token: 0x02000064 RID: 100
	internal class WinStructs
	{
		// Token: 0x02000065 RID: 101
		public enum PROCESSINFOCLASS
		{
			// Token: 0x040003ED RID: 1005
			ProcessBasicInformation,
			// Token: 0x040003EE RID: 1006
			ProcessQuotaLimits,
			// Token: 0x040003EF RID: 1007
			ProcessIoCounters,
			// Token: 0x040003F0 RID: 1008
			ProcessVmCounters,
			// Token: 0x040003F1 RID: 1009
			ProcessTimes,
			// Token: 0x040003F2 RID: 1010
			ProcessBasePriority,
			// Token: 0x040003F3 RID: 1011
			ProcessRaisePriority,
			// Token: 0x040003F4 RID: 1012
			ProcessDebugPort,
			// Token: 0x040003F5 RID: 1013
			ProcessExceptionPort,
			// Token: 0x040003F6 RID: 1014
			ProcessAccessToken,
			// Token: 0x040003F7 RID: 1015
			ProcessLdtInformation,
			// Token: 0x040003F8 RID: 1016
			ProcessLdtSize,
			// Token: 0x040003F9 RID: 1017
			ProcessDefaultHardErrorMode,
			// Token: 0x040003FA RID: 1018
			ProcessIoPortHandlers,
			// Token: 0x040003FB RID: 1019
			ProcessPooledUsageAndLimits,
			// Token: 0x040003FC RID: 1020
			ProcessWorkingSetWatch,
			// Token: 0x040003FD RID: 1021
			ProcessUserModeIOPL,
			// Token: 0x040003FE RID: 1022
			ProcessEnableAlignmentFaultFixup,
			// Token: 0x040003FF RID: 1023
			ProcessPriorityClass,
			// Token: 0x04000400 RID: 1024
			ProcessWx86Information,
			// Token: 0x04000401 RID: 1025
			ProcessHandleCount,
			// Token: 0x04000402 RID: 1026
			ProcessAffinityMask,
			// Token: 0x04000403 RID: 1027
			ProcessPriorityBoost,
			// Token: 0x04000404 RID: 1028
			ProcessDeviceMap,
			// Token: 0x04000405 RID: 1029
			ProcessSessionInformation,
			// Token: 0x04000406 RID: 1030
			ProcessForegroundInformation,
			// Token: 0x04000407 RID: 1031
			ProcessWow64Information,
			// Token: 0x04000408 RID: 1032
			ProcessImageFileName,
			// Token: 0x04000409 RID: 1033
			ProcessLUIDDeviceMapsEnabled,
			// Token: 0x0400040A RID: 1034
			ProcessBreakOnTermination,
			// Token: 0x0400040B RID: 1035
			ProcessDebugObjectHandle,
			// Token: 0x0400040C RID: 1036
			ProcessDebugFlags,
			// Token: 0x0400040D RID: 1037
			ProcessHandleTracing,
			// Token: 0x0400040E RID: 1038
			ProcessIoPriority,
			// Token: 0x0400040F RID: 1039
			ProcessExecuteFlags,
			// Token: 0x04000410 RID: 1040
			ProcessResourceManagement,
			// Token: 0x04000411 RID: 1041
			ProcessCookie,
			// Token: 0x04000412 RID: 1042
			ProcessImageInformation,
			// Token: 0x04000413 RID: 1043
			ProcessCycleTime,
			// Token: 0x04000414 RID: 1044
			ProcessPagePriority,
			// Token: 0x04000415 RID: 1045
			ProcessInstrumentationCallback,
			// Token: 0x04000416 RID: 1046
			ProcessThreadStackAllocation,
			// Token: 0x04000417 RID: 1047
			ProcessWorkingSetWatchEx,
			// Token: 0x04000418 RID: 1048
			ProcessImageFileNameWin32,
			// Token: 0x04000419 RID: 1049
			ProcessImageFileMapping,
			// Token: 0x0400041A RID: 1050
			ProcessAffinityUpdateMode,
			// Token: 0x0400041B RID: 1051
			ProcessMemoryAllocationMode,
			// Token: 0x0400041C RID: 1052
			ProcessGroupInformation,
			// Token: 0x0400041D RID: 1053
			ProcessTokenVirtualizationEnabled,
			// Token: 0x0400041E RID: 1054
			ProcessConsoleHostProcess,
			// Token: 0x0400041F RID: 1055
			ProcessWindowInformation,
			// Token: 0x04000420 RID: 1056
			ProcessHandleInformation,
			// Token: 0x04000421 RID: 1057
			ProcessMitigationPolicy,
			// Token: 0x04000422 RID: 1058
			ProcessDynamicFunctionTableInformation,
			// Token: 0x04000423 RID: 1059
			ProcessHandleCheckingMode,
			// Token: 0x04000424 RID: 1060
			ProcessKeepAliveCount,
			// Token: 0x04000425 RID: 1061
			ProcessRevokeFileHandles,
			// Token: 0x04000426 RID: 1062
			ProcessWorkingSetControl,
			// Token: 0x04000427 RID: 1063
			ProcessHandleTable,
			// Token: 0x04000428 RID: 1064
			ProcessCheckStackExtentsMode,
			// Token: 0x04000429 RID: 1065
			ProcessCommandLineInformation,
			// Token: 0x0400042A RID: 1066
			ProcessProtectionInformation,
			// Token: 0x0400042B RID: 1067
			MaxProcessInfoClass
		}

		// Token: 0x02000066 RID: 102
		[Flags]
		public enum DebugObjectInformationClass
		{
			// Token: 0x0400042D RID: 1069
			DebugObjectFlags = 1,
			// Token: 0x0400042E RID: 1070
			MaxDebugObjectInfoClass = 2
		}

		// Token: 0x02000067 RID: 103
		public enum SYSTEM_INFORMATION_CLASS
		{
			// Token: 0x04000430 RID: 1072
			SystemBasicInformation,
			// Token: 0x04000431 RID: 1073
			SystemProcessorInformation,
			// Token: 0x04000432 RID: 1074
			SystemPerformanceInformation,
			// Token: 0x04000433 RID: 1075
			SystemTimeOfDayInformation,
			// Token: 0x04000434 RID: 1076
			SystemPathInformation,
			// Token: 0x04000435 RID: 1077
			SystemProcessInformation,
			// Token: 0x04000436 RID: 1078
			SystemCallCountInformation,
			// Token: 0x04000437 RID: 1079
			SystemDeviceInformation,
			// Token: 0x04000438 RID: 1080
			SystemProcessorPerformanceInformation,
			// Token: 0x04000439 RID: 1081
			SystemFlagsInformation,
			// Token: 0x0400043A RID: 1082
			SystemCallTimeInformation,
			// Token: 0x0400043B RID: 1083
			SystemModuleInformation,
			// Token: 0x0400043C RID: 1084
			SystemLocksInformation,
			// Token: 0x0400043D RID: 1085
			SystemStackTraceInformation,
			// Token: 0x0400043E RID: 1086
			SystemPagedPoolInformation,
			// Token: 0x0400043F RID: 1087
			SystemNonPagedPoolInformation,
			// Token: 0x04000440 RID: 1088
			SystemHandleInformation,
			// Token: 0x04000441 RID: 1089
			SystemObjectInformation,
			// Token: 0x04000442 RID: 1090
			SystemPageFileInformation,
			// Token: 0x04000443 RID: 1091
			SystemVdmInstemulInformation,
			// Token: 0x04000444 RID: 1092
			SystemVdmBopInformation,
			// Token: 0x04000445 RID: 1093
			SystemFileCacheInformation,
			// Token: 0x04000446 RID: 1094
			SystemPoolTagInformation,
			// Token: 0x04000447 RID: 1095
			SystemInterruptInformation,
			// Token: 0x04000448 RID: 1096
			SystemDpcBehaviorInformation,
			// Token: 0x04000449 RID: 1097
			SystemFullMemoryInformation,
			// Token: 0x0400044A RID: 1098
			SystemLoadGdiDriverInformation,
			// Token: 0x0400044B RID: 1099
			SystemUnloadGdiDriverInformation,
			// Token: 0x0400044C RID: 1100
			SystemTimeAdjustmentInformation,
			// Token: 0x0400044D RID: 1101
			SystemSummaryMemoryInformation,
			// Token: 0x0400044E RID: 1102
			SystemMirrorMemoryInformation,
			// Token: 0x0400044F RID: 1103
			SystemPerformanceTraceInformation,
			// Token: 0x04000450 RID: 1104
			SystemObsolete0,
			// Token: 0x04000451 RID: 1105
			SystemExceptionInformation,
			// Token: 0x04000452 RID: 1106
			SystemCrashDumpStateInformation,
			// Token: 0x04000453 RID: 1107
			SystemKernelDebuggerInformation,
			// Token: 0x04000454 RID: 1108
			SystemContextSwitchInformation,
			// Token: 0x04000455 RID: 1109
			SystemRegistryQuotaInformation,
			// Token: 0x04000456 RID: 1110
			SystemExtendServiceTableInformation,
			// Token: 0x04000457 RID: 1111
			SystemPrioritySeperation,
			// Token: 0x04000458 RID: 1112
			SystemVerifierAddDriverInformation,
			// Token: 0x04000459 RID: 1113
			SystemVerifierRemoveDriverInformation,
			// Token: 0x0400045A RID: 1114
			SystemProcessorIdleInformation,
			// Token: 0x0400045B RID: 1115
			SystemLegacyDriverInformation,
			// Token: 0x0400045C RID: 1116
			SystemCurrentTimeZoneInformation,
			// Token: 0x0400045D RID: 1117
			SystemLookasideInformation,
			// Token: 0x0400045E RID: 1118
			SystemTimeSlipNotification,
			// Token: 0x0400045F RID: 1119
			SystemSessionCreate,
			// Token: 0x04000460 RID: 1120
			SystemSessionDetach,
			// Token: 0x04000461 RID: 1121
			SystemSessionInformation,
			// Token: 0x04000462 RID: 1122
			SystemRangeStartInformation,
			// Token: 0x04000463 RID: 1123
			SystemVerifierInformation,
			// Token: 0x04000464 RID: 1124
			SystemVerifierThunkExtend,
			// Token: 0x04000465 RID: 1125
			SystemSessionProcessInformation,
			// Token: 0x04000466 RID: 1126
			SystemLoadGdiDriverInSystemSpace,
			// Token: 0x04000467 RID: 1127
			SystemNumaProcessorMap,
			// Token: 0x04000468 RID: 1128
			SystemPrefetcherInformation,
			// Token: 0x04000469 RID: 1129
			SystemExtendedProcessInformation,
			// Token: 0x0400046A RID: 1130
			SystemRecommendedSharedDataAlignment,
			// Token: 0x0400046B RID: 1131
			SystemComPlusPackage,
			// Token: 0x0400046C RID: 1132
			SystemNumaAvailableMemory,
			// Token: 0x0400046D RID: 1133
			SystemProcessorPowerInformation,
			// Token: 0x0400046E RID: 1134
			SystemEmulationBasicInformation,
			// Token: 0x0400046F RID: 1135
			SystemEmulationProcessorInformation,
			// Token: 0x04000470 RID: 1136
			SystemExtendedHandleInformation,
			// Token: 0x04000471 RID: 1137
			SystemLostDelayedWriteInformation,
			// Token: 0x04000472 RID: 1138
			SystemBigPoolInformation,
			// Token: 0x04000473 RID: 1139
			SystemSessionPoolTagInformation,
			// Token: 0x04000474 RID: 1140
			SystemSessionMappedViewInformation,
			// Token: 0x04000475 RID: 1141
			SystemHotpatchInformation,
			// Token: 0x04000476 RID: 1142
			SystemObjectSecurityMode,
			// Token: 0x04000477 RID: 1143
			SystemWatchdogTimerHandler,
			// Token: 0x04000478 RID: 1144
			SystemWatchdogTimerInformation,
			// Token: 0x04000479 RID: 1145
			SystemLogicalProcessorInformation,
			// Token: 0x0400047A RID: 1146
			SystemWow64SharedInformationObsolete,
			// Token: 0x0400047B RID: 1147
			SystemRegisterFirmwareTableInformationHandler,
			// Token: 0x0400047C RID: 1148
			SystemFirmwareTableInformation,
			// Token: 0x0400047D RID: 1149
			SystemModuleInformationEx,
			// Token: 0x0400047E RID: 1150
			SystemVerifierTriageInformation,
			// Token: 0x0400047F RID: 1151
			SystemSuperfetchInformation,
			// Token: 0x04000480 RID: 1152
			SystemMemoryListInformation,
			// Token: 0x04000481 RID: 1153
			SystemFileCacheInformationEx,
			// Token: 0x04000482 RID: 1154
			SystemThreadPriorityClientIdInformation,
			// Token: 0x04000483 RID: 1155
			SystemProcessorIdleCycleTimeInformation,
			// Token: 0x04000484 RID: 1156
			SystemVerifierCancellationInformation,
			// Token: 0x04000485 RID: 1157
			SystemProcessorPowerInformationEx,
			// Token: 0x04000486 RID: 1158
			SystemRefTraceInformation,
			// Token: 0x04000487 RID: 1159
			SystemSpecialPoolInformation,
			// Token: 0x04000488 RID: 1160
			SystemProcessIdInformation,
			// Token: 0x04000489 RID: 1161
			SystemErrorPortInformation,
			// Token: 0x0400048A RID: 1162
			SystemBootEnvironmentInformation,
			// Token: 0x0400048B RID: 1163
			SystemHypervisorInformation,
			// Token: 0x0400048C RID: 1164
			SystemVerifierInformationEx,
			// Token: 0x0400048D RID: 1165
			SystemTimeZoneInformation,
			// Token: 0x0400048E RID: 1166
			SystemImageFileExecutionOptionsInformation,
			// Token: 0x0400048F RID: 1167
			SystemCoverageInformation,
			// Token: 0x04000490 RID: 1168
			SystemPrefetchPatchInformation,
			// Token: 0x04000491 RID: 1169
			SystemVerifierFaultsInformation,
			// Token: 0x04000492 RID: 1170
			SystemSystemPartitionInformation,
			// Token: 0x04000493 RID: 1171
			SystemSystemDiskInformation,
			// Token: 0x04000494 RID: 1172
			SystemProcessorPerformanceDistribution,
			// Token: 0x04000495 RID: 1173
			SystemNumaProximityNodeInformation,
			// Token: 0x04000496 RID: 1174
			SystemDynamicTimeZoneInformation,
			// Token: 0x04000497 RID: 1175
			SystemCodeIntegrityInformation,
			// Token: 0x04000498 RID: 1176
			SystemProcessorMicrocodeUpdateInformation,
			// Token: 0x04000499 RID: 1177
			SystemProcessorBrandString,
			// Token: 0x0400049A RID: 1178
			SystemVirtualAddressInformation,
			// Token: 0x0400049B RID: 1179
			SystemLogicalProcessorAndGroupInformation,
			// Token: 0x0400049C RID: 1180
			SystemProcessorCycleTimeInformation,
			// Token: 0x0400049D RID: 1181
			SystemStoreInformation,
			// Token: 0x0400049E RID: 1182
			SystemRegistryAppendString,
			// Token: 0x0400049F RID: 1183
			SystemAitSamplingValue,
			// Token: 0x040004A0 RID: 1184
			SystemVhdBootInformation,
			// Token: 0x040004A1 RID: 1185
			SystemCpuQuotaInformation,
			// Token: 0x040004A2 RID: 1186
			SystemNativeBasicInformation,
			// Token: 0x040004A3 RID: 1187
			SystemSpare1,
			// Token: 0x040004A4 RID: 1188
			SystemLowPriorityIoInformation,
			// Token: 0x040004A5 RID: 1189
			SystemTpmBootEntropyInformation,
			// Token: 0x040004A6 RID: 1190
			SystemVerifierCountersInformation,
			// Token: 0x040004A7 RID: 1191
			SystemPagedPoolInformationEx,
			// Token: 0x040004A8 RID: 1192
			SystemSystemPtesInformationEx,
			// Token: 0x040004A9 RID: 1193
			SystemNodeDistanceInformation,
			// Token: 0x040004AA RID: 1194
			SystemAcpiAuditInformation,
			// Token: 0x040004AB RID: 1195
			SystemBasicPerformanceInformation,
			// Token: 0x040004AC RID: 1196
			SystemQueryPerformanceCounterInformation,
			// Token: 0x040004AD RID: 1197
			SystemSessionBigPoolInformation,
			// Token: 0x040004AE RID: 1198
			SystemBootGraphicsInformation,
			// Token: 0x040004AF RID: 1199
			SystemScrubPhysicalMemoryInformation,
			// Token: 0x040004B0 RID: 1200
			SystemBadPageInformation,
			// Token: 0x040004B1 RID: 1201
			SystemProcessorProfileControlArea,
			// Token: 0x040004B2 RID: 1202
			SystemCombinePhysicalMemoryInformation,
			// Token: 0x040004B3 RID: 1203
			SystemEntropyInterruptTimingCallback,
			// Token: 0x040004B4 RID: 1204
			SystemConsoleInformation,
			// Token: 0x040004B5 RID: 1205
			SystemPlatformBinaryInformation,
			// Token: 0x040004B6 RID: 1206
			SystemThrottleNotificationInformation,
			// Token: 0x040004B7 RID: 1207
			SystemHypervisorProcessorCountInformation,
			// Token: 0x040004B8 RID: 1208
			SystemDeviceDataInformation,
			// Token: 0x040004B9 RID: 1209
			SystemDeviceDataEnumerationInformation,
			// Token: 0x040004BA RID: 1210
			SystemMemoryTopologyInformation,
			// Token: 0x040004BB RID: 1211
			SystemMemoryChannelInformation,
			// Token: 0x040004BC RID: 1212
			SystemBootLogoInformation,
			// Token: 0x040004BD RID: 1213
			SystemProcessorPerformanceInformationEx,
			// Token: 0x040004BE RID: 1214
			SystemSpare0,
			// Token: 0x040004BF RID: 1215
			SystemSecureBootPolicyInformation,
			// Token: 0x040004C0 RID: 1216
			SystemPageFileInformationEx,
			// Token: 0x040004C1 RID: 1217
			SystemSecureBootInformation,
			// Token: 0x040004C2 RID: 1218
			SystemEntropyInterruptTimingRawInformation,
			// Token: 0x040004C3 RID: 1219
			SystemPortableWorkspaceEfiLauncherInformation,
			// Token: 0x040004C4 RID: 1220
			SystemFullProcessInformation,
			// Token: 0x040004C5 RID: 1221
			SystemKernelDebuggerInformationEx,
			// Token: 0x040004C6 RID: 1222
			SystemBootMetadataInformation,
			// Token: 0x040004C7 RID: 1223
			SystemSoftRebootInformation,
			// Token: 0x040004C8 RID: 1224
			SystemElamCertificateInformation,
			// Token: 0x040004C9 RID: 1225
			SystemOfflineDumpConfigInformation,
			// Token: 0x040004CA RID: 1226
			SystemProcessorFeaturesInformation,
			// Token: 0x040004CB RID: 1227
			SystemRegistryReconciliationInformation,
			// Token: 0x040004CC RID: 1228
			SystemEdidInformation,
			// Token: 0x040004CD RID: 1229
			MaxSystemInfoClass
		}

		// Token: 0x02000068 RID: 104
		public enum ThreadInformationClass
		{
			// Token: 0x040004CF RID: 1231
			ThreadBasicInformation,
			// Token: 0x040004D0 RID: 1232
			ThreadTimes,
			// Token: 0x040004D1 RID: 1233
			ThreadPriority,
			// Token: 0x040004D2 RID: 1234
			ThreadBasePriority,
			// Token: 0x040004D3 RID: 1235
			ThreadAffinityMask,
			// Token: 0x040004D4 RID: 1236
			ThreadImpersonationToken,
			// Token: 0x040004D5 RID: 1237
			ThreadDescriptorTableEntry,
			// Token: 0x040004D6 RID: 1238
			ThreadEnableAlignmentFaultFixup,
			// Token: 0x040004D7 RID: 1239
			ThreadEventPair_Reusable,
			// Token: 0x040004D8 RID: 1240
			ThreadQuerySetWin32StartAddress,
			// Token: 0x040004D9 RID: 1241
			ThreadZeroTlsCell,
			// Token: 0x040004DA RID: 1242
			ThreadPerformanceCount,
			// Token: 0x040004DB RID: 1243
			ThreadAmILastThread,
			// Token: 0x040004DC RID: 1244
			ThreadIdealProcessor,
			// Token: 0x040004DD RID: 1245
			ThreadPriorityBoost,
			// Token: 0x040004DE RID: 1246
			ThreadSetTlsArrayAddress,
			// Token: 0x040004DF RID: 1247
			ThreadIsIoPending,
			// Token: 0x040004E0 RID: 1248
			ThreadHideFromDebugger,
			// Token: 0x040004E1 RID: 1249
			ThreadBreakOnTermination,
			// Token: 0x040004E2 RID: 1250
			ThreadSwitchLegacyState,
			// Token: 0x040004E3 RID: 1251
			ThreadIsTerminated,
			// Token: 0x040004E4 RID: 1252
			ThreadLastSystemCall,
			// Token: 0x040004E5 RID: 1253
			ThreadIoPriority,
			// Token: 0x040004E6 RID: 1254
			ThreadCycleTime,
			// Token: 0x040004E7 RID: 1255
			ThreadPagePriority,
			// Token: 0x040004E8 RID: 1256
			ThreadActualBasePriority,
			// Token: 0x040004E9 RID: 1257
			ThreadTebInformation,
			// Token: 0x040004EA RID: 1258
			ThreadCSwitchMon,
			// Token: 0x040004EB RID: 1259
			ThreadCSwitchPmu,
			// Token: 0x040004EC RID: 1260
			ThreadWow64Context,
			// Token: 0x040004ED RID: 1261
			ThreadGroupInformation,
			// Token: 0x040004EE RID: 1262
			ThreadUmsInformation,
			// Token: 0x040004EF RID: 1263
			ThreadCounterProfiling,
			// Token: 0x040004F0 RID: 1264
			ThreadIdealProcessorEx,
			// Token: 0x040004F1 RID: 1265
			ThreadCpuAccountingInformation,
			// Token: 0x040004F2 RID: 1266
			ThreadSuspendCount,
			// Token: 0x040004F3 RID: 1267
			ThreadDescription = 38,
			// Token: 0x040004F4 RID: 1268
			ThreadActualGroupAffinity = 41,
			// Token: 0x040004F5 RID: 1269
			ThreadDynamicCodePolicy
		}

		// Token: 0x02000069 RID: 105
		[Flags]
		public enum ThreadAccess
		{
			// Token: 0x040004F7 RID: 1271
			TERMINATE = 1,
			// Token: 0x040004F8 RID: 1272
			SUSPEND_RESUME = 2,
			// Token: 0x040004F9 RID: 1273
			GET_CONTEXT = 8,
			// Token: 0x040004FA RID: 1274
			SET_CONTEXT = 16,
			// Token: 0x040004FB RID: 1275
			SET_INFORMATION = 32,
			// Token: 0x040004FC RID: 1276
			QUERY_INFORMATION = 64,
			// Token: 0x040004FD RID: 1277
			SET_THREAD_TOKEN = 128,
			// Token: 0x040004FE RID: 1278
			IMPERSONATE = 256,
			// Token: 0x040004FF RID: 1279
			DIRECT_IMPERSONATION = 512
		}

		// Token: 0x0200006A RID: 106
		public struct SYSTEM_KERNEL_DEBUGGER_INFORMATION
		{
			// Token: 0x04000500 RID: 1280
			[MarshalAs(UnmanagedType.U1)]
			public bool KernelDebuggerEnabled;

			// Token: 0x04000501 RID: 1281
			[MarshalAs(UnmanagedType.U1)]
			public bool KernelDebuggerNotPresent;
		}
	}
}
