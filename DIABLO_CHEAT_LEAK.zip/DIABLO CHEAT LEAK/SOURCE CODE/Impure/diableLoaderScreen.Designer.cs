﻿namespace Impure
{
	// Token: 0x02000012 RID: 18
	public partial class diableLoaderScreen : global::System.Windows.Forms.Form
	{
		// Token: 0x0600007E RID: 126 RVA: 0x000058D8 File Offset: 0x00003AD8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00005910 File Offset: 0x00003B10
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(800, 450);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "diableLoaderScreen";
			this.Text = "diableLoaderScreen";
			base.ResumeLayout(false);
		}

		// Token: 0x0400003E RID: 62
		private global::System.ComponentModel.IContainer components = null;
	}
}
