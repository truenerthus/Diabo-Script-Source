﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Impure
{
	// Token: 0x02000012 RID: 18
	public partial class diableLoaderScreen : Form
	{
		// Token: 0x0600007D RID: 125 RVA: 0x00002502 File Offset: 0x00000702
		public diableLoaderScreen()
		{
			this.InitializeComponent();
		}
	}
}
