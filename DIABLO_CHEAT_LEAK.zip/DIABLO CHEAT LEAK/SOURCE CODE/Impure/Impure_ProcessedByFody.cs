﻿using System;

// Token: 0x0200007D RID: 125
internal class Impure_ProcessedByFody
{
	// Token: 0x04000574 RID: 1396
	internal const string FodyVersion = "6.2.4.0";

	// Token: 0x04000575 RID: 1397
	internal const string Costura = "4.1.0.0";
}
