﻿namespace Impure
{
	// Token: 0x02000014 RID: 20
	public partial class Perfom : global::System.Windows.Forms.Form
	{
		// Token: 0x06000086 RID: 134 RVA: 0x00005CB8 File Offset: 0x00003EB8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00005CF0 File Offset: 0x00003EF0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Impure.Perfom));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.label1 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel1.BackgroundImage");
			this.panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(651, 151);
			this.panel1.TabIndex = 1;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = global::System.Drawing.Color.FromArgb(132, 193, 226);
			this.label1.Location = new global::System.Drawing.Point(52, 133);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(198, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "NaiveCheats Performance";
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label2.ForeColor = global::System.Drawing.Color.Yellow;
			this.label2.Location = new global::System.Drawing.Point(254, 167);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(114, 18);
			this.label2.TabIndex = 3;
			this.label2.Text = "COMING SOON";
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Arial Black", 9.75f, global::System.Drawing.FontStyle.Bold);
			this.label3.ForeColor = global::System.Drawing.Color.Red;
			this.label3.Location = new global::System.Drawing.Point(52, 195);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(532, 18);
			this.label3.TabIndex = 4;
			this.label3.Text = "this will boost your pc's perfomance to 20+ FPS when using our software";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(28, 38, 50);
			base.ClientSize = new global::System.Drawing.Size(651, 470);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Perfom";
			this.Text = "Perfom";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000043 RID: 67
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000045 RID: 69
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000046 RID: 70
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000047 RID: 71
		private global::System.Windows.Forms.Label label3;
	}
}
