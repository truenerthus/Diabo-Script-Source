﻿using System;

namespace Impure
{
	// Token: 0x02000015 RID: 21
	internal class ProgramInfo
	{
		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000088 RID: 136 RVA: 0x0000254A File Offset: 0x0000074A
		// (set) Token: 0x06000089 RID: 137 RVA: 0x00002551 File Offset: 0x00000751
		public static string Version { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600008A RID: 138 RVA: 0x00002559 File Offset: 0x00000759
		// (set) Token: 0x0600008B RID: 139 RVA: 0x00002560 File Offset: 0x00000760
		public static string Hash { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600008C RID: 140 RVA: 0x00002568 File Offset: 0x00000768
		// (set) Token: 0x0600008D RID: 141 RVA: 0x0000256F File Offset: 0x0000076F
		public static string Application { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600008E RID: 142 RVA: 0x00002577 File Offset: 0x00000777
		// (set) Token: 0x0600008F RID: 143 RVA: 0x0000257E File Offset: 0x0000077E
		public static string DeveloperMode { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000090 RID: 144 RVA: 0x00002586 File Offset: 0x00000786
		// (set) Token: 0x06000091 RID: 145 RVA: 0x0000258D File Offset: 0x0000078D
		public static string Freemode { get; set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000092 RID: 146 RVA: 0x00002595 File Offset: 0x00000795
		// (set) Token: 0x06000093 RID: 147 RVA: 0x0000259C File Offset: 0x0000079C
		public static string DownloadLink { get; set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000094 RID: 148 RVA: 0x000025A4 File Offset: 0x000007A4
		// (set) Token: 0x06000095 RID: 149 RVA: 0x000025AB File Offset: 0x000007AB
		public static string Register { get; set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000096 RID: 150 RVA: 0x000025B3 File Offset: 0x000007B3
		// (set) Token: 0x06000097 RID: 151 RVA: 0x000025BA File Offset: 0x000007BA
		public static string Login { get; set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000098 RID: 152 RVA: 0x000025C2 File Offset: 0x000007C2
		// (set) Token: 0x06000099 RID: 153 RVA: 0x000025C9 File Offset: 0x000007C9
		public static string Status { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600009A RID: 154 RVA: 0x000025D1 File Offset: 0x000007D1
		// (set) Token: 0x0600009B RID: 155 RVA: 0x000025D8 File Offset: 0x000007D8
		public static string APIKey { get; set; }
	}
}
